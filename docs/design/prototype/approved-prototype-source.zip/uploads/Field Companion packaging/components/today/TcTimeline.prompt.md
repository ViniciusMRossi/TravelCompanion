Day timeline — the branded core of Hoje and Dia completo.

```jsx
<TcTimeline items={[
  { time: "08:30", title: "Butrinto", detail: "Atração · audioguia disponível", state: "active" },
  { time: "19:30", title: "Ônibus para Budva", detail: "Chegar ao ponto às 19:00", state: "critical" }
]} />
```

Keep it on the page background. If an item needs a card, it is a Critical Item or an Agora card, not a timeline row.
