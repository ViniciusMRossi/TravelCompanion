import * as React from "react";

/** "Vista hoje" / "Leve na mochila" — functional, not fashion. */
export interface TcOutfitCardProps extends React.HTMLAttributes<HTMLDivElement> {
  wear?: string[];
  carry?: string[];
  /** Why the recommendation changed (altitude, wind, rain). */
  note?: string;
  /** Top divider — on when it sits under TcWeatherSummary. */
  divider?: boolean;
}

export function TcOutfitCard(props: TcOutfitCardProps): React.JSX.Element;
