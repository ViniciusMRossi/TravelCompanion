import React from "react";

/**
 * One day-timeline row. Grid 58px / 18px / 1fr, gap 12px, min-height 86px,
 * 12px dot with a 3px surface ring (gallery values).
 */
export function TcTimelineItem({
  time,
  title,
  detail,
  state = "upcoming",
  isLast = false,
  trailing,
  onClick,
  style,
  ...rest
}) {
  const dotColor = {
    completed: "var(--tc-neutral-400)",
    active: "var(--tc-primary-bg)",
    upcoming: "var(--tc-neutral-400)",
    critical: "var(--tc-critical-bg)"
  }[state];
  const completed = state === "completed";
  return (
    <div
      onClick={onClick}
      style={{
        display: "grid",
        gridTemplateColumns: "58px 18px 1fr",
        gap: "12px",
        minHeight: "86px",
        cursor: onClick ? "pointer" : "default",
        opacity: completed ? 0.6 : 1,
        ...style
      }}
      {...rest}
    >
      <div
        className="tc-tabular"
        style={{
          fontWeight: "var(--tc-weight-bold)",
          fontSize: "var(--tc-label-size)",
          paddingTop: "2px",
          color: state === "critical" ? "var(--tc-critical-bg)" : "var(--tc-text-primary)"
        }}
      >
        {time}
      </div>
      <div style={{ position: "relative", display: "flex", justifyContent: "center" }}>
        {!isLast ? (
          <span
            aria-hidden="true"
            style={{ position: "absolute", top: "18px", bottom: "-8px", width: "2px", background: "var(--tc-border-default)" }}
          />
        ) : null}
        <span
          aria-hidden="true"
          style={{
            marginTop: "4px",
            width: "12px",
            height: "12px",
            borderRadius: "var(--tc-radius-pill)",
            background: dotColor,
            zIndex: 1,
            border: "3px solid var(--tc-bg-surface)",
            boxSizing: "content-box"
          }}
        />
      </div>
      <div>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: "8px" }}>
          <div style={{ fontWeight: "var(--tc-weight-bold)", marginBottom: "4px", fontSize: "var(--tc-body-size)", lineHeight: "var(--tc-body-line)" }}>
            {title}
          </div>
          {trailing}
        </div>
        {detail ? (
          <div style={{ fontSize: "var(--tc-body-small-size)", color: "var(--tc-text-secondary)", lineHeight: 1.45 }}>{detail}</div>
        ) : null}
      </div>
    </div>
  );
}
