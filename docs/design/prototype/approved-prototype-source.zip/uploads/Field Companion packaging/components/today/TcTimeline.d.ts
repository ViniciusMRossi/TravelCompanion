import * as React from "react";
import { TcTimelineItemProps } from "./TcTimelineItem";

/**
 * Day timeline container.
 * @startingPoint section="Hoje" subtitle="Scannable day timeline with states" viewport="700x380"
 */
export interface TcTimelineProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Rows in chronological order; the last one loses its connector automatically. */
  items?: (TcTimelineItemProps & { id?: string })[];
  children?: React.ReactNode;
}

export function TcTimeline(props: TcTimelineProps): React.JSX.Element;
