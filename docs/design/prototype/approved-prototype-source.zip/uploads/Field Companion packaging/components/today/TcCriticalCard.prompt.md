Critical Item — deadline plus consequence plus immediate actions. Impossible to miss, but rare.

```jsx
<TcCriticalCard
  time="19:30"
  title="Ônibus para Budva"
  reason="Esteja no ponto até 19:00. Leve o passaporte e deixe o bilhete aberto offline."
/>
```

Icon + text always (never colour alone). Do not use it for ordinary errors that don't endanger the trip.
