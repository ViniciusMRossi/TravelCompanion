import React from "react";
import { TcChip } from "../core/TcChip.jsx";

/**
 * Compact weather block with explicit freshness. Never presents planning data
 * as a live forecast.
 */
export function TcWeatherSummary({
  temperature,
  condition,
  range,
  rain,
  freshness = "live",
  freshnessLabel,
  children,
  style,
  ...rest
}) {
  const chip = {
    live: { tone: "primary", label: freshnessLabel || "Atualizado há 24 min" },
    stale: { tone: "warning", label: freshnessLabel || "Última previsão às 08:14" },
    planning: { tone: "neutral", label: freshnessLabel || "Planejamento climático · não é previsão ao vivo" }
  }[freshness];
  return (
    <div style={style} {...rest}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "16px" }}>
        <div>
          <div className="tc-tabular" style={{ fontSize: "44px", fontWeight: "var(--tc-weight-bold)", lineHeight: 1 }}>
            {temperature}
          </div>
          <div style={{ color: "var(--tc-text-secondary)", marginTop: "5px", fontSize: "var(--tc-body-size)" }}>
            {[condition, rain ? "chuva " + rain : null].filter(Boolean).join(" · ")}
          </div>
          {range ? (
            <div className="tc-tabular" style={{ color: "var(--tc-text-tertiary)", marginTop: "4px", fontSize: "var(--tc-body-small-size)" }}>
              {range}
            </div>
          ) : null}
        </div>
        <TcChip tone={chip.tone}>{chip.label}</TcChip>
      </div>
      {children}
    </div>
  );
}
