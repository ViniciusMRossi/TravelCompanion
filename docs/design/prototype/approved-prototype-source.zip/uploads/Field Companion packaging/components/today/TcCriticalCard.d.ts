import * as React from "react";

/**
 * Critical Item card. Critical is an extra dimension over booking status —
 * a "Confirmado" transport can still be critical.
 * @startingPoint section="Hoje" subtitle="Não pode dar errado deadline card" viewport="700x300"
 */
export interface TcCriticalCardProps extends React.HTMLAttributes<HTMLElement> {
  /** Defaults to the approved label "Não pode dar errado". */
  label?: string;
  /** The deadline, always visible without opening details. */
  time?: string;
  title: string;
  /** Concrete consequence, literal and unambiguous. */
  reason?: string;
  actions?: React.ReactNode;
  /** Material Symbols Rounded ligature name. */
  icon?: string;
}

export function TcCriticalCard(props: TcCriticalCardProps): React.JSX.Element;
