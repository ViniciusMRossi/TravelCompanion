import * as React from "react";

/**
 * The "Agora" card — dominates Hoje visually and promotes the single most
 * useful action for the current moment.
 * @startingPoint section="Hoje" subtitle="Agora card on ink with halo" viewport="700x300"
 */
export interface TcNowCardProps extends React.HTMLAttributes<HTMLElement> {
  /** Eyebrow. Defaults to "Agora"; derived from `state` when state is not inProgress. */
  label?: string;
  time?: string;
  title: string;
  description?: string;
  /** Secondary operational line (e.g. "Audioguia disponível offline"). */
  meta?: string;
  state?: "upcoming" | "starting" | "inProgress" | "completed";
  /** TcButton nodes with onInk. Defaults to Ver atração + Abrir no Maps. */
  actions?: React.ReactNode;
}

export function TcNowCard(props: TcNowCardProps): React.JSX.Element;
