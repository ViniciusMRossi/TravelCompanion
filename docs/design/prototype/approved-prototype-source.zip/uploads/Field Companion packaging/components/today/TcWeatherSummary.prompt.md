Weather for Hoje — big temperature, one condition line, freshness chip.

```jsx
<TcWeatherSummary temperature="26°" condition="Ensolarado" rain="10%" freshness="live" />
```

`freshness="planning"` when there is no live data: the label must say it is not a live forecast.
