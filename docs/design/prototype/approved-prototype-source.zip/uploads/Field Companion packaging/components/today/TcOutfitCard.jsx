import React from "react";

/**
 * Functional packing advice — "Vista" / "Leve". Plain categorised lists,
 * no fashion styling.
 */
export function TcOutfitCard({ wear = [], carry = [], note, divider = true, style, ...rest }) {
  const group = (title, items) =>
    items && items.length ? (
      <>
        <h3 style={{ margin: "0 0 6px", fontSize: "var(--tc-heading-3-size)", lineHeight: "var(--tc-heading-3-line)", fontWeight: "var(--tc-weight-medium)" }}>
          {title}
        </h3>
        <p style={{ color: "var(--tc-text-secondary)", lineHeight: 1.55, margin: 0, fontSize: "var(--tc-body-size)" }}>
          {items.join(" · ")}
        </p>
      </>
    ) : null;
  return (
    <div
      style={{
        borderTop: divider ? "1px solid var(--tc-border-default)" : "none",
        marginTop: divider ? "18px" : 0,
        paddingTop: divider ? "16px" : 0,
        ...style
      }}
      {...rest}
    >
      {group("Vista hoje", wear)}
      {carry && carry.length ? <div style={{ marginTop: "16px" }}>{group("Leve na mochila", carry)}</div> : null}
      {note ? (
        <p style={{ color: "var(--tc-text-tertiary)", fontSize: "var(--tc-body-small-size)", margin: "12px 0 0" }}>{note}</p>
      ) : null}
    </div>
  );
}
