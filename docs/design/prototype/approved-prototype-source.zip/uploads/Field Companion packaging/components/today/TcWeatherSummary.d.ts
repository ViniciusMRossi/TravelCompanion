import * as React from "react";

/** Compact weather with mandatory freshness signalling. */
export interface TcWeatherSummaryProps extends React.HTMLAttributes<HTMLDivElement> {
  /** e.g. "26°" */
  temperature: string;
  /** e.g. "Ensolarado" */
  condition?: string;
  /** min/max, e.g. "18° / 27°" */
  range?: string;
  /** e.g. "10%" */
  rain?: string;
  freshness?: "live" | "stale" | "planning";
  freshnessLabel?: string;
  /** Usually a TcOutfitCard below the divider. */
  children?: React.ReactNode;
}

export function TcWeatherSummary(props: TcWeatherSummaryProps): React.JSX.Element;
