Outfit advice under the weather block.

```jsx
<TcOutfitCard wear={["Camiseta", "shorts", "tênis confortável", "protetor solar"]} carry={["Repelente", "água", "powerbank"]} />
```

Words are lowercase after the first item, separated by "·". No imagery, no fashion treatment.
