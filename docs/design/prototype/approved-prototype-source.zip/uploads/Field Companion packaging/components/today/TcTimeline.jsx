import React from "react";
import { TcTimelineItem } from "./TcTimelineItem.jsx";

/**
 * The day timeline. Scannable list, not a stack of cards: it renders on the
 * page surface with no background per item.
 */
export function TcTimeline({ items = [], children, style, ...rest }) {
  return (
    <div style={{ padding: "4px 0", ...style }} {...rest}>
      {items.map((it, i) => (
        <TcTimelineItem key={it.id || i} {...it} isLast={i === items.length - 1 && !children} />
      ))}
      {children}
    </div>
  );
}
