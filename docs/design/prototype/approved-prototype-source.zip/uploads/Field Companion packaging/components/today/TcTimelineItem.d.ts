import * as React from "react";

/** A single row of the day timeline. Rendered inside TcTimeline. */
export interface TcTimelineItemProps extends React.HTMLAttributes<HTMLDivElement> {
  time: string;
  title: string;
  /** "Atração · audioguia disponível" — category first, then the operational fact. */
  detail?: string;
  state?: "completed" | "active" | "upcoming" | "critical";
  /** Hides the connector line; TcTimeline sets it on the last child. */
  isLast?: boolean;
  /** Chip or icon aligned to the title row. */
  trailing?: React.ReactNode;
}

export function TcTimelineItem(props: TcTimelineItemProps): React.JSX.Element;
