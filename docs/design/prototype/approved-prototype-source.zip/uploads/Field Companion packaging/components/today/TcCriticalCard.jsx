import React from "react";
import { TcButton } from "../core/TcButton.jsx";

/**
 * Critical Item — "Não pode dar errado". 14px radius, 1px critical border,
 * 5px oxblood left accent, subtle critical background (gallery values).
 */
export function TcCriticalCard({
  label = "Não pode dar errado",
  time,
  title,
  reason,
  actions,
  icon = "priority_high",
  style,
  ...rest
}) {
  return (
    <section
      style={{
        borderRadius: "var(--tc-radius-md)",
        border: "1px solid var(--tc-critical-border)",
        borderLeft: "5px solid var(--tc-critical-bg)",
        background: "var(--tc-critical-subtle-bg)",
        padding: "18px",
        ...style
      }}
      {...rest}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "6px",
          fontSize: "var(--tc-label-small-size)",
          fontWeight: "var(--tc-weight-bold)",
          color: "var(--tc-critical-bg)",
          textTransform: "uppercase",
          letterSpacing: "var(--tc-label-tracking)"
        }}
      >
        <span className="tc-icon tc-icon-18" aria-hidden="true">{icon}</span>
        {label}
      </div>
      {time ? (
        <div className="tc-tabular" style={{ fontSize: "var(--tc-heading-2-size)", fontWeight: "var(--tc-weight-bold)", margin: "7px 0 3px", color: "var(--tc-text-primary)" }}>
          {time}
        </div>
      ) : null}
      <h3 style={{ margin: "0 0 6px", fontSize: "var(--tc-heading-3-size)", lineHeight: "var(--tc-heading-3-line)", fontWeight: "var(--tc-weight-bold)", color: "var(--tc-text-primary)" }}>
        {title}
      </h3>
      {reason ? (
        <p style={{ color: "var(--tc-critical-text)", margin: "0 0 14px", fontSize: "var(--tc-body-size)", lineHeight: "var(--tc-body-line)" }}>{reason}</p>
      ) : null}
      <div style={{ display: "flex", flexWrap: "wrap", gap: "10px" }}>
        {actions || (
          <>
            <TcButton variant="primary">Mostrar passagem</TcButton>
            <TcButton variant="secondary">Maps</TcButton>
          </>
        )}
      </div>
    </section>
  );
}
