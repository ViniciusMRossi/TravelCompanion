"Agora" card — one per Hoje screen, at the top, visually louder than everything except a Critical Item.

```jsx
<TcNowCard
  time="08:30"
  title="Butrinto"
  description="Cidade arqueológica, Patrimônio Mundial. Reserve cerca de 2h30 para o percurso principal."
  actions={<><TcButton variant="primary" onInk compact>Ver atração</TcButton><TcButton variant="secondary" onInk compact>Abrir no Maps</TcButton></>}
/>
```

Time is Roboto Bold 34/1 on ink. Never put editorial prose here, and never more than two actions.
