One timeline row: fixed 58px time column, connector, 12px state dot.

```jsx
<TcTimelineItem time="08:30" title="Butrinto" detail="Atração · audioguia disponível" state="active" />
```

Critical items carry an icon or chip in `trailing` too — the oxblood dot alone must not be the only signal.
