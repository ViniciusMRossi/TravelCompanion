import React from "react";
import { TcButton } from "../core/TcButton.jsx";

/**
 * "Agora" — the strongest operational element on Hoje. Ink surface, teal halo,
 * 22px padding, 20px radius (gallery values). Must answer what / where /
 * until when, plus one primary action.
 */
export function TcNowCard({
  label = "Agora",
  time,
  title,
  description,
  meta,
  state = "inProgress",
  actions,
  style,
  ...rest
}) {
  const stateLabel = {
    upcoming: "Em breve",
    starting: "Começando",
    inProgress: "Agora",
    completed: "Concluído"
  }[state];
  return (
    <section
      style={{
        padding: "22px",
        borderRadius: "var(--tc-radius-lg)",
        background: "var(--tc-bg-inverse)",
        color: "var(--tc-on-ink-primary)",
        position: "relative",
        overflow: "hidden",
        ...style
      }}
      {...rest}
    >
      <span
        aria-hidden="true"
        style={{
          content: "''",
          position: "absolute",
          width: "170px",
          height: "170px",
          borderRadius: "var(--tc-radius-pill)",
          right: "-60px",
          top: "-80px",
          background: "var(--tc-ink-halo)"
        }}
      />
      <div
        style={{
          fontSize: "var(--tc-label-small-size)",
          color: "var(--tc-on-ink-label)",
          fontWeight: "var(--tc-weight-bold)",
          textTransform: "uppercase",
          letterSpacing: "var(--tc-label-tracking)",
          position: "relative",
          zIndex: 2
        }}
      >
        {label === "Agora" && state !== "inProgress" ? stateLabel : label}
        {time ? " · " + time : null}
      </div>
      {time ? (
        <div
          className="tc-tabular"
          style={{ fontSize: "34px", lineHeight: 1, fontWeight: "var(--tc-weight-bold)", margin: "9px 0", position: "relative", zIndex: 2 }}
        >
          {time}
        </div>
      ) : null}
      <h2 style={{ fontSize: "var(--tc-heading-2-size)", lineHeight: "var(--tc-heading-2-line)", fontWeight: "var(--tc-weight-bold)", margin: "0 0 7px", position: "relative", zIndex: 2 }}>
        {title}
      </h2>
      {description ? (
        <p style={{ color: "var(--tc-on-ink-secondary)", margin: "0 0 14px", maxWidth: "480px", fontSize: "var(--tc-body-size)", lineHeight: "var(--tc-body-line)", position: "relative", zIndex: 2 }}>
          {description}
        </p>
      ) : null}
      {meta ? (
        <div style={{ color: "var(--tc-on-ink-muted)", fontSize: "13px", margin: "0 0 14px", position: "relative", zIndex: 2 }}>{meta}</div>
      ) : null}
      <div style={{ display: "flex", flexWrap: "wrap", gap: "8px", position: "relative", zIndex: 2 }}>
        {actions || (
          <>
            <TcButton variant="primary" onInk compact>Ver atração</TcButton>
            <TcButton variant="secondary" onInk compact>Abrir no Maps</TcButton>
          </>
        )}
      </div>
    </section>
  );
}
