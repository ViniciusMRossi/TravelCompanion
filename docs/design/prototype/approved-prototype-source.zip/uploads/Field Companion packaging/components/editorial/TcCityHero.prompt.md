City hero — the one place a 40px Fraunces title is expected.

```jsx
<TcCityHero city="Sarajevo" country="Bósnia e Herzegovina 🇧🇦" dates="18–20 de setembro" />
```

Never put operational text (times, gate, ticket data) on the image. Omit `image` and the placeholder is labelled — do not fake photography.
