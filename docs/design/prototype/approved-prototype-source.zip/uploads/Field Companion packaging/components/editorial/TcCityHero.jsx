import React from "react";

const CITY_PLACEHOLDER =
  "linear-gradient(to top, rgba(22,35,46,.7), rgba(22,35,46,.05)), linear-gradient(135deg, #89A7A5, #D2C6A8 46%, #728B85)";

/**
 * City hero. Editorial surface: photography, Fraunces display title, location line.
 * The handoff package ships no photography, so when `image` is omitted the
 * approved gallery placeholder gradient is used and labelled as a placeholder.
 */
export function TcCityHero({
  city,
  country,
  dates,
  image,
  imageNote = "foto da cidade",
  overline,
  height = 300,
  actions,
  radius = "var(--tc-radius-hero)",
  style,
  ...rest
}) {
  const bg = image
    ? "linear-gradient(to top, rgba(22,35,46,.7), rgba(22,35,46,.05)), url(" + image + ")"
    : CITY_PLACEHOLDER;
  return (
    <section
      style={{
        position: "relative",
        overflow: "hidden",
        borderRadius: radius,
        minHeight: height + "px",
        display: "flex",
        alignItems: "flex-end",
        padding: "20px",
        color: "var(--tc-on-ink-primary)",
        backgroundImage: bg,
        backgroundSize: "cover",
        backgroundPosition: "center",
        ...style
      }}
      {...rest}
    >
      {!image ? (
        <span
          style={{
            position: "absolute",
            top: "12px",
            left: "16px",
            fontFamily: "var(--tc-font-mono)",
            fontSize: "11px",
            letterSpacing: ".04em",
            padding: "4px 7px",
            borderRadius: "var(--tc-radius-xs)",
            background: "rgba(22,35,46,.42)",
            color: "#F2EFE7"
          }}
        >
          {imageNote}
        </span>
      ) : null}
      <div>
        {overline || country ? (
          <div
            style={{
              fontSize: "var(--tc-label-small-size)",
              opacity: 0.85,
              textTransform: "uppercase",
              letterSpacing: "var(--tc-label-tracking)",
              fontWeight: "var(--tc-weight-bold)"
            }}
          >
            {overline || country}
          </div>
        ) : null}
        <h1
          className="tc-display"
          style={{ fontSize: "var(--tc-display-large-size)", lineHeight: "var(--tc-display-large-line)", margin: "6px 0 4px" }}
        >
          {city}
        </h1>
        {dates ? <div style={{ fontSize: "var(--tc-body-small-size)", opacity: 0.9 }}>{dates}</div> : null}
        {actions ? <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginTop: "14px" }}>{actions}</div> : null}
      </div>
    </section>
  );
}
