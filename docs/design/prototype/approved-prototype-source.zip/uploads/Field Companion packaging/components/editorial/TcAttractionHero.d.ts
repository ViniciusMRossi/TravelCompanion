import * as React from "react";

/**
 * Attraction hero/card: imagery on top, editorial lead and quick actions below.
 * @startingPoint section="Explorar" subtitle="Attraction card with audioguia and Maps actions" viewport="412x420"
 */
export interface TcAttractionHeroProps extends React.HTMLAttributes<HTMLElement> {
  name: string;
  /** "MOSTAR · BÓSNIA E HERZEGOVINA" */
  location?: string;
  /** "Patrimônio Mundial · ~1h30" */
  meta?: string;
  lead?: string;
  image?: string;
  imageNote?: string;
  actions?: React.ReactNode;
  children?: React.ReactNode;
  /** "card" inside lists, "bleed" at the top of the Atração screen. */
  variant?: "card" | "bleed";
}

export function TcAttractionHero(props: TcAttractionHeroProps): React.JSX.Element;
