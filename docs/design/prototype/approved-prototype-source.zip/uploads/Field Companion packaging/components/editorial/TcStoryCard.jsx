import React from "react";
import { TcChip } from "../core/TcChip.jsx";
import { TcButton } from "../core/TcButton.jsx";

/** Small editorial unit: title, hook, listen/read. Used for stories along the way. */
export function TcStoryCard({
  title,
  hook,
  chip = "História pelo caminho",
  distance,
  onListen,
  onRead,
  tone = "surface",
  style,
  ...rest
}) {
  const ink = tone === "ink";
  return (
    <article
      style={{
        background: ink ? "var(--tc-bg-inverse)" : "var(--tc-bg-surface)",
        color: ink ? "var(--tc-on-ink-primary)" : "var(--tc-text-primary)",
        border: ink ? "none" : "1px solid var(--tc-border-default)",
        borderRadius: "var(--tc-radius-md)",
        padding: "18px",
        ...style
      }}
      {...rest}
    >
      {chip ? <TcChip tone="primary">{chip}</TcChip> : null}
      <h3 style={{ margin: "14px 0 6px", fontSize: "var(--tc-heading-3-size)", lineHeight: "var(--tc-heading-3-line)", fontWeight: "var(--tc-weight-medium)" }}>
        {title}
      </h3>
      {hook ? (
        <p style={{ color: ink ? "var(--tc-on-ink-secondary)" : "var(--tc-text-secondary)", lineHeight: 1.5, margin: "0 0 14px", fontSize: "var(--tc-body-size)" }}>
          {hook}
        </p>
      ) : null}
      {distance ? (
        <div style={{ fontSize: "var(--tc-body-small-size)", color: ink ? "var(--tc-on-ink-muted)" : "var(--tc-text-tertiary)", marginBottom: "14px" }}>
          {distance}
        </div>
      ) : null}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
        <TcButton variant="tonal" icon="▶" onInk={ink} onClick={onListen}>Ouvir</TcButton>
        <TcButton variant="secondary" onInk={ink} onClick={onRead}>Ler</TcButton>
      </div>
    </article>
  );
}
