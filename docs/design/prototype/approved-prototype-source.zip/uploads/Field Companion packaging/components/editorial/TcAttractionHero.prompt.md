Attraction hero — used both as a list card and as the top of the Atração screen.

```jsx
<TcAttractionHero
  name="Stari Most"
  location="MOSTAR · BÓSNIA E HERZEGOVINA"
  meta="Patrimônio Mundial · ~1h30"
  lead="A ponte otomana é o símbolo mais conhecido de Mostar."
  actions={<><TcButton variant="tonal" icon="🎧">Ouvir audioguia</TcButton><TcButton variant="secondary">Abrir no Maps</TcButton></>}
/>
```

Practical facts (opening hours, ticket price) go in a TcCard below, never inside the editorial paragraph.
