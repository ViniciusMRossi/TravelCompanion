import * as React from "react";

/** Story along the way — title, hook, Ouvir/Ler. */
export interface TcStoryCardProps extends React.HTMLAttributes<HTMLElement> {
  title: string;
  hook?: string;
  /** Defaults to the approved label "História pelo caminho"; pass null to hide. */
  chip?: string | null;
  /** "~180 m à frente" */
  distance?: string;
  onListen?: () => void;
  onRead?: () => void;
  /** "ink" when it appears over Walk Mode surfaces. */
  tone?: "surface" | "ink";
}

export function TcStoryCard(props: TcStoryCardProps): React.JSX.Element;
