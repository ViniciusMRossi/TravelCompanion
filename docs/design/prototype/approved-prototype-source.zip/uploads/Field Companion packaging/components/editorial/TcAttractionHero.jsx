import React from "react";

const ATTRACTION_PLACEHOLDER =
  "linear-gradient(to top, rgba(22,35,46,.7), rgba(22,35,46,.05)), linear-gradient(135deg, #89A7A5, #D2C6A8 46%, #728B85)";

/**
 * Attraction card / hero: image block (min-height 190px, 20px padding),
 * then an 18px body with lead copy and quick actions. Gallery geometry.
 */
export function TcAttractionHero({
  name,
  location,
  meta,
  lead,
  image,
  imageNote = "foto da atração",
  actions,
  children,
  variant = "card",
  style,
  ...rest
}) {
  const bg = image
    ? "linear-gradient(to top, rgba(22,35,46,.7), rgba(22,35,46,.05)), url(" + image + ")"
    : ATTRACTION_PLACEHOLDER;
  return (
    <article
      style={{
        background: "var(--tc-bg-surface)",
        border: variant === "card" ? "1px solid var(--tc-border-default)" : "none",
        borderRadius: "var(--tc-radius-hero)",
        overflow: "hidden",
        boxShadow: variant === "card" ? "var(--tc-shadow-card-hairline)" : "none",
        ...style
      }}
      {...rest}
    >
      <div
        style={{
          position: "relative",
          minHeight: "190px",
          padding: "20px",
          display: "flex",
          alignItems: "flex-end",
          backgroundImage: bg,
          backgroundSize: "cover",
          backgroundPosition: "center",
          color: "var(--tc-on-ink-primary)"
        }}
      >
        {!image ? (
          <span
            style={{
              position: "absolute",
              top: "12px",
              left: "16px",
              fontFamily: "var(--tc-font-mono)",
              fontSize: "11px",
              padding: "4px 7px",
              borderRadius: "var(--tc-radius-xs)",
              background: "rgba(22,35,46,.42)",
              color: "#F2EFE7"
            }}
          >
            {imageNote}
          </span>
        ) : null}
        <div>
          {location ? <div style={{ fontSize: "var(--tc-label-small-size)", opacity: 0.8, textTransform: "uppercase", letterSpacing: "var(--tc-label-tracking)" }}>{location}</div> : null}
          <h3 className="tc-display" style={{ fontSize: "30px", margin: "4px 0", lineHeight: 1.1 }}>{name}</h3>
          {meta ? <div style={{ fontSize: "var(--tc-body-small-size)" }}>{meta}</div> : null}
        </div>
      </div>
      <div style={{ padding: "18px" }}>
        {lead ? (
          <p style={{ fontSize: "var(--tc-body-small-size)", color: "var(--tc-text-secondary)", lineHeight: 1.5, margin: "0 0 14px" }}>{lead}</p>
        ) : null}
        {children}
        {actions ? <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>{actions}</div> : null}
      </div>
    </article>
  );
}
