Story card — the unit behind "histórias pelo caminho" and city chapter lists.

```jsx
<TcStoryCard
  title="Onde Oriente e Ocidente se encontram"
  hook="Vocês estão chegando a um ponto onde a arquitetura otomana encontra a austro-húngara."
  distance="~180 m à frente"
/>
```

Always offer both Ouvir and Ler — audio is primary but never the only route.
