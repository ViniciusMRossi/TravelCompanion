import * as React from "react";

/**
 * Full-bleed city hero for the Cidade screen.
 * @startingPoint section="Explorar" subtitle="City hero with Fraunces display title" viewport="412x340"
 */
export interface TcCityHeroProps extends React.HTMLAttributes<HTMLElement> {
  city: string;
  /** "Bósnia e Herzegovina 🇧🇦" — flag optional, never the only identifier. */
  country?: string;
  /** Stay period, e.g. "18–20 de setembro". */
  dates?: string;
  /** Photo URL. Omit to render the labelled placeholder. */
  image?: string;
  /** Placeholder caption shown when `image` is absent. */
  imageNote?: string;
  overline?: string;
  height?: number;
  actions?: React.ReactNode;
  radius?: string;
}

export function TcCityHero(props: TcCityHeroProps): React.JSX.Element;
