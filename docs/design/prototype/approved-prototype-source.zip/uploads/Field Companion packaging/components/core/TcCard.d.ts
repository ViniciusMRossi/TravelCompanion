import * as React from "react";

/** Base operational card. Prefer a semantic card (TcTransportCard, …) when one exists. */
export interface TcCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  tone?: "surface" | "flat" | "subtle" | "ink";
  /** Default 18px. Use 20px for editorial bodies, 16px for dense rows. */
  padding?: string;
  /** Default radius-md (14px). Hero surfaces use radius-lg / radius-xl. */
  radius?: string;
}

export function TcCard(props: TcCardProps): React.JSX.Element;
