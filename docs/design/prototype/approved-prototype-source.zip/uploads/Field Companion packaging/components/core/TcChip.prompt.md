Pill metadata label — 12px Roboto Bold, 7px/10px padding, pill radius.

```jsx
<TcChip tone="primary">Audioguia</TcChip>
<TcChip tone="neutral">Offline</TcChip>
```

Use for category/status words, never sentences; at most three in one card. For booking and trip state prefer TcStatusChip, which fixes the tone-to-status mapping.
