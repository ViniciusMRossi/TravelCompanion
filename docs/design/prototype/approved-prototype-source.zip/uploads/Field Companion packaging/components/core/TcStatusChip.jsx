import React from "react";
import { TcChip } from "./TcChip.jsx";

/** Travel status taxonomy — the label/tone pairing is part of the system. */
const STATUS = {
  confirmed: { tone: "success", label: "Confirmado" },
  paid: { tone: "success", label: "Pago" },
  booked: { tone: "success", label: "Reservado" },
  issued: { tone: "success", label: "Emitido" },
  included: { tone: "primary", label: "Incluído" },
  buy: { tone: "warning", label: "Comprar" },
  verify: { tone: "warning", label: "Verificar" },
  critical: { tone: "critical", label: "Crítico" },
  offline: { tone: "neutral", label: "Offline" },
  synchronized: { tone: "success", label: "Sincronizado" },
  connecting: { tone: "warning", label: "Conectando" },
  resyncing: { tone: "warning", label: "Sincronizando novamente" },
  recording: { tone: "critical", label: "Gravando" }
};

export function TcStatusChip({ status = "confirmed", label, dot = true, style, ...rest }) {
  const s = STATUS[status] || STATUS.confirmed;
  return (
    <TcChip tone={s.tone} dot={dot && status !== "offline"} style={style} {...rest}>
      {label || s.label}
    </TcChip>
  );
}

export const TC_STATUSES = STATUS;
