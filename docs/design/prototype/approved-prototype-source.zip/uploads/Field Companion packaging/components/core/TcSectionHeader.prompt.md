Section opener used on every long screen (Cidade, Atração, Dia completo).

```jsx
<TcSectionHeader eyebrow="Explorar" title="Atrações" action={<TcButton variant="text">Ver todas</TcButton>} />
```

The eyebrow is teal, uppercase, 12px, .12em tracking. Titles stay in Roboto — Fraunces belongs to hero/editorial titles only.
