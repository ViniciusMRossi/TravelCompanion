Icon-only control for app-bar and player actions — 48px default touch target, circle by default.

```jsx
<TcIconButton icon={<span className="tc-icon tc-icon-24">arrow_back</span>} label="Voltar" variant="ghost" />
<TcIconButton icon="▶" label="Ouvir" variant="primary" size="audio" />
```

Never use an icon button alone for a critical action — critical actions carry icon + text.
