import React from "react";

/**
 * Offline / stale-data status. Offline is a normal mode, not an error:
 * this is a quiet inline line, never a permanent red banner.
 */
const MODES = {
  online: { dot: "var(--tc-participant-synchronized)", text: "Online · conteúdo atualizado" },
  offlineAvailable: { dot: "var(--tc-status-offline)", text: "Offline · conteúdo disponível" },
  weatherStale: { dot: "var(--tc-status-verify)", text: "Sem internet · previsão não atualizada" },
  syncUnavailable: { dot: "var(--tc-status-verify)", text: "Sincronização indisponível · áudio local continua" }
};

export function TcOfflineStatus({ mode = "offlineAvailable", label, variant = "inline", style, ...rest }) {
  const m = MODES[mode] || MODES.offlineAvailable;
  const chip = variant === "chip";
  return (
    <div
      role="status"
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "8px",
        fontFamily: "var(--tc-font-ui)",
        fontSize: chip ? "var(--tc-label-small-size)" : "13px",
        lineHeight: chip ? "var(--tc-label-small-line)" : "18px",
        fontWeight: chip ? "var(--tc-weight-bold)" : "var(--tc-weight-medium)",
        color: chip ? "var(--tc-neutral-700)" : "var(--tc-text-secondary)",
        background: chip ? "var(--tc-bg-subtle)" : "transparent",
        padding: chip ? "7px 10px" : 0,
        borderRadius: chip ? "var(--tc-radius-pill)" : 0,
        ...style
      }}
      {...rest}
    >
      <span
        aria-hidden="true"
        style={{ width: "8px", height: "8px", borderRadius: "var(--tc-radius-pill)", background: m.dot, flex: "0 0 auto" }}
      />
      {label || m.text}
    </div>
  );
}
