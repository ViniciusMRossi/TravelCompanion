import * as React from "react";

export type TcStatus =
  | "confirmed" | "paid" | "booked" | "issued"
  | "included" | "buy" | "verify" | "critical" | "offline"
  | "synchronized" | "connecting" | "resyncing" | "recording";

/**
 * Booking / transport / group state chip with the approved pt-BR wording baked in.
 * Critical is an ADDITIONAL dimension: an item can be "Confirmado" and critical
 * at the same time — render both chips.
 */
export interface TcStatusChipProps extends React.HTMLAttributes<HTMLSpanElement> {
  status?: TcStatus;
  /** Override only when the trip content uses different approved wording. */
  label?: string;
  dot?: boolean;
}

export function TcStatusChip(props: TcStatusChipProps): React.JSX.Element;
export const TC_STATUSES: Record<TcStatus, { tone: string; label: string }>;
