Field Companion action button — use for every tappable action; 52px tall (44px with `compact`), 14px radius, Roboto Medium.

```jsx
<TcButton variant="primary">Mostrar passagem</TcButton>
<TcButton variant="secondary">Abrir no Maps</TcButton>
<TcButton variant="tonal" icon="🎧">Ouvir audioguia</TcButton>
<TcButton variant="critical">Ligar 112</TcButton>
<TcButton variant="text">Ver detalhes</TcButton>
```

Rules: one `primary` per decision surface; `critical` only for real urgency (emergency call, destructive); `onInk` on TcNowCard / TcWalkProgress / TcEmergencyAction surfaces; never set Fraunces on a button.
