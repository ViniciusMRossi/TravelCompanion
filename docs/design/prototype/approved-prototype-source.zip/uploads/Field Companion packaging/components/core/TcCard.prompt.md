Plain operational card — the fallback container when no semantic card fits.

```jsx
<TcCard>
  <h3>Instruções de chegada</h3>
  <p>Portão azul à direita do mercado.</p>
</TcCard>
```

Never nest TcCard inside TcCard, and never wrap every timeline item in one.
