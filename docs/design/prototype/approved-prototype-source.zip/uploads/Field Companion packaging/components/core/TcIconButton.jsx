import React from "react";

/**
 * Circular or squared icon-only control. 48px is the minimum touch target;
 * the 46px teal circle from the gallery's audio player is available as size="audio".
 */
export function TcIconButton({
  icon,
  label,
  variant = "surface",
  size = "default",
  shape = "circle",
  disabled = false,
  onInk = false,
  style,
  ...rest
}) {
  const dims = { compact: 40, default: 48, audio: 46, hero: 56 }[size] || 48;
  const variants = {
    surface: {
      background: "var(--tc-bg-surface)",
      color: "var(--tc-text-primary)",
      border: "1px solid var(--tc-border-strong)"
    },
    primary: { background: "var(--tc-primary-bg)", color: "var(--tc-primary-fg)", border: 0 },
    tonal: { background: "var(--tc-primary-subtle-bg)", color: "var(--tc-primary-subtle-fg)", border: 0 },
    critical: { background: "var(--tc-critical-bg)", color: "var(--tc-critical-fg)", border: 0 },
    ghost: { background: "transparent", color: "var(--tc-text-primary)", border: 0 }
  };
  const onInkGhost = { background: "var(--tc-on-ink-fill)", color: "var(--tc-on-ink-primary)", border: "1px solid var(--tc-on-ink-border-soft)" };
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      style={{
        width: dims + "px",
        height: dims + "px",
        minWidth: dims + "px",
        display: "grid",
        placeItems: "center",
        padding: 0,
        cursor: disabled ? "default" : "pointer",
        borderRadius: shape === "circle" ? "var(--tc-radius-pill)" : "var(--tc-radius-md)",
        fontSize: size === "compact" ? "20px" : "24px",
        ...(onInk && variant === "ghost" ? onInkGhost : variants[variant] || variants.surface),
        ...(disabled ? { opacity: 0.42 } : null),
        ...style
      }}
      {...rest}
    >
      <span aria-hidden="true" style={{ display: "inline-flex", lineHeight: 1 }}>{icon}</span>
    </button>
  );
}
