Quiet connectivity/freshness line — put it next to the thing it affects.

```jsx
<TcOfflineStatus mode="offlineAvailable" />
<TcOfflineStatus mode="weatherStale" variant="chip" />
```

Never render it as a fixed red banner, and never say "erro". Say what still works.
