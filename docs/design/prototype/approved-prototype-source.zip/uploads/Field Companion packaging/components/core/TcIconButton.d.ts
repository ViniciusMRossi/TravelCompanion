import * as React from "react";

/** Icon-only control; always needs an accessible `label`. */
export interface TcIconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon: React.ReactNode;
  /** Content description — required, icons never ship without a label. */
  label: string;
  variant?: "surface" | "primary" | "tonal" | "critical" | "ghost";
  /** compact 40 · default 48 · audio 46 (gallery play button) · hero 56 */
  size?: "compact" | "default" | "audio" | "hero";
  shape?: "circle" | "squared";
  onInk?: boolean;
  disabled?: boolean;
}

export function TcIconButton(props: TcIconButtonProps): React.JSX.Element;
