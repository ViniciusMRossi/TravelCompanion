import * as React from "react";

/** Section opener: teal eyebrow, Roboto Bold 24 title, optional note and trailing action. */
export interface TcSectionHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  eyebrow?: string;
  title?: string;
  note?: string;
  /** Usually a TcButton variant="text". */
  action?: React.ReactNode;
  onInk?: boolean;
}

export function TcSectionHeader(props: TcSectionHeaderProps): React.JSX.Element;
