import React from "react";

const base = {
  border: 0,
  font: "inherit",
  fontFamily: "var(--tc-font-ui)",
  fontSize: "var(--tc-label-large-size)",
  lineHeight: "var(--tc-label-large-line)",
  fontWeight: "var(--tc-weight-medium)",
  cursor: "pointer",
  minHeight: "52px",
  padding: "0 18px",
  borderRadius: "var(--tc-radius-button)",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "8px",
  transition: "background var(--tc-motion-micro) var(--tc-motion-easing), opacity var(--tc-motion-micro) var(--tc-motion-easing)"
};

const variants = {
  primary: { background: "var(--tc-primary-bg)", color: "var(--tc-primary-fg)" },
  secondary: {
    background: "var(--tc-bg-surface)",
    color: "var(--tc-text-primary)",
    border: "1px solid var(--tc-border-strong)"
  },
  tonal: { background: "var(--tc-primary-subtle-bg)", color: "var(--tc-primary-subtle-fg)" },
  critical: { background: "var(--tc-critical-bg)", color: "var(--tc-critical-fg)" },
  text: {
    background: "transparent",
    color: "var(--tc-text-link)",
    padding: "0 8px",
    minHeight: "44px"
  }
};

const onInkVariants = {
  primary: { background: "var(--tc-on-ink-primary)", color: "var(--tc-ink)" },
  secondary: {
    background: "var(--tc-on-ink-fill)",
    color: "var(--tc-on-ink-primary)",
    border: "1px solid var(--tc-on-ink-border)"
  },
  tonal: { background: "var(--tc-on-ink-fill-strong)", color: "var(--tc-on-ink-primary)" },
  critical: { background: "var(--tc-critical-bg)", color: "var(--tc-critical-fg)" },
  text: { background: "transparent", color: "var(--tc-on-ink-primary)", padding: "0 8px", minHeight: "44px" }
};

/**
 * Primary / secondary / tonal / critical / text action.
 * Geometry is taken verbatim from the approved Component Gallery.
 */
export function TcButton({
  children,
  variant = "primary",
  icon,
  compact = false,
  full = false,
  onInk = false,
  disabled = false,
  loading = false,
  style,
  ...rest
}) {
  const v = (onInk ? onInkVariants : variants)[variant] || variants.primary;
  return (
    <button
      type="button"
      disabled={disabled || loading}
      style={{
        ...base,
        ...v,
        ...(compact ? { minHeight: "44px" } : null),
        ...(full ? { width: "100%" } : null),
        ...(disabled ? { opacity: 0.42, cursor: "default" } : null),
        ...style
      }}
      {...rest}
    >
      {icon ? <span aria-hidden="true" style={{ display: "inline-flex" }}>{icon}</span> : null}
      <span>{loading ? "Aguarde…" : children}</span>
    </button>
  );
}
