Status chip with the trip status taxonomy and its pt-BR labels fixed.

```jsx
<TcStatusChip status="confirmed" />
<TcStatusChip status="verify" />
<TcStatusChip status="critical" />
```

"Confirmado" and "Crítico" are not mutually exclusive — a booked bus with a boarding deadline shows both.
