import React from "react";

/** Eyebrow + title + optional note/action. Opens a section; never a card. */
export function TcSectionHeader({ eyebrow, title, note, action, onInk = false, style, ...rest }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "space-between",
        gap: "16px",
        marginBottom: "12px",
        ...style
      }}
      {...rest}
    >
      <div>
        {eyebrow ? (
          <div
            style={{
              fontFamily: "var(--tc-font-ui)",
              fontSize: "var(--tc-eyebrow-size)",
              fontWeight: "var(--tc-weight-bold)",
              letterSpacing: "var(--tc-eyebrow-tracking)",
              textTransform: "uppercase",
              color: onInk ? "var(--tc-on-ink-eyebrow)" : "var(--tc-teal)"
            }}
          >
            {eyebrow}
          </div>
        ) : null}
        {title ? (
          <h2
            style={{
              margin: eyebrow ? "6px 0 0" : 0,
              fontFamily: "var(--tc-font-ui)",
              fontSize: "var(--tc-heading-2-size)",
              lineHeight: "var(--tc-heading-2-line)",
              fontWeight: "var(--tc-weight-bold)",
              color: onInk ? "var(--tc-on-ink-primary)" : "var(--tc-text-primary)"
            }}
          >
            {title}
          </h2>
        ) : null}
        {note ? (
          <p
            style={{
              margin: "4px 0 0",
              fontSize: "var(--tc-body-small-size)",
              lineHeight: "var(--tc-body-small-line)",
              color: onInk ? "var(--tc-on-ink-muted)" : "var(--tc-text-secondary)"
            }}
          >
            {note}
          </p>
        ) : null}
      </div>
      {action}
    </div>
  );
}
