import React from "react";

/**
 * Semantic container for operational content. 14px radius, 1px neutral border,
 * 18px padding (gallery transport card). Cards are not generic wrappers —
 * do not nest one inside another.
 */
export function TcCard({ children, tone = "surface", padding, radius, style, ...rest }) {
  const tones = {
    surface: { background: "var(--tc-bg-surface)", border: "1px solid var(--tc-border-default)", color: "var(--tc-text-primary)" },
    flat: { background: "transparent", border: "1px solid var(--tc-border-default)", color: "var(--tc-text-primary)" },
    subtle: { background: "var(--tc-bg-subtle)", border: "1px solid var(--tc-border-default)", color: "var(--tc-text-primary)" },
    ink: { background: "var(--tc-bg-inverse)", border: 0, color: "var(--tc-on-ink-primary)" }
  };
  return (
    <div
      style={{
        borderRadius: radius || "var(--tc-radius-operational-card)",
        padding: padding || "18px",
        boxShadow: tone === "surface" ? "var(--tc-shadow-card-hairline)" : "none",
        ...tones[tone],
        ...style
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
