import React from "react";

const tones = {
  neutral: { background: "var(--tc-bg-subtle)", color: "var(--tc-neutral-700)" },
  primary: { background: "var(--tc-primary-subtle-bg)", color: "var(--tc-primary-subtle-fg)" },
  success: { background: "var(--tc-success-subtle-bg)", color: "var(--tc-success-subtle-fg)" },
  warning: { background: "var(--tc-warning-subtle-bg)", color: "var(--tc-warning-subtle-fg)" },
  critical: { background: "var(--tc-critical-subtle-bg)", color: "var(--tc-critical-subtle-fg)" }
};

/** Short metadata or state label. Never a full sentence; max 3 per card. */
export function TcChip({ children, tone = "neutral", dot = false, icon, style, ...rest }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "6px",
        padding: "7px 10px",
        borderRadius: "var(--tc-radius-pill)",
        fontFamily: "var(--tc-font-ui)",
        fontSize: "var(--tc-label-small-size)",
        lineHeight: "var(--tc-label-small-line)",
        fontWeight: "var(--tc-weight-bold)",
        ...tones[tone],
        ...style
      }}
      {...rest}
    >
      {dot ? (
        <span
          aria-hidden="true"
          style={{ width: "8px", height: "8px", borderRadius: "var(--tc-radius-pill)", background: "currentColor" }}
        />
      ) : null}
      {icon ? <span aria-hidden="true" style={{ display: "inline-flex" }}>{icon}</span> : null}
      {children}
    </span>
  );
}
