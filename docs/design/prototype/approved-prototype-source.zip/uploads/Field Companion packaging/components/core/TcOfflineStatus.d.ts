import * as React from "react";

/**
 * Connectivity status, shown only where it changes what the user can rely on.
 * Never a global banner (Design System v0.1 §40).
 */
export interface TcOfflineStatusProps extends React.HTMLAttributes<HTMLDivElement> {
  mode?: "online" | "offlineAvailable" | "weatherStale" | "syncUnavailable";
  /** Override the approved pt-BR wording only with trip-specific copy. */
  label?: string;
  variant?: "inline" | "chip";
}

export function TcOfflineStatus(props: TcOfflineStatusProps): React.JSX.Element;
