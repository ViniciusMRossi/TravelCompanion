import * as React from "react";

/**
 * Field Companion action button.
 * @startingPoint section="Core" subtitle="Primary, secondary, tonal, critical and text actions" viewport="700x220"
 */
export interface TcButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  /** primary = teal, once per decision surface. critical = oxblood, emergencies only. */
  variant?: "primary" | "secondary" | "tonal" | "critical" | "text";
  /** Leading glyph (Material Symbols Rounded span, or an approved emoji as in the gallery). */
  icon?: React.ReactNode;
  /** 44px height — only inside dense card action rows (TcNowCard). */
  compact?: boolean;
  full?: boolean;
  /** Use on ink / oxblood surfaces. */
  onInk?: boolean;
  disabled?: boolean;
  loading?: boolean;
}

export function TcButton(props: TcButtonProps): React.JSX.Element;
