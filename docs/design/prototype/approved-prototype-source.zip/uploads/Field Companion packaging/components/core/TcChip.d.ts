import * as React from "react";

/** Pill label for category, country, UNESCO, difficulty, offline availability. */
export interface TcChipProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
  tone?: "neutral" | "primary" | "success" | "warning" | "critical";
  /** currentColor dot — used when the chip carries state. */
  dot?: boolean;
  icon?: React.ReactNode;
}

export function TcChip(props: TcChipProps): React.JSX.Element;
