import * as React from "react";
import { TcStatus } from "../core/TcStatusChip";

/**
 * Accommodation card. Geometry derived from the gallery transport specimen —
 * the approved gallery has no accommodation example (see readme "Derived pieces").
 * @startingPoint section="Viagem" subtitle="Check-in / check-out with voucher shortcut" viewport="412x320"
 */
export interface TcAccommodationCardProps extends React.HTMLAttributes<HTMLElement> {
  name: string;
  address?: string;
  status?: TcStatus;
  /** "15 set · 14:00" */
  checkIn: string;
  checkOut: string;
  /** "1 noite" */
  nights?: string;
  /** Arrival instructions summary. */
  note?: string;
  critical?: boolean | string;
  actions?: React.ReactNode;
}

export function TcAccommodationCard(props: TcAccommodationCardProps): React.JSX.Element;
