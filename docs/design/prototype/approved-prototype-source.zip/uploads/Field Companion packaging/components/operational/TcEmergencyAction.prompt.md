Emergency action — nothing may compete with the call button.

```jsx
<TcEmergencyAction country="Emergência · Montenegro" number="112" service="Emergência geral"
  description="Use apenas quando houver necessidade imediata de polícia, ambulância ou bombeiros." />
<TcEmergencyAction variant="row" service="Polícia" number="122" />
```

No photography, no editorial type, no paragraphs before the action.
