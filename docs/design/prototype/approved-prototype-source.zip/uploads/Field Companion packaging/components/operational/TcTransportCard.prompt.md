Transport card — the densest operational surface in the system.

```jsx
<TcTransportCard
  status="booked" operator="Drita Travel"
  origin="Ksamil" destination="Budva · +1 dia"
  departure="19:30" arrival="11:07"
  note="Ônibus internacional · passaporte obrigatório"
/>
```

Times are Roboto Bold, tabular, never Fraunces. Under time pressure "Mostrar passagem" is the primary action.
