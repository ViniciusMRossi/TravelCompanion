import * as React from "react";

/**
 * Plan B card — scenario, consequence, 1–3 numbered next steps.
 * Gold/warning language; it should reduce stress, not signal panic.
 * @startingPoint section="Recuperação" subtitle="Plan B scenario with numbered steps" viewport="412x300"
 */
export interface TcPlanBCardProps extends React.HTMLAttributes<HTMLElement> {
  /** "Se perdermos o ônibus para Budva" */
  scenario: string;
  consequence?: string;
  /** Keep to 1–3 concrete steps. */
  steps?: string[];
  actions?: React.ReactNode;
  label?: string;
}

export function TcPlanBCard(props: TcPlanBCardProps): React.JSX.Element;
