import React from "react";

/**
 * Emergency action — deliberately breaks the app's softness. Solid oxblood,
 * 48px number, one dominant call action, no decoration.
 */
export function TcEmergencyAction({
  country,
  number,
  service,
  description,
  callLabel,
  onCall,
  variant = "hero",
  style,
  ...rest
}) {
  if (variant === "row") {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "14px",
          padding: "14px",
          border: "1px solid var(--tc-border-default)",
          borderRadius: "var(--tc-radius-operational-card)",
          background: "var(--tc-bg-surface)",
          minHeight: "var(--tc-touch-min)",
          ...style
        }}
        {...rest}
      >
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: "var(--tc-weight-bold)" }}>{service}</div>
          {description ? <div style={{ fontSize: "var(--tc-label-small-size)", color: "var(--tc-text-secondary)", marginTop: "3px" }}>{description}</div> : null}
        </div>
        <div className="tc-tabular" style={{ fontWeight: "var(--tc-weight-bold)", fontSize: "var(--tc-heading-3-size)" }}>{number}</div>
        <button
          type="button"
          onClick={onCall}
          style={{
            border: 0,
            cursor: "pointer",
            minHeight: "var(--tc-touch-critical)",
            padding: "0 16px",
            borderRadius: "var(--tc-radius-button)",
            background: "var(--tc-critical-bg)",
            color: "var(--tc-critical-fg)",
            fontFamily: "var(--tc-font-ui)",
            fontSize: "var(--tc-label-large-size)",
            fontWeight: "var(--tc-weight-medium)"
          }}
        >
          {callLabel || "Ligar"}
        </button>
      </div>
    );
  }
  return (
    <section
      style={{
        background: "var(--tc-critical-bg)",
        color: "var(--tc-critical-fg)",
        borderRadius: "var(--tc-radius-lg)",
        padding: "22px",
        ...style
      }}
      {...rest}
    >
      {country ? (
        <div style={{ fontSize: "var(--tc-eyebrow-size)", fontWeight: "var(--tc-weight-bold)", letterSpacing: "var(--tc-eyebrow-tracking)", textTransform: "uppercase", color: "var(--tc-on-critical-eyebrow)" }}>
          {country}
        </div>
      ) : null}
      <div className="tc-tabular" style={{ fontSize: "48px", lineHeight: 1, fontWeight: "var(--tc-weight-bold)", margin: "10px 0" }}>{number}</div>
      <h3 style={{ margin: "0 0 6px", fontSize: "var(--tc-heading-3-size)", lineHeight: "var(--tc-heading-3-line)", fontWeight: "var(--tc-weight-bold)" }}>{service}</h3>
      {description ? <p style={{ color: "var(--tc-on-critical-copy)", margin: "0 0 16px", fontSize: "var(--tc-body-size)", lineHeight: "var(--tc-body-line)" }}>{description}</p> : null}
      <button
        type="button"
        onClick={onCall}
        style={{
          border: 0,
          cursor: "pointer",
          minHeight: "var(--tc-touch-critical)",
          padding: "0 18px",
          borderRadius: "var(--tc-radius-button)",
          background: "var(--tc-on-ink-primary)",
          color: "var(--tc-critical-bg)",
          fontFamily: "var(--tc-font-ui)",
          fontSize: "var(--tc-label-large-size)",
          fontWeight: "var(--tc-weight-medium)",
          display: "inline-flex",
          alignItems: "center",
          gap: "8px"
        }}
      >
        <span className="tc-icon tc-icon-24" aria-hidden="true">call</span>
        {callLabel || "Ligar " + number}
      </button>
    </section>
  );
}
