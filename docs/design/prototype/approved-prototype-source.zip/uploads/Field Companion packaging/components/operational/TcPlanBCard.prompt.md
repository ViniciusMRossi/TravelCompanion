Plan B — contingency, not emergency.

```jsx
<TcPlanBCard
  scenario="Se perdermos o ônibus para Budva"
  steps={["Vá até o ponto/rodoviária e confirme a próxima saída.",
          "Verifique conexão por Sarandë ou Shkodër.",
          "Se não houver opção segura, use a hospedagem emergencial cadastrada."]}
/>
```

Never use oxblood here unless the scenario genuinely became an emergency.
