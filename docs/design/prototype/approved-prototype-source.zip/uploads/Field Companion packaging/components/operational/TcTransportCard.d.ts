import * as React from "react";
import { TcStatus } from "../core/TcStatusChip";

/**
 * Transport card — origin/destination, times, operator, status, ticket shortcut.
 * @startingPoint section="Viagem" subtitle="Dense transport card with route grid" viewport="412x300"
 */
export interface TcTransportCardProps extends React.HTMLAttributes<HTMLElement> {
  status?: TcStatus;
  /** "Drita Travel" */
  operator?: string;
  origin: string;
  /** "Budva · +1 dia" — day offsets belong in the place line. */
  destination: string;
  departure: string;
  arrival: string;
  /** "Ônibus internacional · passaporte obrigatório" */
  note?: string;
  /** true, or the critical label to show alongside the booking status. */
  critical?: boolean | string;
  actions?: React.ReactNode;
}

export function TcTransportCard(props: TcTransportCardProps): React.JSX.Element;
