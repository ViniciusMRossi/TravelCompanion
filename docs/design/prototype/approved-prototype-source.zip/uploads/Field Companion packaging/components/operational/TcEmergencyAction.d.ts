import * as React from "react";

/**
 * Emergency number + call action.
 * @startingPoint section="Recuperação" subtitle="Oxblood emergency call block" viewport="412x300"
 */
export interface TcEmergencyActionProps extends React.HTMLAttributes<HTMLElement> {
  /** "Emergência · Montenegro" — always name the current country. */
  country?: string;
  number: string;
  service: string;
  description?: string;
  callLabel?: string;
  onCall?: () => void;
  /** "hero" for the primary number, "row" for the secondary list. */
  variant?: "hero" | "row";
}

export function TcEmergencyAction(props: TcEmergencyActionProps): React.JSX.Element;
