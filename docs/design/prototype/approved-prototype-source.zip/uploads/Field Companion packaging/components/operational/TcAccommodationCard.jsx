import React from "react";
import { TcStatusChip } from "../core/TcStatusChip.jsx";
import { TcButton } from "../core/TcButton.jsx";

/**
 * Accommodation card — check-in/out, address, reservation status, voucher.
 * Composition note: the approved gallery has no accommodation specimen, so this
 * reuses the transport card geometry (14px radius, 18px padding, 24px times).
 */
export function TcAccommodationCard({
  name,
  address,
  status = "confirmed",
  checkIn,
  checkOut,
  nights,
  note,
  critical,
  actions,
  style,
  ...rest
}) {
  const col = (label, value) => (
    <div>
      <div style={{ fontSize: "var(--tc-label-small-size)", fontWeight: "var(--tc-weight-bold)", color: "var(--tc-text-secondary)", textTransform: "uppercase", letterSpacing: "var(--tc-label-tracking)" }}>
        {label}
      </div>
      <div className="tc-tabular" style={{ fontSize: "var(--tc-heading-2-size)", fontWeight: "var(--tc-weight-bold)", marginTop: "2px" }}>{value}</div>
    </div>
  );
  return (
    <article
      style={{
        border: "1px solid var(--tc-border-default)",
        borderRadius: "var(--tc-radius-operational-card)",
        padding: "18px",
        background: "var(--tc-bg-surface)",
        ...style
      }}
      {...rest}
    >
      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginBottom: "12px" }}>
        <TcStatusChip status={status} />
        {critical ? <TcStatusChip status="critical" label={typeof critical === "string" ? critical : "Crítico"} /> : null}
        {nights ? <span style={{ marginLeft: "auto", fontSize: "var(--tc-label-small-size)", color: "var(--tc-text-secondary)" }}>{nights}</span> : null}
      </div>
      <h3 style={{ margin: "0 0 4px", fontSize: "var(--tc-heading-3-size)", lineHeight: "var(--tc-heading-3-line)", fontWeight: "var(--tc-weight-bold)" }}>{name}</h3>
      {address ? <div style={{ fontSize: "13px", color: "var(--tc-text-secondary)" }}>{address}</div> : null}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", margin: "16px 0" }}>
        {col("Check-in", checkIn)}
        {col("Check-out", checkOut)}
      </div>
      {note ? <div style={{ fontSize: "13px", color: "var(--tc-text-secondary)", marginBottom: "14px" }}>{note}</div> : null}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
        {actions || (
          <>
            <TcButton variant="primary">Abrir voucher</TcButton>
            <TcButton variant="secondary">Abrir no Maps</TcButton>
          </>
        )}
      </div>
    </article>
  );
}
