Accommodation card — check-in/out first, voucher one tap away.

```jsx
<TcAccommodationCard
  name="Vila Emiljano" address="Rruga e Plazhit, Ksamil"
  status="confirmed" checkIn="15 set · 14:00" checkOut="16 set · 10:00" nights="1 noite"
/>
```

When check-in closes at a fixed hour, pair it with a TcCriticalCard instead of hiding the deadline in `note`.
