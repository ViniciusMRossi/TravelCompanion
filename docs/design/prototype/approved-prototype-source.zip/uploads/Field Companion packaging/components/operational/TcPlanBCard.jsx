import React from "react";

/**
 * Plan B — warm gold, calm and actionable. Not an emergency.
 * 16px radius, 18px padding (gallery values).
 */
export function TcPlanBCard({ scenario, consequence, steps = [], actions, label = "Plano B", style, ...rest }) {
  return (
    <section
      style={{
        background: "var(--tc-warning-subtle-bg)",
        border: "1px solid var(--tc-planb-border)",
        borderRadius: "16px",
        padding: "18px",
        ...style
      }}
      {...rest}
    >
      <div style={{ fontSize: "var(--tc-label-small-size)", textTransform: "uppercase", letterSpacing: "var(--tc-label-tracking)", color: "var(--tc-warning-subtle-fg)", fontWeight: "var(--tc-weight-bold)" }}>
        {label}
      </div>
      <h3 style={{ margin: "8px 0 6px", fontSize: "var(--tc-heading-3-size)", lineHeight: "var(--tc-heading-3-line)", fontWeight: "var(--tc-weight-bold)" }}>{scenario}</h3>
      {consequence ? (
        <p style={{ margin: "0 0 10px", color: "var(--tc-planb-text)", fontSize: "var(--tc-body-small-size)", lineHeight: 1.5 }}>{consequence}</p>
      ) : null}
      {steps.length ? (
        <ol style={{ paddingLeft: "20px", margin: 0, marginBottom: 0, color: "var(--tc-planb-text)" }}>
          {steps.map((s, i) => (
            <li key={i} style={{ margin: "8px 0", lineHeight: 1.4 }}>{s}</li>
          ))}
        </ol>
      ) : null}
      {actions ? <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginTop: "16px" }}>{actions}</div> : null}
    </section>
  );
}
