import React from "react";
import { TcStatusChip } from "../core/TcStatusChip.jsx";
import { TcButton } from "../core/TcButton.jsx";

/**
 * Dense operational transport card. 14px radius, 18px padding,
 * origin/destination route grid (1fr auto 1fr), 24px bold times.
 */
export function TcTransportCard({
  status = "booked",
  operator,
  origin,
  destination,
  departure,
  arrival,
  note,
  critical,
  actions,
  style,
  ...rest
}) {
  return (
    <article
      style={{
        border: "1px solid var(--tc-border-default)",
        borderRadius: "var(--tc-radius-operational-card)",
        padding: "18px",
        background: "var(--tc-bg-surface)",
        ...style
      }}
      {...rest}
    >
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: "10px" }}>
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          <TcStatusChip status={status} />
          {critical ? <TcStatusChip status="critical" label={typeof critical === "string" ? critical : "Crítico"} /> : null}
        </div>
        {operator ? <span style={{ fontSize: "var(--tc-label-small-size)", color: "var(--tc-text-secondary)" }}>{operator}</span> : null}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center", gap: "12px", margin: "16px 0" }}>
        <div>
          <div className="tc-tabular" style={{ fontSize: "var(--tc-heading-2-size)", fontWeight: "var(--tc-weight-bold)" }}>{departure}</div>
          <div style={{ fontSize: "13px", color: "var(--tc-text-secondary)" }}>{origin}</div>
        </div>
        <div aria-hidden="true" style={{ display: "flex", alignItems: "center", color: "var(--tc-text-tertiary)", fontSize: "20px" }}>→</div>
        <div style={{ textAlign: "right" }}>
          <div className="tc-tabular" style={{ fontSize: "var(--tc-heading-2-size)", fontWeight: "var(--tc-weight-bold)" }}>{arrival}</div>
          <div style={{ fontSize: "13px", color: "var(--tc-text-secondary)" }}>{destination}</div>
        </div>
      </div>

      {note ? <div style={{ fontSize: "13px", color: "var(--tc-text-secondary)", marginBottom: "14px" }}>{note}</div> : null}

      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
        {actions || (
          <>
            <TcButton variant="primary">Mostrar passagem</TcButton>
            <TcButton variant="secondary">Ver embarque</TcButton>
          </>
        )}
      </div>
    </article>
  );
}
