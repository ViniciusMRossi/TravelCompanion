Voice recorder — must feel easier than typing at the end of a tired day.

```jsx
<TcVoiceRecorder state="recording" elapsed="02:41" context="Žabljak · Bobotov Kuk · Vinícius" />
```

Cancelar sits apart from Concluir (they must be hard to confuse); haptics fire on start and stop.
