Group listening state for "Ouvir juntos".

```jsx
<TcGroupAudioStatus participants={[
  { name: "Vinícius", state: "synchronized" },
  { name: "Érika", state: "resyncing" }
]} />
```

Local playback never depends on the group: the degraded message must say the audioguia keeps working.
