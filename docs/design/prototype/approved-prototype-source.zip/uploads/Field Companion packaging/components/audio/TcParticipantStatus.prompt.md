Participant pill — moss = sincronizado, gold = conectando / sincronizando novamente, neutral = offline.

```jsx
<TcParticipantStatus name="Vinícius" state="synchronized" />
<TcParticipantStatus name="Érika" state="resyncing" />
```

Never render latency numbers, peer ids, or the words stream/room/session.
