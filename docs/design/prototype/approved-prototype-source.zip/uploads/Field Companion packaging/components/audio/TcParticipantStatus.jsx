import React from "react";

const STATES = {
  synchronized: { dot: "var(--tc-participant-synchronized)", label: "Sincronizado" },
  connecting: { dot: "var(--tc-participant-connecting)", label: "Conectando" },
  resyncing: { dot: "var(--tc-participant-connecting)", label: "Sincronizando novamente" },
  offline: { dot: "var(--tc-participant-offline)", label: "Offline" }
};

/**
 * One participant pill: initial avatar, state dot, name and/or state label.
 * Never shows latency or any technical detail.
 */
export function TcParticipantStatus({
  name,
  state = "synchronized",
  showLabel = true,
  showName = true,
  label,
  onInk = false,
  style,
  ...rest
}) {
  const s = STATES[state] || STATES.synchronized;
  const text = [showName ? name : null, showLabel ? (label || s.label) : null].filter(Boolean).join(" · ");
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "8px",
        padding: "9px 11px",
        border: onInk ? "1px solid var(--tc-on-ink-border-soft)" : "1px solid var(--tc-border-default)",
        borderRadius: "var(--tc-radius-pill)",
        background: onInk ? "var(--tc-on-ink-fill-strong)" : "var(--tc-bg-surface)",
        color: onInk ? "var(--tc-on-ink-primary)" : "var(--tc-text-primary)",
        fontSize: "13px",
        ...style
      }}
      {...rest}
    >
      {name ? (
        <span
          aria-hidden="true"
          style={{
            width: "25px",
            height: "25px",
            borderRadius: "var(--tc-radius-pill)",
            background: onInk ? "var(--tc-on-ink-fill)" : "var(--tc-ink)",
            color: "var(--tc-on-ink-primary)",
            display: "grid",
            placeItems: "center",
            fontSize: "10px",
            fontWeight: "var(--tc-weight-bold)",
            flex: "0 0 auto"
          }}
        >
          {name.slice(0, 1)}
        </span>
      ) : null}
      <span
        aria-hidden="true"
        style={{ width: "8px", height: "8px", borderRadius: "var(--tc-radius-pill)", background: s.dot, flex: "0 0 auto" }}
      />
      {text}
    </div>
  );
}
