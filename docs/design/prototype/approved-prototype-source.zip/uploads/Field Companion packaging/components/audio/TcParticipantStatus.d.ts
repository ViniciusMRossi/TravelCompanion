import * as React from "react";

/** Participant pill with group-audio state. Terminology is fixed by the system. */
export interface TcParticipantStatusProps extends React.HTMLAttributes<HTMLDivElement> {
  /** First letter becomes the avatar. No photos in V1. */
  name?: string;
  state?: "synchronized" | "connecting" | "resyncing" | "offline";
  showLabel?: boolean;
  showName?: boolean;
  /** Override the approved label only with equally plain wording. */
  label?: string;
  onInk?: boolean;
}

export function TcParticipantStatus(props: TcParticipantStatusProps): React.JSX.Element;
