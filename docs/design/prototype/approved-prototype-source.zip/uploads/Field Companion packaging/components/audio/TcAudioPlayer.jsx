import React from "react";
import { TcIconButton } from "../core/TcIconButton.jsx";
import { TcGroupAudioStatus } from "./TcGroupAudioStatus.jsx";

/**
 * Audio player. Teal subtle surface, 18px radius/padding, 46px play circle,
 * 6px progress track (gallery values). Compact = persistent bottom player,
 * full = the shared audioguide screen.
 */
export function TcAudioPlayer({
  title,
  chapter,
  progress = 0,
  elapsed,
  total,
  state = "playing",
  variant = "compact",
  participants,
  groupMessage,
  onToggle,
  onSkipBack,
  onSkipForward,
  style,
  ...rest
}) {
  const icon = state === "playing" ? "❙❙" : state === "loading" ? "…" : "▶";
  return (
    <section
      style={{
        background: "var(--tc-primary-subtle-bg)",
        border: "1px solid var(--tc-audio-border)",
        borderRadius: "18px",
        padding: "18px",
        ...style
      }}
      {...rest}
    >
      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        <TcIconButton
          icon={icon}
          size="audio"
          variant="primary"
          label={state === "playing" ? "Pausar" : "Ouvir"}
          onClick={onToggle}
          style={{ fontSize: "19px" }}
        />
        <div style={{ minWidth: 0 }}>
          <div style={{ fontWeight: "var(--tc-weight-bold)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{title}</div>
          {chapter ? <div style={{ fontSize: "var(--tc-label-small-size)", color: "var(--tc-text-secondary)", marginTop: "2px" }}>{chapter}</div> : null}
        </div>
        {variant === "full" ? (
          <div style={{ marginLeft: "auto", display: "flex", gap: "8px" }}>
            <TcIconButton icon="−15" label="Voltar 15 segundos" variant="tonal" onClick={onSkipBack} style={{ fontSize: "13px", fontWeight: 700 }} />
            <TcIconButton icon="+15" label="Avançar 15 segundos" variant="tonal" onClick={onSkipForward} style={{ fontSize: "13px", fontWeight: 700 }} />
          </div>
        ) : null}
      </div>

      <div style={{ height: "6px", borderRadius: "var(--tc-radius-pill)", background: "var(--tc-audio-track)", margin: "15px 0 8px", overflow: "hidden" }}>
        <span style={{ display: "block", height: "100%", width: progress + "%", background: "var(--tc-audio-accent)" }} />
      </div>
      <div className="tc-tabular" style={{ display: "flex", justifyContent: "space-between", fontSize: "11px", color: "var(--tc-text-secondary)" }}>
        <span>{elapsed}</span>
        <span>{total}</span>
      </div>

      {participants && participants.length ? (
        <TcGroupAudioStatus participants={participants} message={groupMessage} />
      ) : null}
    </section>
  );
}
