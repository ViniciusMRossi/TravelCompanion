Audio player — teal family only; audio is a first-class surface, never a purple "music" widget.

```jsx
<TcAudioPlayer title="Latin Bridge" chapter="Sarajevo Historical Walk · capítulo 5"
  progress={53} elapsed="04:32" total="08:41" state="playing"
  participants={[{ name: "Vinícius", state: "synchronized" }, { name: "Érika", state: "synchronized" }]} />
```

The compact player stays available while navigating; playback survives screen-off and background.
