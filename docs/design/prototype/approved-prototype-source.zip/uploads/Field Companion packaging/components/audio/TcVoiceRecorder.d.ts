import * as React from "react";

/**
 * Voice memory recorder — one tap to start, no mandatory title or text.
 * @startingPoint section="Diário" subtitle="Voice memory recorder, idle and recording" viewport="412x360"
 */
export interface TcVoiceRecorderProps extends React.HTMLAttributes<HTMLElement> {
  state?: "idle" | "recording" | "paused" | "saved";
  /** "02:41" */
  elapsed?: string;
  /** Auto-captured context: "Žabljak · Bobotov Kuk · Vinícius" */
  context?: string;
  /** Full saved sentence; defaults to "Memória salva em {context}". */
  savedLabel?: string;
  onStart?: () => void;
  onPause?: () => void;
  onResume?: () => void;
  onFinish?: () => void;
  onCancel?: () => void;
  idleTitle?: string;
  idleHint?: string;
}

export function TcVoiceRecorder(props: TcVoiceRecorderProps): React.JSX.Element;
