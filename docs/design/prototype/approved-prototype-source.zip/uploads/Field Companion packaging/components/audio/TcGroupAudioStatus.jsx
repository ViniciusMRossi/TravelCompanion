import React from "react";
import { TcParticipantStatus } from "./TcParticipantStatus.jsx";

/**
 * Group listening state. There is no room, invite, code or pairing —
 * participants come from the trip package and "Quem é você?".
 */
export function TcGroupAudioStatus({
  participants = [],
  message,
  onInk = false,
  title,
  style,
  ...rest
}) {
  const degraded = participants.some(p => p.state === "offline" || p.state === "resyncing" || p.state === "connecting");
  return (
    <div style={style} {...rest}>
      {title ? (
        <div style={{ fontSize: "var(--tc-label-small-size)", fontWeight: "var(--tc-weight-bold)", textTransform: "uppercase", letterSpacing: "var(--tc-label-tracking)", color: onInk ? "var(--tc-on-ink-label)" : "var(--tc-text-secondary)", marginBottom: "10px" }}>
          {title}
        </div>
      ) : null}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginTop: title ? 0 : "14px" }}>
        {participants.map((p, i) => (
          <TcParticipantStatus key={p.name || i} onInk={onInk} {...p} />
        ))}
      </div>
      {(message || degraded) ? (
        <p
          style={{
            margin: "12px 0 0",
            fontSize: "13px",
            lineHeight: 1.45,
            color: onInk ? "var(--tc-on-ink-muted)" : "var(--tc-text-secondary)"
          }}
        >
          {message || "Não foi possível sincronizar o grupo. Seu audioguia continua funcionando normalmente."}
        </p>
      ) : null}
    </div>
  );
}
