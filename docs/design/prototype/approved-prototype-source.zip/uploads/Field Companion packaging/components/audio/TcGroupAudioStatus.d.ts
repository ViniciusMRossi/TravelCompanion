import * as React from "react";
import { TcParticipantStatusProps } from "./TcParticipantStatus";

/**
 * Group audio state block — participant pills plus a plain-language message
 * when synchronisation degrades.
 * @startingPoint section="Áudio" subtitle="Ouvir juntos group state" viewport="700x180"
 */
export interface TcGroupAudioStatusProps extends React.HTMLAttributes<HTMLDivElement> {
  participants?: TcParticipantStatusProps[];
  /** Defaults to the approved sync-failure sentence when any participant is degraded. */
  message?: string;
  title?: string;
  onInk?: boolean;
}

export function TcGroupAudioStatus(props: TcGroupAudioStatusProps): React.JSX.Element;
