import React from "react";

/**
 * Active-walk header on ink: tour name in Fraunces 28, progress, remaining
 * time, next instruction, next story and group presence. 20px radius/padding.
 */
export function TcWalkProgress({
  tour,
  progressLabel,
  remainingLabel,
  instruction,
  nextTitle,
  nextDistance,
  nextLabel = "Próxima história",
  gpsState,
  children,
  style,
  ...rest
}) {
  const gps = gpsState
    ? { active: "Localização ativa", searching: "Procurando sua localização", weak: "Localização imprecisa" }[gpsState]
    : null;
  return (
    <section
      style={{
        borderRadius: "var(--tc-radius-lg)",
        background: "var(--tc-bg-inverse)",
        color: "var(--tc-on-ink-primary)",
        padding: "20px",
        ...style
      }}
      {...rest}
    >
      <div style={{ display: "flex", justifyContent: "space-between", gap: "10px", color: "var(--tc-on-ink-muted)", fontSize: "var(--tc-label-small-size)" }}>
        <span>{progressLabel}</span>
        <span>{remainingLabel}</span>
      </div>
      <h3 className="tc-display" style={{ fontSize: "28px", margin: "16px 0 8px", lineHeight: 1.1 }}>{tour}</h3>
      {instruction ? (
        <p style={{ color: "var(--tc-on-ink-walk-copy)", lineHeight: 1.5, margin: 0, fontSize: "var(--tc-body-size)" }}>{instruction}</p>
      ) : null}
      {nextTitle ? (
        <div style={{ padding: "12px 14px", borderRadius: "12px", background: "var(--tc-on-ink-step)", marginTop: "12px" }}>
          <strong style={{ display: "block", marginBottom: "4px" }}>{nextLabel}</strong>
          {[nextTitle, nextDistance].filter(Boolean).join(" · ")}
        </div>
      ) : null}
      {gps ? (
        <div style={{ display: "flex", alignItems: "center", gap: "8px", marginTop: "12px", fontSize: "var(--tc-label-small-size)", color: "var(--tc-on-ink-muted)" }}>
          <span aria-hidden="true" style={{ width: "8px", height: "8px", borderRadius: "var(--tc-radius-pill)", background: gpsState === "active" ? "var(--tc-participant-synchronized)" : "var(--tc-participant-connecting)" }} />
          {gps}
        </div>
      ) : null}
      {children}
    </section>
  );
}
