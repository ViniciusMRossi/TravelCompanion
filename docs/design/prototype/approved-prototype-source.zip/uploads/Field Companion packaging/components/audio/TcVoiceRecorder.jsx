import React from "react";
import { TcChip } from "../core/TcChip.jsx";
import { TcButton } from "../core/TcButton.jsx";

const WAVE = [10, 26, 38, 20, 34, 15, 29, 11];

/**
 * Voice memory recorder. Idle / recording / paused / saved.
 * 82px oxblood record button, 28px white core, 44px waveform (gallery values).
 * No title, no form — context is captured automatically.
 */
export function TcVoiceRecorder({
  state = "idle",
  elapsed = "00:00",
  context,
  savedLabel,
  onStart,
  onPause,
  onResume,
  onFinish,
  onCancel,
  idleTitle = "Registrar memória",
  idleHint = "Toque e conte como foi este momento.",
  style,
  ...rest
}) {
  const shell = {
    textAlign: "center",
    padding: "28px",
    border: "1px solid var(--tc-border-default)",
    borderRadius: "var(--tc-radius-lg)",
    background: "var(--tc-bg-surface)",
    ...style
  };

  if (state === "idle") {
    return (
      <section style={shell} {...rest}>
        <button
          type="button"
          onClick={onStart}
          aria-label="Gravar memória"
          style={{
            width: "82px",
            height: "82px",
            borderRadius: "var(--tc-radius-pill)",
            background: "var(--tc-critical-bg)",
            display: "grid",
            placeItems: "center",
            margin: "8px auto 18px",
            boxShadow: "var(--tc-shadow-record)",
            border: 0,
            cursor: "pointer"
          }}
        >
          <span aria-hidden="true" style={{ width: "28px", height: "28px", borderRadius: "var(--tc-radius-pill)", background: "var(--tc-on-ink-primary)" }} />
        </button>
        <h3 style={{ margin: "0 0 6px", fontSize: "var(--tc-heading-3-size)", lineHeight: "var(--tc-heading-3-line)", fontWeight: "var(--tc-weight-medium)" }}>{idleTitle}</h3>
        <p style={{ color: "var(--tc-text-secondary)", margin: 0, fontSize: "var(--tc-body-size)" }}>{idleHint}</p>
      </section>
    );
  }

  if (state === "saved") {
    return (
      <section style={shell} {...rest}>
        <TcChip tone="success" dot>Memória salva</TcChip>
        <p style={{ color: "var(--tc-text-secondary)", margin: "14px 0 0", fontSize: "var(--tc-body-size)" }}>
          {savedLabel || "Memória salva em " + (context || "") }
        </p>
      </section>
    );
  }

  const recording = state === "recording";
  return (
    <section style={shell} {...rest}>
      <TcChip tone={recording ? "critical" : "warning"} dot>{recording ? "Gravando" : "Pausado"}</TcChip>
      <div className="tc-tabular" style={{ fontSize: "38px", fontWeight: "var(--tc-weight-bold)", margin: "16px 0 0" }}>{elapsed}</div>
      <div style={{ height: "44px", display: "flex", alignItems: "center", justifyContent: "center", gap: "4px", margin: "14px 0" }}>
        {WAVE.map((h, i) => (
          <span
            key={i}
            aria-hidden="true"
            style={{
              display: "block",
              width: "4px",
              height: (recording ? h : Math.max(6, Math.round(h / 3))) + "px",
              borderRadius: "var(--tc-radius-pill)",
              background: "var(--tc-critical-bg)",
              opacity: 0.78,
              transition: "height var(--tc-motion-standard) var(--tc-motion-easing)"
            }}
          />
        ))}
      </div>
      {context ? (
        <div style={{ fontSize: "13px", color: "var(--tc-text-secondary)", marginBottom: "18px" }}>{context}</div>
      ) : null}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", justifyContent: "center" }}>
        <TcButton variant="secondary" onClick={recording ? onPause : onResume}>{recording ? "Pausar" : "Continuar"}</TcButton>
        <TcButton variant="primary" onClick={onFinish}>Concluir</TcButton>
        <TcButton variant="text" style={{ color: "var(--tc-critical-bg)" }} onClick={onCancel}>Cancelar</TcButton>
      </div>
    </section>
  );
}
