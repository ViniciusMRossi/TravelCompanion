import * as React from "react";

/**
 * Walk Mode header. Designed to be understood at a glance — the phone is
 * usually in a pocket, so targets around it stay generous and states audible.
 * @startingPoint section="Passeio" subtitle="Active walk header on ink" viewport="412x340"
 */
export interface TcWalkProgressProps extends React.HTMLAttributes<HTMLElement> {
  tour: string;
  /** "3 de 7 histórias" */
  progressLabel?: string;
  /** "~28 min restantes" */
  remainingLabel?: string;
  /** The next physical instruction, in plain language. */
  instruction?: string;
  nextTitle?: string;
  /** "~180 m" */
  nextDistance?: string;
  nextLabel?: string;
  /** Shown only when it matters; never permanent telemetry. */
  gpsState?: "active" | "searching" | "weak";
  /** Participant pills (TcGroupAudioStatus with onInk). */
  children?: React.ReactNode;
}

export function TcWalkProgress(props: TcWalkProgressProps): React.JSX.Element;
