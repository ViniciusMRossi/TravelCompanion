import * as React from "react";
import { TcParticipantStatusProps } from "./TcParticipantStatus";

/**
 * Audioguide player, compact (persistent) or full (shared audio screen).
 * @startingPoint section="Áudio" subtitle="Shared audioguide player" viewport="412x300"
 */
export interface TcAudioPlayerProps extends React.HTMLAttributes<HTMLElement> {
  title: string;
  /** "Sarajevo Historical Walk · capítulo 5" */
  chapter?: string;
  /** 0–100 */
  progress?: number;
  elapsed?: string;
  total?: string;
  state?: "idle" | "loading" | "playing" | "paused";
  variant?: "compact" | "full";
  /** Pass the trip participants to turn this into "Ouvir juntos". */
  participants?: TcParticipantStatusProps[];
  groupMessage?: string;
  onToggle?: () => void;
  onSkipBack?: () => void;
  onSkipForward?: () => void;
}

export function TcAudioPlayer(props: TcAudioPlayerProps): React.JSX.Element;
