Walk Mode header — progress, current instruction, next story, group presence.

```jsx
<TcWalkProgress tour="Sarajevo Historical Walk" progressLabel="3 de 7 histórias" remainingLabel="~28 min restantes"
  instruction="Continuem pela Ferhadija. Em alguns minutos vocês vão perceber uma mudança clara na arquitetura."
  nextTitle="Sarajevo Meeting of Cultures" nextDistance="~180 m" gpsState="active">
  <TcGroupAudioStatus onInk participants={[{ name: "Vinícius", state: "synchronized", showLabel: false }]} />
</TcWalkProgress>
```

Show GPS state only when it is relevant. No accuracy numbers, no "geofence".
