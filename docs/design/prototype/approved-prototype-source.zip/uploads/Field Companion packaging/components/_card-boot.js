/* Field Companion — card/kit bootstrap.
   Prefers the compiled design-system bundle (window.<Namespace>). When it is
   not available (opening a card straight from the filesystem), it loads the
   component sources with Babel so every card and UI kit still renders.
   Not a component: this file never ships to consumers. */
(function () {
  var FILES = ["core/TcButton","core/TcIconButton","core/TcChip","core/TcStatusChip","core/TcCard","core/TcSectionHeader","core/TcOfflineStatus","today/TcNowCard","today/TcCriticalCard","today/TcTimelineItem","today/TcTimeline","today/TcWeatherSummary","today/TcOutfitCard","editorial/TcCityHero","editorial/TcAttractionHero","editorial/TcStoryCard","operational/TcTransportCard","operational/TcAccommodationCard","operational/TcPlanBCard","operational/TcEmergencyAction","audio/TcParticipantStatus","audio/TcGroupAudioStatus","audio/TcAudioPlayer","audio/TcWalkProgress","audio/TcVoiceRecorder","wallet/TcDocumentRow","wallet/TcQrViewer"];
  var NAMES = ["TcButton","TcIconButton","TcChip","TcStatusChip","TcCard","TcSectionHeader","TcOfflineStatus","TcNowCard","TcCriticalCard","TcTimelineItem","TcTimeline","TcWeatherSummary","TcOutfitCard","TcCityHero","TcAttractionHero","TcStoryCard","TcTransportCard","TcAccommodationCard","TcPlanBCard","TcEmergencyAction","TcParticipantStatus","TcGroupAudioStatus","TcAudioPlayer","TcWalkProgress","TcVoiceRecorder","TcDocumentRow","TcQrViewer"];

  function findNamespace() {
    for (var k in window) {
      try {
        var v = window[k];
        if (v && typeof v === "object" && typeof v.TcNowCard === "function" && typeof v.TcButton === "function") return v;
      } catch (e) {}
    }
    return null;
  }

  function loadScript(src) {
    return new Promise(function (res) {
      var s = document.createElement("script");
      s.src = src;
      s.onload = function () { res(true); };
      s.onerror = function () { res(false); };
      document.head.appendChild(s);
    });
  }

  window.tcBoot = async function (componentsBase, bundlePath) {
    var ns = findNamespace();
    if (ns) return ns;
    if (bundlePath) {
      // Probe first: an element load of a missing bundle would log a resource error.
      var present = false;
      try { var head = await fetch(bundlePath, { method: "HEAD" }); present = head.ok; } catch (e) {}
      if (present) { await loadScript(bundlePath); ns = findNamespace(); if (ns) return ns; }
    }

    var sources = await Promise.all(
      FILES.map(function (f) {
        return fetch(componentsBase + f + ".jsx").then(function (r) { return r.text(); });
      })
    );
    var code = sources
      .join("\n")
      .replace(/^\s*import[^\n]*\n/gm, "")
      .replace(/export function/g, "function")
      .replace(/export const/g, "const");
    code += "\nwindow.TravelCompanion = {" + NAMES.map(function (n) { return n + ":" + n; }).join(",") + "};";
    var out = Babel.transform(code, { presets: [["react", { runtime: "classic" }]] }).code;
    new Function("React", out)(window.React);
    return window.TravelCompanion;
  };
})();
