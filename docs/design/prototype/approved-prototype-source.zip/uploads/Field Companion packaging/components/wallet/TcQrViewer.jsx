import React from "react";

const QR_PATTERN = {
  backgroundImage:
    "linear-gradient(90deg,#111 12%,transparent 12% 24%,#111 24% 36%,transparent 36% 48%,#111 48% 60%,transparent 60% 72%,#111 72% 84%,transparent 84%), linear-gradient(#111 12%,transparent 12% 24%,#111 24% 36%,transparent 36% 48%,#111 48% 60%,transparent 60% 72%,#111 72% 84%,transparent 84%)",
  backgroundSize: "24px 24px"
};

/**
 * QR mode: large code, maximum brightness, screen kept awake, minimum UI.
 * The pattern below is the approved gallery placeholder, not a real code.
 */
export function TcQrViewer({
  label = "CARTÃO DE EMBARQUE",
  size = 150,
  note = "Brilho máximo · tela sempre ativa",
  identity,
  code,
  style,
  ...rest
}) {
  return (
    <section
      style={{
        border: "1px solid var(--tc-border-default)",
        borderRadius: "18px",
        padding: "18px",
        textAlign: "center",
        background: "#FFFFFF",
        color: "var(--tc-ink)",
        ...style
      }}
      {...rest}
    >
      <div style={{ fontSize: "var(--tc-label-small-size)", fontWeight: "var(--tc-weight-bold)", marginBottom: "14px", letterSpacing: "var(--tc-label-tracking)" }}>{label}</div>
      <div
        role="img"
        aria-label="Código QR do documento"
        style={{ width: size + "px", height: size + "px", margin: "0 auto", ...QR_PATTERN }}
      />
      {code ? (
        <div className="tc-tabular" style={{ marginTop: "14px", fontWeight: "var(--tc-weight-bold)", letterSpacing: ".06em" }}>{code}</div>
      ) : null}
      {identity ? (
        <div style={{ fontSize: "13px", marginTop: "6px", color: "var(--tc-neutral-700)" }}>{identity}</div>
      ) : null}
      {note ? (
        <div style={{ fontSize: "var(--tc-label-small-size)", color: "var(--tc-text-secondary)", marginTop: "14px" }}>{note}</div>
      ) : null}
    </section>
  );
}
