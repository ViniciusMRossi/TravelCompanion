import * as React from "react";

/**
 * Wallet row for a ticket, voucher, insurance or personal document.
 * @startingPoint section="Carteira" subtitle="Document rows with offline indicator" viewport="700x220"
 */
export interface TcDocumentRowProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  title: string;
  /** Relevant date, e.g. "16 set". */
  meta?: string;
  /** Emoji or Material Symbols span for the document type. */
  icon?: React.ReactNode;
  actionLabel?: string;
  /** Appends "disponível offline" to the meta line. */
  offline?: boolean;
  /** Whose document it is, when it matters. */
  participant?: string;
  onOpen?: () => void;
}

export function TcDocumentRow(props: TcDocumentRowProps): React.JSX.Element;
