QR mode — the screen exists to be scanned.

```jsx
<TcQrViewer size={220} code="DRT-77412" identity="Vinícius Batista · assento 12" />
```

No decoration, no editorial type. Brightness and wake-lock are annotated behaviours, not visible controls.
