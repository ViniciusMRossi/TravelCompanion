Document row — a ticket must open in one or two taps.

```jsx
<TcDocumentRow icon="🎫" title="Ônibus Ksamil → Budva" meta="16 set" />
<TcDocumentRow icon="🛡️" title="Seguro viagem" meta="Toda a viagem · PDF" />
```

The whole row is the target (48px minimum). Offline availability is stated, not implied.
