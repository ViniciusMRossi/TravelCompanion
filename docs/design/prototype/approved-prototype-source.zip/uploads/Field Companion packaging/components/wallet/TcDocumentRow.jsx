import React from "react";

/**
 * Document row — speed over beauty. 14px radius, 14px padding, 42px icon tile
 * with 12px radius (gallery values).
 */
export function TcDocumentRow({
  title,
  meta,
  icon = "🎫",
  actionLabel = "Abrir",
  offline = true,
  participant,
  onOpen,
  style,
  ...rest
}) {
  return (
    <button
      type="button"
      onClick={onOpen}
      style={{
        display: "flex",
        alignItems: "center",
        gap: "14px",
        padding: "14px",
        border: "1px solid var(--tc-border-default)",
        borderRadius: "var(--tc-radius-operational-card)",
        background: "var(--tc-bg-surface)",
        width: "100%",
        minHeight: "var(--tc-touch-min)",
        textAlign: "left",
        font: "inherit",
        fontFamily: "var(--tc-font-ui)",
        color: "var(--tc-text-primary)",
        cursor: "pointer",
        ...style
      }}
      {...rest}
    >
      <span
        aria-hidden="true"
        style={{
          width: "42px",
          height: "42px",
          borderRadius: "12px",
          background: "var(--tc-bg-subtle)",
          display: "grid",
          placeItems: "center",
          fontSize: "20px",
          flex: "0 0 auto"
        }}
      >
        {icon}
      </span>
      <span style={{ flex: 1, minWidth: 0 }}>
        <span style={{ display: "block", fontWeight: "var(--tc-weight-bold)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{title}</span>
        <span style={{ display: "block", fontSize: "var(--tc-label-small-size)", color: "var(--tc-text-secondary)", marginTop: "3px" }}>
          {[meta, participant, offline ? "disponível offline" : null].filter(Boolean).join(" · ")}
        </span>
      </span>
      <span style={{ fontWeight: "var(--tc-weight-bold)", color: "var(--tc-text-link)", fontSize: "13px", flex: "0 0 auto" }}>{actionLabel}</span>
    </button>
  );
}
