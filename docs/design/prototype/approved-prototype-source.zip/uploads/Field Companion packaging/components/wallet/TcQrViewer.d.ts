import * as React from "react";

/**
 * QR mode viewer. Raises brightness and keeps the screen awake (annotate this
 * behaviour in handoff); the visual carries only what staff need to identify.
 * @startingPoint section="Carteira" subtitle="QR mode, minimum surrounding UI" viewport="412x340"
 */
export interface TcQrViewerProps extends React.HTMLAttributes<HTMLElement> {
  label?: string;
  /** Code side in px. Use 220+ on the full QR screen. */
  size?: number;
  note?: string;
  /** Passenger/holder line, e.g. "Vinícius Batista · assento 12". */
  identity?: string;
  /** Human-readable booking code shown under the QR. */
  code?: string;
}

export function TcQrViewer(props: TcQrViewerProps): React.JSX.Element;
