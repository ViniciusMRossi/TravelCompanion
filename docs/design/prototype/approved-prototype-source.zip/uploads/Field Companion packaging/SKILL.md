---
name: field-companion-design
description: Use this skill to generate well-branded interfaces and assets for Travel Companion (Field Companion design system), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for protoyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Notas específicas deste sistema:

- Interface em português do Brasil. Strings aprovadas não são reescritas.
- Fraunces (600) só em conteúdo editorial; Roboto em tudo operacional. Fraunces
  nunca em horário, ticket, botão ou aviso crítico.
- Inventário de componentes fechado (27 nomes `Tc*`). Não adicione primitivos.
- Artboard Android 412×915, coluna única, gutter 20dp, toque mínimo 48dp.
- Offline é modo normal; crítico é dimensão adicional ao status de reserva.
- Não existe login, sala, convite, código de pareamento ou recurso social.
- Não há logo: use o nome em tipografia simples.
