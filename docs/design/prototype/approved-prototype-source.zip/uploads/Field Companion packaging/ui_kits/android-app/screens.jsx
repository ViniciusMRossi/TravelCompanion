
/* Field Companion — Android UI kit screens.
   Recreates the 18 screens listed in SCREEN-DELIVERABLES.md at 412×915.
   Content is the reference trip (Mochilão pelos Bálcãs). Nothing here invents
   screens that the deliverables list does not specify. */

window.TcKitFactory = function (TC) {
  const {
    TcButton, TcIconButton, TcChip, TcStatusChip, TcCard, TcSectionHeader, TcOfflineStatus,
    TcNowCard, TcCriticalCard, TcTimeline, TcTimelineItem, TcWeatherSummary, TcOutfitCard,
    TcCityHero, TcAttractionHero, TcStoryCard,
    TcTransportCard, TcAccommodationCard, TcPlanBCard, TcEmergencyAction,
    TcAudioPlayer, TcGroupAudioStatus, TcParticipantStatus, TcWalkProgress, TcVoiceRecorder,
    TcDocumentRow, TcQrViewer
  } = TC;

  const G = "var(--tc-gutter)";
  const SPRITE = "#tc-"; // sprite injected by assets/icons/tc-icons.js

  /* Field Companion icon set (assets/icons/tc-icons.svg). Material Symbols
     Rounded stays available for pictograms the native set does not cover. */
  function Icon({ name, size = 24, style }) {
    if (name && name.indexOf("tc-") === 0) {
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" style={{ display: "block", flex: "0 0 auto", ...style }}>
          <use href={SPRITE + name.slice(3)} />
        </svg>
      );
    }
    return <span className="tc-icon" aria-hidden="true" style={{ fontSize: size + "px", ...style }}>{name}</span>;
  }

  /* ---------- chrome ---------- */

  function StatusBar({ onInk }) {
    const c = onInk ? "var(--tc-on-ink-primary)" : "var(--tc-text-primary)";
    return (
      <div style={{ height: "28px", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px", fontSize: "12px", fontWeight: 500, color: c, flex: "0 0 auto" }}>
        <span className="tc-tabular">09:24</span>
        <span style={{ display: "flex", gap: "6px", alignItems: "center", fontSize: "11px" }}>
          <span className="tc-icon" style={{ fontSize: "14px" }}>signal_cellular_alt</span>
          <Icon name="tc-offline" size={14} />
          <span className="tc-icon" style={{ fontSize: "14px" }}>battery_5_bar</span>
        </span>
      </div>
    );
  }

  function AppBar({ title, subtitle, onInk, back, actions, trailing }) {
    return (
      <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "6px 12px 10px", flex: "0 0 auto" }}>
        {back ? (
          <TcIconButton onInk={onInk} variant="ghost" label="Voltar" icon={<Icon name="tc-arrow-left" />} />
        ) : null}
        <div style={{ flex: 1, minWidth: 0, paddingLeft: back ? 0 : "8px" }}>
          <div style={{ fontWeight: 700, fontSize: "16px", color: onInk ? "var(--tc-on-ink-primary)" : "var(--tc-text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{title}</div>
          {subtitle ? (
            <div style={{ fontSize: "12px", color: onInk ? "var(--tc-on-ink-muted)" : "var(--tc-text-secondary)", marginTop: "2px" }}>{subtitle}</div>
          ) : null}
        </div>
        {trailing}
        {actions}
      </div>
    );
  }

  const NAV = [
    { id: "hoje", label: "Hoje", icon: "tc-calendar" },
    { id: "viagem", label: "Viagem", icon: "tc-map" },
    { id: "explorar", label: "Explorar", icon: "tc-compass" },
    { id: "carteira", label: "Carteira", icon: "tc-wallet" },
    { id: "mais", label: "Mais", icon: "tc-more-horiz" }
  ];

  function BottomNav({ active = "hoje", onNavigate }) {
    return (
      <nav style={{ flex: "0 0 auto", background: "var(--tc-bg-surface)", borderTop: "1px solid var(--tc-border-default)", boxShadow: "var(--tc-shadow-1)", paddingBottom: "var(--tc-gesture-area)" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)" }}>
          {NAV.map(n => {
            const on = n.id === active;
            return (
              <button key={n.id} type="button" onClick={() => onNavigate && onNavigate(n.id)}
                style={{ border: 0, background: "transparent", cursor: "pointer", minHeight: "var(--tc-touch-min)", padding: "8px 0 6px", display: "grid", justifyItems: "center", gap: "3px", font: "inherit", fontFamily: "var(--tc-font-ui)", color: on ? "var(--tc-primary-subtle-fg)" : "var(--tc-neutral-600)" }}>
                <span style={{ background: on ? "var(--tc-primary-subtle-bg)" : "transparent", borderRadius: "var(--tc-radius-pill)", padding: "3px 14px", display: "grid", placeItems: "center" }}>
                  <Icon name={n.icon} />
                </span>
                <span style={{ fontSize: "11px", fontWeight: on ? 700 : 500 }}>{n.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    );
  }

  function Screen({ children, ink, scroll = true, style }) {
    return (
      <div className="tc-root" style={{ width: "412px", height: "915px", display: "flex", flexDirection: "column", background: ink ? "var(--tc-bg-inverse)" : "var(--tc-bg-app)", overflow: "hidden", ...style }}>
        {children}
      </div>
    );
  }

  function Body({ children, pad = true, style }) {
    return (
      <div className="tcbody" style={{ flex: 1, overflowY: "auto", padding: pad ? "0 " + G + " 24px" : 0, display: "flex", flexDirection: "column", gap: "16px", ...style }}>
        {children}
      </div>
    );
  }

  function Row({ children, gap = "10px", style }) {
    return <div style={{ display: "flex", flexWrap: "wrap", gap, ...style }}>{children}</div>;
  }

  function Note({ children }) {
    return <p style={{ margin: 0, fontSize: "var(--tc-body-small-size)", lineHeight: "var(--tc-body-small-line)", color: "var(--tc-text-secondary)" }}>{children}</p>;
  }

  function Editorial({ children }) {
    return <p style={{ margin: 0, fontSize: "var(--tc-body-large-size)", lineHeight: "var(--tc-body-large-line)", color: "var(--tc-neutral-800)" }}>{children}</p>;
  }

  function ListCard({ items }) {
    return (
      <div style={{ background: "var(--tc-bg-surface)", border: "1px solid var(--tc-border-default)", borderRadius: "var(--tc-radius-operational-card)", overflow: "hidden" }}>
        {items.map((it, i) => (
          <button key={i} type="button" style={{ width: "100%", display: "flex", alignItems: "center", gap: "14px", minHeight: "56px", padding: "12px 14px", border: 0, borderTop: i ? "1px solid var(--tc-border-default)" : "none", background: "transparent", font: "inherit", fontFamily: "var(--tc-font-ui)", color: "var(--tc-text-primary)", textAlign: "left", cursor: "pointer" }}>
            <Icon name={it.icon} style={{ color: "var(--tc-teal)" }} />
            <span style={{ flex: 1, minWidth: 0 }}>
              <span style={{ display: "block", fontWeight: 500 }}>{it.label}</span>
              {it.meta ? <span style={{ display: "block", fontSize: "12px", color: "var(--tc-text-secondary)", marginTop: "2px" }}>{it.meta}</span> : null}
            </span>
            <Icon name="tc-chevron-right" size={20} style={{ color: "var(--tc-neutral-400)" }} />
          </button>
        ))}
      </div>
    );
  }

  /* ---------- 01 ---------- */
  function WhoAreYou({ go }) {
    return (
      <Screen>
        <StatusBar />
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "24px " + G + " 32px" }}>
          <div>
            <div style={{ fontSize: "var(--tc-eyebrow-size)", fontWeight: 700, letterSpacing: "var(--tc-eyebrow-tracking)", textTransform: "uppercase", color: "var(--tc-teal)" }}>Travel Companion</div>
            <h1 className="tc-display" style={{ fontSize: "var(--tc-display-large-size)", lineHeight: "var(--tc-display-large-line)", margin: "10px 0 12px" }}>Mochilão pelos Bálcãs</h1>
            <Editorial>21 dias entre Albânia, Montenegro, Bósnia e Herzegovina. O itinerário, os audioguias e os documentos já estão neste aparelho.</Editorial>
          </div>
          <div style={{ borderRadius: "var(--tc-radius-xl)", overflow: "hidden", minHeight: "180px", backgroundImage: "linear-gradient(to top, rgba(22,35,46,.55), rgba(22,35,46,.05)), linear-gradient(135deg, #89A7A5, #D2C6A8 46%, #728B85)", position: "relative" }}>
            <span style={{ position: "absolute", top: "12px", left: "14px", fontFamily: "var(--tc-font-mono)", fontSize: "11px", padding: "4px 7px", borderRadius: "var(--tc-radius-xs)", background: "rgba(22,35,46,.42)", color: "#F2EFE7" }}>foto de abertura</span>
          </div>
          <div>
            <h2 style={{ fontSize: "var(--tc-heading-2-size)", lineHeight: "var(--tc-heading-2-line)", fontWeight: 700, margin: "0 0 4px" }}>Quem é você?</h2>
            <Note>A escolha fica salva neste aparelho e pode ser alterada em Configurações.</Note>
            <div style={{ display: "grid", gap: "10px", marginTop: "16px" }}>
              <TcButton variant="primary" full style={{ minHeight: "56px", justifyContent: "flex-start", gap: "12px" }} onClick={() => go && go("today")}>Vinícius</TcButton>
              <TcButton variant="secondary" full style={{ minHeight: "56px", justifyContent: "flex-start", gap: "12px" }} onClick={() => go && go("today")}>Érika</TcButton>
            </div>
          </div>
        </div>
      </Screen>
    );
  }

  /* ---------- 02 ---------- */
  function Today({ go, nav }) {
    return (
      <Screen>
        <StatusBar />
        <AppBar title="Ksamil · Albânia" subtitle="Sábado, 16 de setembro · dia 6 de 21"
          trailing={<TcOfflineStatus mode="offlineAvailable" variant="chip" label="Offline" />} />
        <Body>
          <TcNowCard time="08:30" title="Butrinto"
            description="Cidade arqueológica, Patrimônio Mundial. Reserve cerca de 2h30 para o percurso principal."
            meta="Audioguia disponível offline"
            actions={<><TcButton variant="primary" onInk compact onClick={() => go && go("attraction")}>Ver atração</TcButton><TcButton variant="secondary" onInk compact>Abrir no Maps</TcButton></>} />

          <TcCriticalCard time="19:30" title="Ônibus para Budva"
            reason="Esteja no ponto até 19:00. Leve o passaporte e deixe o bilhete aberto offline."
            actions={<><TcButton variant="primary" onClick={() => go && go("documentQr")}>Mostrar passagem</TcButton><TcButton variant="secondary" onClick={() => go && go("transport")}>Ver embarque</TcButton></>} />

          <TcCard padding="18px">
            <TcWeatherSummary temperature="26°" condition="Ensolarado" rain="10%" range="21° / 29°" freshness="live" freshnessLabel="Atualizado há 24 min">
              <TcOutfitCard wear={["Camiseta", "shorts", "tênis confortável", "protetor solar"]} carry={["Repelente", "água", "powerbank"]} />
            </TcWeatherSummary>
          </TcCard>

          <div>
            <TcSectionHeader eyebrow="Hoje" title="Próximos" action={<TcButton variant="text" onClick={() => go && go("fullDay")}>Dia completo</TcButton>} />
            <TcTimeline items={[
              { time: "08:30", title: "Butrinto", detail: "Atração · audioguia disponível", state: "completed" },
              { time: "13:00", title: "Retorno para Ksamil", detail: "Ônibus local · pagar em dinheiro", state: "active" },
              { time: "15:00", title: "Praia", detail: "Tempo livre", state: "upcoming" },
              { time: "19:30", title: "Ônibus para Budva", detail: "Chegar ao ponto às 19:00", state: "critical", trailing: <TcStatusChip status="critical" /> }
            ]} />
          </div>

          <div>
            <TcSectionHeader eyebrow="Atalhos" title="Do dia" />
            <div style={{ display: "grid", gap: "10px" }}>
              <TcDocumentRow icon="🎫" title="Ônibus Ksamil → Budva" meta="16 set" onOpen={() => go && go("documentQr")} />
              <ListCard items={[
                { icon: "tc-alt-route", label: "Plano B do dia", meta: "Se perdermos o ônibus para Budva" },
                { icon: "tc-mic", label: "Gravar memória", meta: "Voz · salva com local e horário" }
              ]} />
            </div>
          </div>
        </Body>
        <BottomNav active="hoje" onNavigate={nav} />
      </Screen>
    );
  }

  /* ---------- 03 ---------- */
  function FullDay({ nav }) {
    return (
      <Screen>
        <StatusBar />
        <AppBar back title="Dia completo" subtitle="16 de setembro · Ksamil → Budva" />
        <Body>
          <TcCriticalCard time="19:30" title="Ônibus para Budva" reason="Esteja no ponto até 19:00. Passaporte obrigatório." />
          <TcCard padding="18px">
            <TcTimeline items={[
              { time: "07:30", title: "Café na hospedagem", detail: "Incluído", state: "completed" },
              { time: "08:00", title: "Ksamil → Butrinto", detail: "Transporte · ônibus local, 30 min", state: "completed" },
              { time: "08:30", title: "Butrinto", detail: "Atração · Patrimônio Mundial · ~2h30", state: "completed" },
              { time: "13:00", title: "Retorno para Ksamil", detail: "Ônibus local · pagar em dinheiro", state: "active" },
              { time: "13:40", title: "Almoço em Ksamil", detail: "Tempo livre · peixe grelhado no porto", state: "upcoming" },
              { time: "15:00", title: "Praia", detail: "Tempo livre", state: "upcoming" },
              { time: "18:00", title: "Check-out Vila Emiljano", detail: "Hospedagem · deixar a chave com a proprietária", state: "upcoming" },
              { time: "19:30", title: "Ônibus para Budva", detail: "Chegar ao ponto às 19:00 · Drita Travel", state: "critical", trailing: <TcStatusChip status="critical" /> }
            ]} />
          </TcCard>

          <TcSectionHeader eyebrow="Transporte" title="Do dia" />
          <TcTransportCard status="booked" operator="Drita Travel" origin="Ksamil" destination="Budva · +1 dia"
            departure="19:30" arrival="11:07" critical="Check-in 19:00" note="Ônibus internacional · passaporte obrigatório" />

          <TcSectionHeader eyebrow="Hospedagem" title="Saída e chegada" />
          <TcAccommodationCard name="Vila Emiljano" address="Rruga e Plazhit, Ksamil" status="confirmed"
            checkIn="15 set · 14:00" checkOut="16 set · 10:00" nights="1 noite" note="Chave com a proprietária. Bagagem pode ficar até 18:00." />

          <TcSectionHeader eyebrow="Documentos" title="Do dia" />
          <div style={{ display: "grid", gap: "10px" }}>
            <TcDocumentRow icon="🎫" title="Ônibus Ksamil → Budva" meta="16 set" />
            <TcDocumentRow icon="🏨" title="Vila Emiljano — voucher" meta="15–16 set · hospedagem" />
          </div>

          <TcPlanBCard scenario="Se perdermos o ônibus para Budva"
            consequence="A próxima saída internacional pode ser só no dia seguinte."
            steps={["Vá até o ponto/rodoviária e confirme a próxima saída.", "Verifique conexão por Sarandë ou Shkodër.", "Se não houver opção segura, use a hospedagem emergencial cadastrada."]}
            actions={<><TcButton variant="secondary">Abrir no Maps</TcButton><TcButton variant="text">Ver hospedagem emergencial</TcButton></>} />
        </Body>
      </Screen>
    );
  }

  /* ---------- 04 ---------- */
  function City({ go, nav }) {
    return (
      <Screen>
        <StatusBar />
        <Body pad={false} style={{ gap: 0 }}>
          <div style={{ padding: "0 0 16px" }}>
            <TcCityHero city="Sarajevo" country="Bósnia e Herzegovina 🇧🇦" dates="19–21 de setembro · 3 dias" height={320} radius="0 0 var(--tc-radius-xl) var(--tc-radius-xl)" />
          </div>
          <div className="tcbody" style={{ padding: "0 " + G + " 24px", display: "flex", flexDirection: "column", gap: "16px" }}>
            <Editorial>Sarajevo cresceu como cidade de encontro: mesquitas otomanas, prédios austro-húngaros, uma catedral católica e uma sinagoga a poucos minutos de caminhada um do outro.</Editorial>
            <Row>
              <TcChip tone="primary">Audioguia da cidade</TcChip>
              <TcChip tone="neutral">3 passeios</TcChip>
              <TcChip tone="neutral">12 histórias</TcChip>
            </Row>

            <TcAudioPlayer title="Sarajevo em 20 minutos" chapter="Audioguia da cidade · capítulo 1 de 6"
              progress={0} elapsed="00:00" total="19:42" state="idle" />

            <div>
              <TcSectionHeader eyebrow="História" title="Em capítulos" />
              <div style={{ display: "grid", gap: "10px" }}>
                <TcStoryCard chip="Capítulo 2" title="O império que virou esquina" hook="Como a arquitetura mudou de lado da rua em menos de cinquenta anos." />
                <TcStoryCard chip="Capítulo 3" title="1914, em vinte metros" hook="A esquina onde a Primeira Guerra começou continua sendo uma esquina comum." />
              </div>
            </div>

            <div>
              <TcSectionHeader eyebrow="Explorar" title="Atrações" />
              <div style={{ display: "grid", gap: "12px" }}>
                <TcAttractionHero name="Baščaršija" location="SARAJEVO · BÓSNIA E HERZEGOVINA" meta="Bazar otomano · ~1h"
                  lead="O centro antigo de Sarajevo, com oficinas de cobre que ainda funcionam."
                  actions={<><TcButton variant="tonal" icon={<Icon name="tc-headphones" size={20} />}>Ouvir audioguia</TcButton><TcButton variant="secondary">Abrir no Maps</TcButton></>} />
              </div>
            </div>

            <div>
              <TcSectionHeader eyebrow="Passeios" title="Guiados por GPS" />
              <ListCard items={[
                { icon: "directions_walk", label: "Sarajevo Historical Walk", meta: "2,4 km · ~75 min · 7 histórias" },
                { icon: "directions_walk", label: "Sarajevo do cerco", meta: "3,1 km · ~90 min · 9 histórias" }
              ]} />
              <div style={{ marginTop: "10px" }}>
                <TcButton variant="primary" full onClick={() => go && go("walkPrestart")}>Ver passeio histórico</TcButton>
              </div>
            </div>

            <div>
              <TcSectionHeader eyebrow="Comer" title="Restaurantes" />
              <ListCard items={[
                { icon: "restaurant", label: "Ćevabdžinica Željo", meta: "Ćevapi · dinheiro · Baščaršija" },
                { icon: "restaurant", label: "Buregdžinica Bosna", meta: "Burek · aberto até 22:00" }
              ]} />
            </div>

            <div>
              <TcSectionHeader eyebrow="Pelo caminho" title="Pequenas histórias" />
              <div style={{ display: "grid", gap: "10px" }}>
                <TcStoryCard title="As rosas de Sarajevo" hook="Marcas de morteiro preenchidas com resina vermelha, espalhadas pela cidade." chip="2 min" />
              </div>
            </div>
          </div>
        </Body>
        <BottomNav active="explorar" onNavigate={nav} />
      </Screen>
    );
  }

  /* ---------- 05 ---------- */
  function Attraction({ go }) {
    return (
      <Screen>
        <StatusBar />
        <Body pad={false} style={{ gap: 0 }}>
          <TcAttractionHero variant="bleed" name="Stari Most" location="MOSTAR · BÓSNIA E HERZEGOVINA"
            meta="Patrimônio Mundial · ~1h30" style={{ borderRadius: 0 }}
            lead="A ponte otomana é o símbolo mais conhecido de Mostar e um dos pontos onde a história recente da cidade fica mais visível."
            actions={<><TcButton variant="tonal" icon={<Icon name="tc-headphones" size={20} />}>Ouvir audioguia</TcButton><TcButton variant="secondary">Abrir no Maps</TcButton></>} />
          <div className="tcbody" style={{ padding: "16px " + G + " 24px", display: "flex", flexDirection: "column", gap: "16px" }}>
            <TcCard>
              <TcSectionHeader eyebrow="Prático" title="Informações" />
              <div style={{ display: "grid", gap: "8px", fontSize: "var(--tc-body-size)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: "12px" }}><span style={{ color: "var(--tc-text-secondary)" }}>Entrada</span><strong>Livre · ponte</strong></div>
                <div style={{ display: "flex", justifyContent: "space-between", gap: "12px" }}><span style={{ color: "var(--tc-text-secondary)" }}>Museu da ponte</span><strong className="tc-tabular">6 KM · 09:00–18:00</strong></div>
                <div style={{ display: "flex", justifyContent: "space-between", gap: "12px" }}><span style={{ color: "var(--tc-text-secondary)" }}>Como chegar</span><strong>10 min a pé do centro</strong></div>
                <div style={{ display: "flex", justifyContent: "space-between", gap: "12px" }}><span style={{ color: "var(--tc-text-secondary)" }}>Piso</span><strong>Pedra lisa e inclinada</strong></div>
              </div>
              <div style={{ marginTop: "14px" }}><TcButton variant="secondary" full>Como chegar</TcButton></div>
            </TcCard>

            <div>
              <TcSectionHeader eyebrow="História" title="A ponte e a reconstrução" />
              <Editorial>Construída no século XVI e destruída em 1993, a ponte foi reerguida com pedra da mesma região e reaberta em 2004. Parte dos blocos originais foi retirada do rio.</Editorial>
            </div>

            <div>
              <TcSectionHeader eyebrow="Curiosidades" title="Três coisas" />
              <ul style={{ margin: 0, paddingLeft: "20px", color: "var(--tc-neutral-800)", fontSize: "var(--tc-body-size)", lineHeight: "var(--tc-body-line)" }}>
                <li style={{ marginBottom: "8px" }}>Os saltos da ponte são uma tradição local desde 1664.</li>
                <li style={{ marginBottom: "8px" }}>A pedra fica escorregadia com qualquer chuva.</li>
                <li>As duas torres, Halebija e Tara, guardavam a passagem.</li>
              </ul>
            </div>

            <TcCard tone="subtle">
              <TcSectionHeader eyebrow="O que observar" title="Ao atravessar" />
              <Note>Olhe para a junta das pedras no meio do arco: a diferença de cor separa o que é original do que foi reconstruído.</Note>
            </TcCard>

            <TcPlanBCard scenario="Se a ponte estiver fechada para evento"
              steps={["Veja a vista da margem oeste, ao lado do museu.", "O audioguia funciona igual — ouça no mirante."]} />
          </div>
        </Body>
      </Screen>
    );
  }

  /* ---------- 06 ---------- */
  function WalkPrestart({ go }) {
    return (
      <Screen>
        <StatusBar />
        <Body pad={false} style={{ gap: 0 }}>
          <TcCityHero city="Sarajevo Historical Walk" country="PASSEIO GUIADO POR GPS" dates="2,4 km · ~75 min · 7 histórias" height={280} radius="0" imageNote="foto do percurso" />
          <div className="tcbody" style={{ padding: "16px " + G + " 24px", display: "flex", flexDirection: "column", gap: "16px" }}>
            <Editorial>Da Baščaršija até a Latin Bridge, passando pela linha onde a cidade otomana encontra a austro-húngara.</Editorial>
            <TcCard>
              <div style={{ display: "grid", gap: "10px" }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>Rota</span><strong>Baščaršija → Latin Bridge</strong></div>
                <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>Distância</span><strong className="tc-tabular">2,4 km</strong></div>
                <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>Tempo</span><strong className="tc-tabular">~75 min</strong></div>
                <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>Histórias</span><strong className="tc-tabular">7 · 42 min de áudio</strong></div>
                <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>Áudio</span><strong>Baixado neste aparelho</strong></div>
              </div>
            </TcCard>

            <TcCard>
              <div style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
                <Icon name="tc-notifications" style={{ color: "var(--tc-teal)" }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700 }}>Histórias automáticas</div>
                  <Note>Durante o passeio, o app avisa quando vocês chegarem perto de um lugar interessante, mesmo com a tela apagada.</Note>
                </div>
                <span style={{ width: "44px", height: "26px", borderRadius: "var(--tc-radius-pill)", background: "var(--tc-primary-bg)", position: "relative", flex: "0 0 auto" }}>
                  <span style={{ position: "absolute", top: "3px", right: "3px", width: "20px", height: "20px", borderRadius: "var(--tc-radius-pill)", background: "#fff" }} />
                </span>
              </div>
            </TcCard>

            <div>
              <TcSectionHeader eyebrow="Ouvir juntos" title="Participantes" note="O grupo da viagem já existe — não há código nem convite." />
              <Row>
                <TcParticipantStatus name="Vinícius" state="synchronized" />
                <TcParticipantStatus name="Érika" state="synchronized" />
              </Row>
            </div>

            <TcButton variant="primary" full style={{ minHeight: "56px" }} onClick={() => go && go("walkActive")}>Começar passeio</TcButton>
            <Note>Vocês podem guardar o celular. O áudio continua com a tela apagada.</Note>
          </div>
        </Body>
      </Screen>
    );
  }

  /* ---------- 07 ---------- */
  function WalkActive({ go }) {
    return (
      <Screen ink>
        <StatusBar onInk />
        <AppBar onInk back title="Modo Passeio" subtitle="Sarajevo Historical Walk" />
        <div className="tcbody" style={{ flex: 1, overflowY: "auto", padding: "0 " + G + " 24px", display: "flex", flexDirection: "column", gap: "16px" }}>
          <TcWalkProgress tour="Sarajevo Historical Walk" progressLabel="3 de 7 histórias" remainingLabel="~28 min restantes"
            instruction="Continuem pela Ferhadija. Em alguns minutos vocês vão perceber uma mudança muito clara na arquitetura."
            nextTitle="Sarajevo Meeting of Cultures" nextDistance="~180 m" gpsState="active">
            <TcGroupAudioStatus onInk title="Ouvindo juntos" participants={[
              { name: "Vinícius", state: "synchronized", showLabel: false },
              { name: "Érika", state: "synchronized", showLabel: false }
            ]} />
          </TcWalkProgress>

          <TcAudioPlayer title="Latin Bridge" chapter="História 3 de 7" progress={53} elapsed="04:32" total="08:41" state="playing"
            onToggle={() => {}} />

          <TcStoryCard tone="ink" chip="Tocando agora" title="1914, em vinte metros"
            hook="A esquina onde a Primeira Guerra começou continua sendo uma esquina comum." />

          <div style={{ display: "grid", gap: "10px", marginTop: "auto" }}>
            <TcButton variant="secondary" onInk full style={{ minHeight: "56px" }}>Pausar passeio</TcButton>
            <TcButton variant="text" onInk full onClick={() => go && go("memoryIdle")}>Encerrar passeio</TcButton>
          </div>
        </div>
      </Screen>
    );
  }

  /* ---------- 08 ---------- */
  function SharedAudio({ variant = "synchronized" }) {
    const participants = variant === "synchronized"
      ? [{ name: "Vinícius", state: "synchronized" }, { name: "Érika", state: "synchronized" }]
      : [{ name: "Vinícius", state: "synchronized" }, { name: "Érika", state: "resyncing" }];
    return (
      <Screen>
        <StatusBar />
        <AppBar back title="Audioguia compartilhado" subtitle="Sarajevo Historical Walk" />
        <Body>
          <div style={{ borderRadius: "var(--tc-radius-lg)", minHeight: "220px", backgroundImage: "linear-gradient(to top, rgba(22,35,46,.7), rgba(22,35,46,.05)), linear-gradient(135deg, #89A7A5, #D2C6A8 46%, #728B85)", position: "relative", display: "flex", alignItems: "flex-end", padding: "18px", color: "var(--tc-on-ink-primary)" }}>
            <span style={{ position: "absolute", top: "12px", left: "14px", fontFamily: "var(--tc-font-mono)", fontSize: "11px", padding: "4px 7px", borderRadius: "var(--tc-radius-xs)", background: "rgba(22,35,46,.42)", color: "#F2EFE7" }}>foto do capítulo</span>
            <div>
              <div style={{ fontSize: "12px", textTransform: "uppercase", letterSpacing: "var(--tc-label-tracking)", opacity: .85, fontWeight: 700 }}>Capítulo 5</div>
              <h2 className="tc-display" style={{ fontSize: "var(--tc-display-small-size)", lineHeight: "var(--tc-display-small-line)", margin: "6px 0 0" }}>Latin Bridge</h2>
            </div>
          </div>

          <TcAudioPlayer variant="full" title="Latin Bridge" chapter="Sarajevo Historical Walk · capítulo 5"
            progress={53} elapsed="04:32" total="08:41" state="playing" participants={participants}
            groupMessage={variant === "synchronized" ? null : "Não foi possível sincronizar o grupo. Seu audioguia continua funcionando normalmente."} />

          <Row>
            <TcButton variant="tonal" icon={<Icon name="tc-group" size={20} />}>Ouvir juntos</TcButton>
            <TcButton variant="secondary" icon={<Icon name="tc-document" size={20} />}>Transcrição</TcButton>
          </Row>

          <TcCard tone="subtle">
            <TcSectionHeader eyebrow="Transcrição" title="Trecho atual" />
            <Note>“Em 28 de junho de 1914, o arquiduque Franz Ferdinand passou por esta esquina depois de uma mudança de rota que nunca chegou ao motorista…”</Note>
          </TcCard>
        </Body>
      </Screen>
    );
  }

  /* ---------- 09 ---------- */
  function StoryTrigger() {
    return (
      <Screen ink>
        <StatusBar onInk />
        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "flex-end", padding: "0 0 0" }}>
          <div style={{ padding: "0 " + G, opacity: .5 }}>
            <TcWalkProgress tour="Sarajevo Historical Walk" progressLabel="3 de 7 histórias" remainingLabel="~28 min restantes" />
          </div>
          <div style={{ marginTop: "20px", background: "var(--tc-bg-surface)", borderRadius: "var(--tc-radius-xl) var(--tc-radius-xl) 0 0", padding: "8px " + G + " 28px", boxShadow: "var(--tc-shadow-2)" }}>
            <div style={{ width: "42px", height: "4px", borderRadius: "999px", background: "var(--tc-neutral-300)", margin: "0 auto 18px" }} />
            <TcChip tone="primary" dot>História pelo caminho</TcChip>
            <h2 className="tc-display" style={{ fontSize: "var(--tc-display-small-size)", lineHeight: "var(--tc-display-small-line)", margin: "14px 0 8px" }}>Onde Oriente e Ocidente se encontram</h2>
            <Editorial>Vocês estão chegando a um ponto onde a arquitetura otomana encontra a austro-húngara. A mudança acontece em menos de vinte metros de calçada.</Editorial>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", margin: "14px 0 18px", color: "var(--tc-text-secondary)", fontSize: "var(--tc-body-small-size)" }}>
              <Icon name="tc-near-me" size={18} />
              <span>~40 m à frente · 3 min de áudio</span>
            </div>
            <div style={{ display: "grid", gap: "10px" }}>
              <TcButton variant="primary" full icon={<Icon name="tc-play" size={20} />} style={{ minHeight: "56px" }}>Ouvir agora</TcButton>
              <Row style={{ display: "grid", gridTemplateColumns: "1fr 1fr" }}>
                <TcButton variant="secondary">Ler</TcButton>
                <TcButton variant="text">Depois</TcButton>
              </Row>
            </div>
            <Note>Com histórias automáticas ligadas, o áudio começa sozinho depois de um sinal curto.</Note>
          </div>
        </div>
      </Screen>
    );
  }

  /* ---------- 10 ---------- */
  function Wallet({ go, nav }) {
    return (
      <Screen>
        <StatusBar />
        <AppBar title="Carteira" subtitle="Mochilão pelos Bálcãs · 21 dias"
          trailing={<TcOfflineStatus mode="offlineAvailable" variant="chip" label="Offline" />} />
        <Body>
          <div>
            <TcSectionHeader eyebrow="Hoje" title="16 de setembro" />
            <div style={{ display: "grid", gap: "10px" }}>
              <TcDocumentRow icon="🎫" title="Ônibus Ksamil → Budva" meta="16 set · 19:30" onOpen={() => go && go("documentQr")} />
              <TcDocumentRow icon="🏨" title="Vila Emiljano — voucher" meta="15–16 set" />
            </div>
          </div>
          <div>
            <TcSectionHeader eyebrow="Transporte" title="Toda a viagem" />
            <div style={{ display: "grid", gap: "10px" }}>
              <TcDocumentRow icon="🎫" title="Ônibus Budva → Žabljak" meta="18 set · 07:15" />
              <TcDocumentRow icon="🎫" title="Ônibus Žabljak → Sarajevo" meta="19 set · 08:00" />
              <TcDocumentRow icon="✈️" title="Sarajevo → Guarulhos" meta="6 out · 14:35 · Turkish Airlines" />
            </div>
          </div>
          <div>
            <TcSectionHeader eyebrow="Hospedagem" title="Vouchers" />
            <div style={{ display: "grid", gap: "10px" }}>
              <TcDocumentRow icon="🏨" title="Apartmani Budva" meta="16–18 set" />
              <TcDocumentRow icon="🏨" title="Eko Kuća Žabljak" meta="18–19 set" />
            </div>
          </div>
          <div>
            <TcSectionHeader eyebrow="Seguro e documentos" title="Sempre disponíveis" />
            <div style={{ display: "grid", gap: "10px" }}>
              <TcDocumentRow icon="🛡️" title="Seguro viagem" meta="Toda a viagem · PDF" />
              <TcDocumentRow icon="🪪" title="Passaporte — Vinícius" meta="Válido até 2031" participant="Vinícius" />
              <TcDocumentRow icon="🪪" title="Passaporte — Érika" meta="Válido até 2029" participant="Érika" />
            </div>
          </div>
        </Body>
        <BottomNav active="carteira" onNavigate={nav} />
      </Screen>
    );
  }

  /* ---------- 11 ---------- */
  function DocumentQr() {
    return (
      <Screen>
        <StatusBar />
        <AppBar back title="Ônibus Ksamil → Budva" subtitle="Drita Travel · 16 set, 19:30"
          actions={<TcIconButton variant="ghost" label="Compartilhar" icon={<Icon name="tc-document" />} />} />
        <Body>
          <TcQrViewer size={240} label="PASSAGEM · ÔNIBUS INTERNACIONAL" code="DRT-77412" identity="Vinícius Batista · assento 12" />
          <TcCard>
            <div style={{ display: "grid", gap: "10px" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>Embarque</span><strong>Ponto na Rruga e Plazhit</strong></div>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>Chegar até</span><strong className="tc-tabular">19:00</strong></div>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>Documento</span><strong>Passaporte obrigatório</strong></div>
            </div>
          </TcCard>
          <TcOfflineStatus mode="offlineAvailable" label="Disponível offline · não depende de internet" />
          <Row>
            <TcButton variant="secondary">Ver embarque no Maps</TcButton>
            <TcButton variant="text">Abrir PDF</TcButton>
          </Row>
          <Note>Em modo QR o brilho vai ao máximo e a tela permanece ativa até fechar.</Note>
        </Body>
      </Screen>
    );
  }

  /* ---------- 12 ---------- */
  function Transport() {
    return (
      <Screen>
        <StatusBar />
        <AppBar back title="Ksamil → Budva" subtitle="16 de setembro · Drita Travel" />
        <Body>
          <TcCriticalCard time="19:00" title="Esteja no ponto" reason="O ônibus internacional não espera. Passaporte na mão e bilhete aberto offline."
            actions={<><TcButton variant="primary">Mostrar passagem</TcButton><TcButton variant="secondary">Ver embarque no Maps</TcButton></>} />
          <TcTransportCard status="booked" operator="Drita Travel" origin="Ksamil" destination="Budva · +1 dia"
            departure="19:30" arrival="11:07" note="Ônibus internacional · 2 paradas de fronteira · passaporte obrigatório" />
          <TcCard>
            <TcSectionHeader eyebrow="Embarque" title="Como chegar" />
            <div style={{ display: "grid", gap: "10px" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>Ponto</span><strong>Rruga e Plazhit, em frente ao mercado</strong></div>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>A pé</span><strong className="tc-tabular">12 min da hospedagem</strong></div>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: "var(--tc-text-secondary)" }}>Pagamento</span><strong>Já pago · não pagar a bordo</strong></div>
            </div>
            <div style={{ marginTop: "14px", display: "grid", gap: "10px" }}>
              <TcButton variant="secondary" full>Abrir no Maps</TcButton>
              <TcButton variant="text" full>Operadora · Drita Travel</TcButton>
            </div>
          </TcCard>
          <TcPlanBCard scenario="Se o ônibus não aparecer até 19:45"
            steps={["Confirme na bilheteria do ponto se houve mudança de horário.", "Verifique saída por Sarandë (30 min de táxi).", "Se não houver saída hoje, use a hospedagem emergencial em Ksamil."]}
            actions={<TcButton variant="secondary">Chamar táxi local</TcButton>} />
        </Body>
      </Screen>
    );
  }

  /* ---------- 13 ---------- */
  function Accommodation() {
    return (
      <Screen>
        <StatusBar />
        <AppBar back title="Apartmani Budva" subtitle="17–18 de setembro · Budva, Montenegro" />
        <Body>
          <TcAccommodationCard name="Apartmani Budva" address="Slovenska obala 12, Budva" status="confirmed"
            checkIn="17 set · 13:00" checkOut="18 set · 06:30" nights="1 noite"
            note="Reserva no nome de Vinícius. Café não incluído."
            actions={<><TcButton variant="primary">Abrir voucher</TcButton><TcButton variant="secondary">Abrir no Maps</TcButton></>} />
          <TcCriticalCard label="Não pode dar errado" time="06:30" title="Check-out antes do ônibus"
            reason="O ônibus para Žabljak sai às 07:15. Combine a devolução da chave na chegada." />
          <TcCard>
            <TcSectionHeader eyebrow="Chegada" title="Instruções" />
            <Note>Entrada pelo portão lateral. O anfitrião deixa a chave no cofre ao lado da porta; o código chega por mensagem no dia da chegada.</Note>
            <div style={{ marginTop: "14px", display: "grid", gap: "10px" }}>
              <TcButton variant="secondary" full icon={<Icon name="tc-call" size={20} />}>Ligar para o anfitrião</TcButton>
              <TcButton variant="text" full>Ver reserva no Booking</TcButton>
            </div>
          </TcCard>
          <TcPlanBCard scenario="Se não conseguirmos entrar"
            steps={["Ligue para o anfitrião pelo número da reserva.", "Se não responder em 15 min, abra a reserva no Booking e use o chat.", "Hospedagem alternativa cadastrada: Hotel Mogren, 8 min a pé."]} />
        </Body>
      </Screen>
    );
  }

  /* ---------- 14 ---------- */
  function MemoryIdle({ go, nav }) {
    return (
      <Screen>
        <StatusBar />
        <AppBar title="Memórias" subtitle="Žabljak · dia 8 de 21" />
        <Body>
          <TcVoiceRecorder state="idle" onStart={() => go && go("memoryRecording")} />
          <TcCard tone="subtle">
            <Note>Contexto atual: Žabljak · Bobotov Kuk · Vinícius. Ele é salvo junto com a gravação, sem formulário.</Note>
          </TcCard>
          <div>
            <TcSectionHeader eyebrow="Diário" title="Últimas memórias" />
            <div style={{ display: "grid", gap: "10px" }}>
              <TcDocumentRow icon="🎙️" title="Chegada em Žabljak" meta="18 set · 19:12 · 1:42" actionLabel="Ouvir" offline={false} participant="Érika" />
              <TcDocumentRow icon="🎙️" title="Ônibus pela costa" meta="16 set · 21:40 · 2:08" actionLabel="Ouvir" offline={false} participant="Vinícius" />
              <TcDocumentRow icon="🎙️" title="Butrinto, fim da tarde" meta="16 set · 12:55 · 0:58" actionLabel="Ouvir" offline={false} participant="Vinícius" />
            </div>
          </div>
        </Body>
        <BottomNav active="viagem" onNavigate={nav} />
      </Screen>
    );
  }

  /* ---------- 15 ---------- */
  function MemoryRecording() {
    return (
      <Screen>
        <StatusBar />
        <AppBar back title="Gravando memória" />
        <Body>
          <TcVoiceRecorder state="recording" elapsed="02:41" context="Žabljak · Bobotov Kuk · Vinícius" />
          <TcCard tone="subtle">
            <Note>A gravação continua com a tela apagada. Pausar, concluir e cancelar ficam separados para não serem confundidos.</Note>
          </TcCard>
          <Note>Ao concluir: “Memória salva em Žabljak · 14:51”. Sem título, sem texto obrigatório.</Note>
        </Body>
      </Screen>
    );
  }

  /* ---------- 16 ---------- */
  function Emergency() {
    return (
      <Screen>
        <StatusBar />
        <AppBar back title="Emergência" subtitle="Montenegro · localização atual" />
        <Body>
          <TcEmergencyAction country="Emergência · Montenegro" number="112" service="Emergência geral"
            description="Use apenas quando houver necessidade imediata de polícia, ambulância ou bombeiros." />
          <div style={{ display: "grid", gap: "10px" }}>
            <TcEmergencyAction variant="row" service="Polícia" number="122" description="Montenegro" />
            <TcEmergencyAction variant="row" service="Ambulância" number="124" description="Montenegro" />
            <TcEmergencyAction variant="row" service="Seguro viagem · assistência 24h" number="+55 11 4004-0000" description="Apólice 8842-77 · fale português" />
          </div>
          <div>
            <TcSectionHeader eyebrow="Onde estamos" title="Contexto" />
            <ListCard items={[
              { icon: "tc-bed", label: "Apartmani Budva", meta: "Slovenska obala 12 · +382 67 000 000" },
              { icon: "account_balance", label: "Embaixada do Brasil em Podgorica", meta: "Representação consular · +382 20 000 000" },
              { icon: "local_hospital", label: "Hospital Geral de Budva", meta: "Popa Jola Zeca · 6 min de carro" }
            ]} />
          </div>
          <TcButton variant="secondary" full style={{ minHeight: "56px" }} icon={<span className="tc-icon tc-icon-24">present_to_all</span>}>Mostrar para alguém</TcButton>
          <Note>“Mostrar para alguém” abre uma tela grande, em inglês e montenegrino, com nome, alergias, tipo sanguíneo e contato de emergência.</Note>
        </Body>
      </Screen>
    );
  }

  /* ---------- 17 ---------- */
  function PlanB() {
    return (
      <Screen>
        <StatusBar />
        <AppBar back title="Plano B" subtitle="16 de setembro · Ksamil → Budva" />
        <Body>
          <TcPlanBCard scenario="Se perdermos o ônibus para Budva"
            consequence="A próxima saída internacional direta pode ser só no dia seguinte."
            steps={["Vá até o ponto/rodoviária e confirme a próxima saída.", "Verifique conexão por Sarandë ou Shkodër.", "Se não houver opção segura hoje, use a hospedagem emergencial cadastrada."]}
            actions={<><TcButton variant="secondary">Abrir rodoviária no Maps</TcButton><TcButton variant="text">Ver passagem</TcButton></>} />
          <div>
            <TcSectionHeader eyebrow="Alternativas" title="Rotas possíveis" />
            <div style={{ display: "grid", gap: "10px" }}>
              <TcTransportCard status="buy" operator="Gjirokastra Lines" origin="Sarandë" destination="Budva" departure="22:10" arrival="13:40" note="Sai de Sarandë · 30 min de táxi desde Ksamil" actions={<TcButton variant="secondary">Ver operadora</TcButton>} />
              <TcTransportCard status="verify" operator="Local" origin="Ksamil" destination="Shkodër" departure="06:00" arrival="11:20" note="Conexão para Podgorica no mesmo dia · confirmar no balcão" actions={<TcButton variant="secondary">Como chegar</TcButton>} />
            </div>
          </div>
          <div>
            <TcSectionHeader eyebrow="Se precisar dormir aqui" title="Hospedagem emergencial" />
            <ListCard items={[{ icon: "tc-bed", label: "Guest House Ksamil", meta: "3 min a pé do ponto · pagamento na chegada" }]} />
          </div>
        </Body>
      </Screen>
    );
  }

  /* ---------- 18 ---------- */
  function More({ nav }) {
    return (
      <Screen>
        <StatusBar />
        <AppBar title="Mais" subtitle="Mochilão pelos Bálcãs 2026" />
        <Body>
          <TcButton variant="critical" full style={{ minHeight: "56px" }} icon={<Icon name="tc-warning" />}>Emergência</TcButton>
          <div>
            <TcSectionHeader eyebrow="Na estrada" title="Utilidades" />
            <ListCard items={[
              { icon: "translate", label: "Frases úteis", meta: "Albanês · montenegrino · bósnio" },
              { icon: "apps", label: "Apps úteis", meta: "Maps offline · Bolt · Booking · conversor" },
              { icon: "currency_exchange", label: "Moedas e preços", meta: "€ · lek · marco convertível" }
            ]} />
          </div>
          <div>
            <TcSectionHeader eyebrow="Grupo" title="Participantes" />
            <Row>
              <TcParticipantStatus name="Vinícius" state="synchronized" label="Você" />
              <TcParticipantStatus name="Érika" state="synchronized" />
            </Row>
          </div>
          <div>
            <TcSectionHeader eyebrow="Dados" title="Sincronização" />
            <TcCard>
              <TcOfflineStatus mode="offlineAvailable" label="Conteúdo da viagem disponível offline" />
              <div style={{ marginTop: "10px" }}><TcOfflineStatus mode="syncUnavailable" /></div>
              <div style={{ marginTop: "14px" }}><TcButton variant="secondary" full>Tentar sincronizar agora</TcButton></div>
            </TcCard>
          </div>
          <div>
            <TcSectionHeader eyebrow="Viagem" title="Informações" />
            <ListCard items={[
              { icon: "tc-map", label: "Info da viagem", meta: "21 dias · 4 países · 9 cidades" },
              { icon: "tc-settings", label: "Configurações", meta: "Quem é você · áudio · notificações" }
            ]} />
          </div>
        </Body>
        <BottomNav active="mais" onNavigate={nav} />
      </Screen>
    );
  }

  const SCREENS = [
    { id: "whoAreYou", code: "01-who-are-you", name: "Quem é você?", section: "Onboarding", Comp: WhoAreYou },
    { id: "today", code: "02-today", name: "Hoje", section: "Hoje", Comp: Today },
    { id: "fullDay", code: "03-full-day", name: "Dia completo", section: "Viagem", Comp: FullDay },
    { id: "city", code: "04-city", name: "Cidade · Sarajevo", section: "Explorar", Comp: City },
    { id: "attraction", code: "05-attraction", name: "Atração · Stari Most", section: "Explorar", Comp: Attraction },
    { id: "walkPrestart", code: "06-walk-prestart", name: "Passeio · pré-início", section: "Passeio", Comp: WalkPrestart },
    { id: "walkActive", code: "07-walk-active", name: "Passeio ativo", section: "Passeio", Comp: WalkActive },
    { id: "sharedAudio", code: "08-shared-audio-player", name: "Audioguia compartilhado", section: "Áudio", Comp: SharedAudio },
    { id: "storyTrigger", code: "09-story-trigger", name: "História pelo caminho", section: "Passeio", Comp: StoryTrigger },
    { id: "wallet", code: "10-wallet", name: "Carteira", section: "Carteira", Comp: Wallet },
    { id: "documentQr", code: "11-document-qr", name: "Documento / QR", section: "Carteira", Comp: DocumentQr },
    { id: "transport", code: "12-transport", name: "Transporte", section: "Viagem", Comp: Transport },
    { id: "accommodation", code: "13-accommodation", name: "Hospedagem", section: "Viagem", Comp: Accommodation },
    { id: "memoryIdle", code: "14-memory-idle", name: "Diário · idle", section: "Diário", Comp: MemoryIdle },
    { id: "memoryRecording", code: "15-memory-recording", name: "Diário · gravando", section: "Diário", Comp: MemoryRecording },
    { id: "emergency", code: "16-emergency", name: "Emergência", section: "Recuperação", Comp: Emergency },
    { id: "planB", code: "17-plan-b", name: "Plano B", section: "Recuperação", Comp: PlanB },
    { id: "more", code: "18-more", name: "Mais / utilidades", section: "Mais", Comp: More }
  ];

  const FLOW = ["whoAreYou", "today", "attraction", "walkPrestart", "walkActive", "sharedAudio", "storyTrigger", "memoryIdle", "memoryRecording"];

  const NAV_TARGET = { hoje: "today", viagem: "fullDay", explorar: "city", carteira: "wallet", mais: "more" };

  return { SCREENS, FLOW, NAV_TARGET, SharedAudio, Screen, StatusBar, AppBar, BottomNav, Icon };
};
