# UI kit — Travel Companion (Android)

Recriação das telas especificadas em `SCREEN-DELIVERABLES.md`, no artboard
**412 × 915**, montada com os componentes de `components/`. O kit **recria**;
não inventa telas.

Abra `index.html`. Três modos:

1. **Fluxo principal** — tela em tamanho real, clicável, na ordem do fluxo de
   demonstração: Quem é você? → Hoje → Atração → Iniciar passeio → Passeio ativo
   → Érika conectada → Ouvir juntos → História disparada por localização →
   Gravar memória por voz. A bottom navigation troca de tela raiz.
2. **18 telas** — screen index com todas as telas agrupadas por seção do app,
   com o ID de export de cada uma (`01-who-are-you`, `02-today`, …).
3. **Estados** — pranchas S1–S5 do handoff (conectividade, participante,
   timeline, áudio, reserva), mais diário por voz e as duas variantes da tela 08.

## Telas

| ID | Nome | Seção |
|---|---|---|
| 01-who-are-you | Quem é você? | Onboarding |
| 02-today | Hoje | Hoje |
| 03-full-day | Dia completo | Viagem |
| 04-city | Cidade · Sarajevo | Explorar |
| 05-attraction | Atração · Stari Most | Explorar |
| 06-walk-prestart | Passeio · pré-início | Passeio |
| 07-walk-active | Passeio ativo | Passeio |
| 08-shared-audio-player | Audioguia compartilhado | Áudio |
| 09-story-trigger | História pelo caminho | Passeio |
| 10-wallet | Carteira | Carteira |
| 11-document-qr | Documento / QR | Carteira |
| 12-transport | Transporte | Viagem |
| 13-accommodation | Hospedagem | Viagem |
| 14-memory-idle | Diário · idle | Diário |
| 15-memory-recording | Diário · gravando | Diário |
| 16-emergency | Emergência | Recuperação |
| 17-plan-b | Plano B | Recuperação |
| 18-more | Mais / utilidades | Mais |

## Anotações de interação

- **Scroll** — Cidade, Atração e Dia completo são longas, coluna única; nada de
  controle sticky além da bottom nav.
- **Bottom nav** — presente nas telas raiz (Hoje, Viagem, Explorar, Carteira,
  Mais) com label sempre visível; telas de detalhe usam back.
- **Áudio** — segue tocando com a tela apagada, em background e entre telas; o
  player compacto pode permanecer.
- **Áudio compartilhado** — sincroniza estado de reprodução, não stream. Sem
  sala, convite, código ou pareamento. Falha de sync nunca interrompe o áudio local.
- **GPS** — estado visível só quando relevante (ativa / procurando / imprecisa).
  Sem telemetria permanente nem número de precisão.
- **Modo Passeio** — desenhado para funcionar com o celular no bolso: alvos
  generosos, estados audíveis, controles essenciais no fim da tela.
- **QR Mode** — brilho ao máximo e tela ativa ao abrir; restaura ao fechar.
- **Diário por voz** — grava em um toque, contexto capturado automaticamente,
  sem título obrigatório; haptics no início e no fim.
- **Offline** — status inline junto do que é afetado; nunca banner global.
- **Deeplink** — rótulo sempre com verbo + destino.
- **Back** — preserva scroll, playback, estado de passeio e contexto do dia.

## Conteúdo em branco por falta de especificação

- Fotografia real: todo hero mostra placeholder rotulado.
- Números de emergência, contatos consulares, códigos de reserva e telefones são
  **mock visual plausível** — não são dados operacionais verificados. Substitua
  pelo JSON real da viagem antes de qualquer uso em campo.
- “Mostrar para alguém” (tela 16) e o padrão de permissão de localização estão
  descritos como anotação, conforme o handoff, sem tela em alta fidelidade.
