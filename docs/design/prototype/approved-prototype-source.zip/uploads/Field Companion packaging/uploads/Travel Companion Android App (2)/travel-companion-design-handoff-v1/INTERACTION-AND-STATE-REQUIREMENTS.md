# Interaction and State Requirements

Este documento complementa os mockups com regras de comportamento.

---

# 1. Quem é você?

- aparece apenas quando não existe `participantId` local;
- seleção persiste;
- não há autenticação visual;
- pode ser alterado posteriormente em Configurações.

---

# 2. Today / Agora

O conteúdo deve reagir conceitualmente ao horário.

Estados:

- evento futuro;
- evento começando;
- evento em andamento;
- evento concluído.

O `Agora` deve promover a ação mais útil daquele momento.

---

# 3. Critical Items

Pode existir simultaneamente com status Confirmado.

Exemplo:

`Confirmado` não significa que o item deixou de ser crítico.

Critical é uma dimensão adicional.

---

# 4. Bottom Navigation

Permanece disponível nas telas raiz:

- Hoje;
- Viagem;
- Explorar;
- Carteira;
- Mais.

Detalhes podem ocultar bottom nav se isso melhorar foco, desde que voltar seja evidente.

---

# 5. Audio

O áudio deve continuar:

- com tela apagada;
- em background;
- navegando entre telas.

Compact player pode permanecer persistente.

---

# 6. Shared audio

Estados:

## synchronized
Todos tocando a posição esperada.

## reconnecting
Aparelho tentando recuperar estado compartilhado.

## offline
Participante sem comunicação.

O playback local não deve depender da sincronização.

Mensagem preferida:

> Não foi possível sincronizar o grupo. Seu audioguia continua funcionando normalmente.

---

# 7. “Ouvir juntos”

Não requer:

- lobby;
- código;
- QR;
- pairing.

Participantes são definidos no pacote da viagem e identificados por “Quem é você?”.

---

# 8. Walk Mode

Ao iniciar:

- localização mais ativa;
- áudio pode continuar em background;
- histórias podem ser automáticas;
- usuário pode guardar o celular.

Não desenhar telemetria técnica persistente.

---

# 9. GPS

Estados visuais somente quando relevantes:

- localização ativa;
- procurando localização;
- localização imprecisa.

Não usar termos:
- geofence;
- fused provider;
- GPS accuracy number,
na UI normal.

---

# 10. Story Trigger

Quando automatic play estiver ligado:

- pequeno earcon;
- audioguia começa.

Quando desligado:

- notificação/prompt.

O design precisa funcionar para os dois comportamentos.

---

# 11. Voice memory

Ao tocar gravar:

- gravação começa com mínimo de atrito;
- contexto é capturado automaticamente;
- título não é obrigatório.

Ao salvar:

> Memória salva em [local] · [hora]

---

# 12. Wallet

Conteúdo sempre prioriza disponibilidade offline.

Documento contextual pode aparecer também em:
- Hoje;
- Transport;
- Accommodation.

Não duplicar bytes conceitualmente; apenas referenciar o mesmo documento.

---

# 13. QR Mode

Ao abrir:

- brilho aumenta;
- tela permanece ativa;
- UI mínima.

Ao fechar:
- restaura brilho/comportamento.

---

# 14. Weather

Mostrar freshness.

Estados:

## Live
> Atualizado há 12 min

## Stale
> Última previsão atualizada às 08:14

## No live data
Usar planejamento climático do JSON, explicitando que não é previsão ao vivo.

---

# 15. Outfit

É recomendação funcional, não fashion.

Pode variar com:
- temperatura;
- chuva;
- vento;
- altitude;
- atividade.

---

# 16. Deep links

Sempre indicar destino da ação.

Bom:
- Abrir no Maps
- Ver reserva no Booking

Ruim:
- Link
- Abrir
- Ver mais

---

# 17. Emergency

Ações críticas podem usar oxblood sólido.

Sem fotografia decorativa.

Ligação deve ser a principal ação quando aplicável.

---

# 18. Plan B

Plano B usa warning/gold, exceto quando o cenário realmente se torna uma emergência.

Deve reduzir estresse oferecendo passos claros.

---

# 19. Offline

Offline não é erro global.

Não usar banner vermelho permanente.

Mostrar apenas quando afeta algo.

---

# 20. Loading

Conteúdo local deve renderizar imediatamente.

Skeleton/loading somente para informação realmente online.

---

# 21. Scroll

Telas longas:
- Cidade;
- Atração;
- Dia completo.

Ações importantes podem usar sticky/compact controls com moderação.

---

# 22. Haptics / feedback

Representar em anotação quando aplicável:

- iniciar/parar gravação;
- sync start countdown;
- concluir checklist;
- confirmação crítica.

---

# 23. Motion

Anotar:

- compact audio player expansion;
- 3–2–1 shared audio;
- card expansion;
- participant reconnect.

Não desenhar motion decorativo excessivo.

---

# 24. External app return

O Travel Companion deve manter contexto ao retornar de Maps/Booking/etc.

Não precisa desenhar splash/reload.

---

# 25. Back behavior

Voltar deve preservar:
- scroll quando plausível;
- estado de playback;
- estado de passeio;
- contexto do dia.

---

# 26. Permission UX

Antes da permissão Android, explicar benefício.

Exemplo:

> Durante os passeios, o app pode avisar quando vocês chegarem perto de um lugar interessante, mesmo com a tela apagada.

Depois solicitar permissão.

Criar annotation, não precisa necessariamente ser uma das 18 telas principais.
