# Travel Companion — Design Specification v0.1

## 1. Visão do produto

O **Travel Companion** é um aplicativo Android pessoal, offline-first, criado para acompanhar uma viagem específica do início ao fim.

Ele não é um planejador de viagens genérico e não deve tentar substituir Google Maps, Booking, Uber, companhias aéreas, aplicativos de transporte ou serviços semelhantes.

Seu papel é ser o **hub central da viagem**, mostrando a informação certa no momento certo e abrindo outros aplicativos quando eles são a melhor ferramenta para a tarefa.

O app deve funcionar como:

- itinerário operacional;
- guia turístico pessoal;
- audioguia;
- carteira de documentos e vouchers;
- central de informações da viagem;
- assistente contextual do dia;
- ferramenta de emergência;
- diário por voz;
- experiência de passeio compartilhada entre os participantes.

A viagem é fornecida ao app através de **JSON + assets locais** e gera uma nova build Android. Não há necessidade de CMS ou atualização remota do conteúdo.

---

## 2. Objetivo principal de UX

Durante a viagem, o usuário deve conseguir responder em poucos segundos:

1. **O que fazemos agora?**
2. **O que vem depois?**
3. **Como chegamos lá?**
4. **O que precisamos levar ou mostrar?**
5. **Existe algo importante que não podemos esquecer?**
6. **O que é interessante saber sobre este lugar?**
7. **O que fazemos se algo der errado?**

O aplicativo deve exigir o mínimo possível de navegação manual.

### Princípio central

> O app deve antecipar a necessidade, não apenas armazenar informação.

---

## 3. Público e contexto de uso

O aplicativo é de **uso pessoal** e todos os participantes da viagem são conhecidos previamente.

Para a viagem de referência:

- Vinícius
- Érika

Não existe necessidade de:

- criação de conta;
- e-mail;
- senha;
- convite;
- QR code para entrar em grupo;
- administração de participantes;
- descoberta pública de usuários.

Na primeira abertura, o app pergunta apenas:

# Quem é você?

Exemplo:

- Vinícius
- Érika

A seleção fica persistida no aparelho.

Todos os participantes definidos no `trip.json` pertencem automaticamente ao mesmo grupo da viagem.

---

## 4. Princípios de design

### 4.1 Offline-first

Tudo que for essencial à viagem deve estar disponível sem internet:

- itinerário;
- cidades;
- atrações;
- hospedagens;
- transportes;
- vouchers;
- documentos;
- imagens;
- audioguias;
- planos B;
- contatos de emergência;
- frases úteis;
- dados gerais da viagem.

A internet deve ser usada apenas para recursos que realmente dependem dela:

- previsão do tempo;
- sincronização entre participantes;
- atualização de presença;
- abertura de serviços externos;
- navegação online.

### 4.2 Contextual

A tela principal deve mudar conforme:

- dia da viagem;
- horário;
- cidade atual;
- próximo transporte;
- próxima atração;
- check-in/check-out;
- clima;
- itens críticos.

### 4.3 Um toque para ações importantes

Ações recorrentes devem estar a no máximo um ou dois toques:

- abrir Maps;
- abrir passagem;
- mostrar voucher;
- ligar para hotel;
- tocar audioguia;
- iniciar passeio;
- abrir plano B;
- acessar emergência;
- gravar memória.

### 4.4 Não substituir aplicativos especializados

O Travel Companion sabe **qual app abrir e quando**.

Exemplos:

- Google Maps para navegação;
- Uber/Bolt para corrida;
- Booking para reserva;
- companhia aérea para check-in;
- navegador para página oficial.

### 4.5 Baixa carga cognitiva

O usuário estará:

- andando;
- cansado;
- com mochila;
- usando fones;
- possivelmente sem internet;
- sob pressão de horário.

A interface deve privilegiar:

- hierarquia clara;
- botões grandes;
- poucas decisões;
- informações críticas destacadas;
- leitura rápida;
- bom contraste.

---

# 5. Personalidade visual

A identidade deve derivar do espírito do álbum de viagem existente: descontraído, pessoal, exploratório e visual.

Ao mesmo tempo, o app precisa ter uma camada operacional mais forte para horários, documentos e riscos.

## Direção recomendada

**“Diário de exploração + instrumento de viagem.”**

Mistura de:

- editorial de viagem;
- caderno de campo;
- mapas;
- fotografia;
- interface utilitária moderna.

### Evitar

- aparência de app corporativo;
- excesso de cartões genéricos;
- visual de agência de viagens;
- visual excessivamente “premium luxury”;
- interface infantil;
- excesso de gradientes;
- excesso de ícones decorativos.

### Fotografia

Fotos devem ter presença forte em:

- cidade;
- atração;
- passeios;
- memória da viagem.

Elementos operacionais, entretanto, devem permanecer compactos.

---

# 6. Navegação principal

A navegação inferior deve ter cinco áreas.

## 6.1 Hoje

Centro operacional da viagem.

Mostra:

- local atual;
- clima;
- roupa sugerida;
- agora;
- próximo;
- restante do dia;
- itens críticos;
- checklist;
- documentos contextuais;
- plano B;
- botão de gravar memória.

## 6.2 Viagem

Timeline completa.

Estrutura:

- dias;
- cidades;
- pernoites;
- transportes;
- atrações;
- status.

Permite navegar para qualquer dia, passado ou futuro.

## 6.3 Explorar

Conteúdo turístico e narrativo.

Inclui:

- cidades;
- atrações;
- histórias pelo caminho;
- passeios;
- audioguias;
- restaurantes;
- pontos de interesse menores.

## 6.4 Carteira

Central de documentos.

Inclui:

- passagens;
- vouchers;
- reservas;
- seguro;
- documentos pessoais;
- PDFs;
- QR codes;
- comprovantes.

## 6.5 Mais

Inclui:

- emergência;
- frases úteis;
- apps úteis;
- configurações;
- participantes;
- status de sincronização;
- informações gerais da viagem.

---

# 7. Tela de onboarding — “Quem é você?”

A primeira abertura deve ser extremamente simples.

## Tela

**Bem-vindo ao Mochilão pelos Bálcãs**

Foto/ilustração da viagem.

Texto curto:

> Este app foi preparado para acompanhar nossa viagem.

Pergunta:

# Quem é você?

Cards/botões:

- Vinícius
- Érika

Após selecionar:

> Pronto, Vinícius. Boa viagem.

Não existe cadastro.

### Estado persistido

```json
{
  "participantId": "vinicius"
}
```

### Configuração vinda da viagem

```json
{
  "participants": [
    {
      "id": "vinicius",
      "name": "Vinícius"
    },
    {
      "id": "erika",
      "name": "Érika"
    }
  ]
}
```

---

# 8. Tela “Hoje”

Esta é a tela mais importante do aplicativo.

## 8.1 Cabeçalho

Exemplo:

**Quarta, 16 de setembro**

Ksamil · Albânia 🇦🇱

Dia 4 de 20

Clima resumido:

- 26 °C
- máxima 28 °C
- chuva 10%

Ação:

**Ver previsão**

---

## 8.2 Sugestão de roupa

Card compacto:

### Vista hoje

- camiseta;
- shorts;
- tênis;
- protetor solar;
- repelente.

Botão:

**Ver detalhes**

---

## 8.3 Agora

Card principal da tela.

Exemplo:

### Agora
08:30

**Butrinto**

Cidade arqueológica e Patrimônio Mundial.

Ações rápidas:

- Abrir Maps
- Ver atração
- 🎧 Audioguia

Se estiver ocorrendo transporte:

### Agora
14:00

**Ferry Corfu → Sarandë**

- mostrar bilhete;
- terminal;
- abrir Maps;
- instruções de embarque.

---

## 8.4 Próximo

Exemplo:

### Próximo
13:00

**Voltar para Ksamil**

Ônibus local

- como chegar;
- custo;
- forma de pagamento.

---

## 8.5 Timeline do restante do dia

Sequência vertical simples:

08:30 — Butrinto  
13:00 — Retorno  
15:00 — Praia  
18:00 — Jantar  
19:30 — Ônibus

Itens críticos possuem destaque visual.

---

# 9. Critical Items

Itens que não podem ser esquecidos devem aparecer separadamente.

## Exemplo

### Não pode dar errado hoje

**19:30 — Ônibus internacional**

- estar no ponto até 19:00;
- levar passaporte;
- bilhete salvo offline;
- bagagem pode exigir pagamento em dinheiro.

Ações:

- Mostrar passagem
- Abrir local de embarque
- Plano B

### Notificações locais

Exemplos:

- “Check-out termina em 45 minutos.”
- “Seu ônibus sai em 1h15.”
- “Hora de sair para o aeroporto.”
- “Leve o passaporte.”
- “O ferry exige o bilhete impresso.”

Esses alertas vêm do JSON e podem ser agendados localmente.

---

# 10. Página de cidade

Uma cidade deve ser tratada como uma entidade editorial própria.

## Cabeçalho

- foto de capa;
- nome;
- país;
- período da estadia.

Exemplo:

# Sarajevo
Bosnia and Herzegovina

25–26 setembro

---

## 10.1 Em 2 minutos

Resumo curto explicando:

- importância da cidade;
- contexto;
- principais características.

---

## 10.2 Audioguia da cidade

### Conheça Sarajevo
12 min

Controles:

- play;
- pause;
- voltar 15 s;
- avançar 15 s;
- transcrição.

---

## 10.3 História

Conteúdo dividido em capítulos.

Exemplo:

- período otomano;
- austro-húngaro;
- Primeira Guerra;
- Iugoslávia;
- Cerco de Sarajevo;
- cidade atual.

---

## 10.4 Hoje nesta cidade

Atrações agendadas.

---

## 10.5 Passeios

Exemplo:

**Sarajevo Historical Walk**

- 1,8 km;
- 45 min;
- 7 histórias;
- áudio guiado;
- modo grupo disponível.

---

## 10.6 Restaurantes recomendados

Cadastro local preparado antes da build.

Filtros simples:

- perto;
- barato;
- comida local;
- café;
- jantar.

Cada item:

- nome;
- descrição;
- faixa de preço;
- prato recomendado;
- Maps.

---

## 10.7 Pequenas histórias

Pontos interessantes que não justificam uma atração completa.

Exemplo:

- prédio;
- fonte;
- rua;
- monumento;
- praça;
- detalhe arquitetônico.

---

# 11. Página de atração

## Hero

- foto grande;
- nome;
- cidade;
- importância/prioridade.

## Resumo

Texto curto.

## Ações principais

- Abrir Maps
- Como chegar
- 🎧 Ouvir audioguia
- Ingresso
- Site oficial

## Informações práticas

- horário;
- preço;
- duração recomendada;
- acessibilidade;
- necessidade de reserva;
- melhor horário;
- itens necessários.

## História

Texto editorial.

## Curiosidades

Cards curtos.

## O que observar

Instruções espaciais:

> Olhe para o arco central.

> Observe as marcas nas pedras próximas à entrada.

## Audioguia

Pode possuir capítulos.

## Fotos

Galeria local.

## Plano B

Exemplo:

> Se estiver fechado, caminhe até...

---

# 12. Audioguia

Audioguia não deve ser tratado como simples player de MP3.

## Estrutura

- título;
- duração;
- capítulos;
- transcrição;
- controles;
- progresso;
- imagem contextual.

Exemplo:

### Stari Most
12:34

Capítulos:

00:00 — Mostar otomana  
02:40 — Construção da ponte  
05:15 — Destruição  
08:20 — Reconstrução  
10:40 — Mergulhadores

---

# 13. Modo Passeio

O Modo Passeio é uma experiência ativa de caminhada guiada.

## Exemplo

### Sarajevo Historical Walk

Baščaršija → Latin Bridge

1,8 km  
~45 min  
7 histórias

Opções:

- Histórias automáticas
- Áudio nos fones
- Sincronizar com participantes

Botão:

# Começar passeio

---

# 14. Modo Passeio — experiência sem tela

O usuário deve conseguir guardar o celular e continuar usando o passeio.

O app usa:

- localização;
- ordem esperada dos pontos;
- geofences;
- estado atual do passeio.

Exemplo de áudio:

> Estamos chegando ao Sebilj. Quando estiverem próximos à fonte, olhem para a praça à frente.

Depois:

> Esta fonte se tornou um dos símbolos de Sarajevo...

Depois:

> Continuem caminhando pela rua à direita. A próxima história começa em alguns minutos.

---

# 15. Histórias pelo caminho

Existem dois comportamentos.

## 15.1 Exploração passiva

Usa geofencing de baixo consumo.

Quando o usuário entra em uma área:

> Você está passando por um lugar interessante.

Notificação:

**Onde Oriente e Ocidente se encontram**

Ações:

- Ouvir
- Ler

---

## 15.2 Durante um passeio

Localização mais ativa.

Permite narrativas mais precisas:

> Olhem para o chão.

> Vocês estão chegando ao Sarajevo Meeting of Cultures.

---

# 16. Passeio em grupo

Todos os participantes da viagem já pertencem ao mesmo grupo.

Não existem:

- convites;
- códigos;
- QR codes;
- salas;
- pairing manual.

A única identificação é feita através de “Quem é você?” no onboarding.

---

## 16.1 Presença

Exemplo:

### Participantes

🟢 Vinícius  
🟢 Érika

ou:

🟢 Vinícius  
⚫ Érika — offline

---

## 16.2 Sincronização de áudio

Os arquivos de áudio estão armazenados localmente em todos os aparelhos.

A sincronização envia apenas:

- faixa;
- estado;
- posição;
- timestamp de início.

Exemplo conceitual:

```json
{
  "tourId": "sarajevo-historical",
  "trackId": "latin-bridge",
  "state": "playing",
  "startedAt": 1788012345678,
  "positionMs": 0
}
```

### Experiência

Usuário toca:

**Ouvir juntos**

UI:

3  
2  
1

Os aparelhos começam juntos.

---

## 16.3 Controles compartilhados

Qualquer participante pode:

- iniciar;
- pausar;
- continuar.

Ações destrutivas pedem confirmação:

- pular capítulo;
- trocar passeio;
- encerrar passeio.

Volume é sempre individual.

---

## 16.4 Estado visual

Exemplo:

### Latin Bridge

04:32 / 08:41

🎧 Vinícius — sincronizado  
🎧 Érika — sincronizada

Controles:

- voltar;
- pause;
- avançar.

---

## 16.5 Perda de conexão

Se a internet desaparecer:

> Sincronização temporariamente indisponível.

O áudio local continua.

Quando a conexão retorna:

> Érika voltou ao grupo.

A reprodução pode ser realinhada automaticamente.

---

# 17. Hospedagem

Página própria.

## Informações

- nome;
- foto;
- endereço;
- telefone;
- check-in;
- check-out;
- valor;
- pagamento;
- reserva;
- PIN;
- observações.

## Ações rápidas

- Maps
- Ligar
- WhatsApp
- Booking
- Mostrar voucher

## Como chegar

Texto preparado no JSON.

## Informação crítica

Exemplo:

> Check-in fecha às 16:00.

## Plano B

Exemplo:

> Se chegar após 16:00, ligar para...

---

# 18. Transportes

Cada transporte possui página própria.

Tipos:

- voo;
- ônibus;
- ferry;
- trem;
- transfer;
- táxi;
- transporte urbano.

## Informações

- origem;
- destino;
- horário;
- duração;
- operador;
- número;
- assento;
- plataforma/portão;
- reserva;
- custo.

## Ações

- mostrar passagem;
- abrir Maps;
- abrir app da empresa;
- instruções de embarque.

## Como chegar

Instruções detalhadas até terminal/ponto.

## Informações críticas

Exemplo:

> Estar no terminal 60 minutos antes.

---

# 19. Carteira

A Carteira deve organizar documentos de maneira contextual.

Categorias:

## Viagem

- passaportes;
- seguro;
- PID;
- documentos gerais.

## Dia

Documentos daquele dia.

## Transporte

Passagens.

## Hospedagem

Vouchers.

---

## 19.1 Visualizador rápido

Ações:

- tela cheia;
- zoom;
- compartilhar;
- abrir externamente.

### QR Code

Botão:

**Mostrar QR Code**

Comportamento:

- aumenta brilho;
- abre em tela cheia;
- impede suspensão temporariamente.

---

# 20. Emergência

Acesso em no máximo um toque a partir de “Mais” e através de atalhos contextuais.

## Tela

### Emergência — Montenegro

- número geral;
- polícia;
- ambulância;
- bombeiros.

### Seguro

- telefone;
- WhatsApp;
- apólice.

### Hospedagem atual

- telefone;
- Maps.

### Consulado / representação

- telefone;
- endereço.

---

## 20.1 “Mostrar para alguém”

Tela com frases grandes no idioma local.

Exemplo:

> Preciso de ajuda.

> Sou brasileiro.

> Meu hotel é este.

> Por favor, ligue para este número.

Pode incluir botão de reprodução de áudio.

---

# 21. Plano B

Cada dia deve possuir um plano alternativo.

Também pode existir plano B em:

- transporte;
- atração;
- hospedagem.

## Tela do dia

### Se algo der errado

**Chuva forte**

→ atividade alternativa

**Ônibus perdido**

→ próxima opção

**Atração fechada**

→ alternativa próxima

**Chegada atrasada**

→ contato / procedimento

---

# 22. Clima

É um dos poucos componentes online.

## Hoje

- temperatura atual;
- máxima;
- mínima;
- chuva;
- vento.

## Próximas horas

Resumo simples.

### Fallback

Sem internet:

> Última previsão atualizada às 08:14.

Se nenhuma previsão foi obtida:

usar clima esperado configurado no JSON.

---

# 23. Sugestão de roupas

Baseada em:

- temperatura;
- chuva;
- vento;
- atividade planejada;
- altitude;
- exposição ao sol.

Categorias:

### Vista

### Leve na mochila

### Equipamento específico

Exemplo trilha:

- segunda pele;
- corta-vento;
- tênis/trilha;
- água;
- protetor.

---

# 24. Apps úteis

Lista contextual por país/dia.

Exemplos:

- Google Maps;
- Uber;
- Bolt;
- Booking;
- easyJet;
- FlixBus;
- companhia local.

### Deeplinks

Sempre que possível, abrir diretamente:

- destino;
- reserva;
- endereço;
- rota.

---

# 25. Diário de viagem por voz

O diário é predominantemente um gravador de voz.

Não exigir escrita.

Botão recorrente:

# 🎙 Registrar memória

Disponível:

- Hoje;
- página da atração;
- após passeio;
- fim do dia.

---

## 25.1 Durante gravação

Tela minimalista:

### Gravando memória

02:41

- pausar;
- concluir;
- cancelar.

Contexto salvo automaticamente:

- participante;
- data;
- horário;
- dia da viagem;
- cidade;
- atração próxima ou atual;
- posição aproximada opcional.

---

## 25.2 Timeline de memórias

Exemplo:

### 21 setembro — Žabljak

🎙 08:32 · 01:12  
Antes da trilha

🎙 14:51 · 03:42  
Bobotov Kuk

🎙 20:13 · 02:06  
Fim do dia

---

## 25.3 Prompt no final do dia

Notificação local opcional:

> Como foi o dia?

Ação:

**🎙 Gravar memória**

---

# 26. Estados compartilhados da viagem

Conteúdo e estado devem ser separados.

## Conteúdo

Sempre local:

- JSON;
- imagens;
- áudio;
- documentos;
- itinerário.

## Estado

Pode ser sincronizado:

- participantes online;
- passeio ativo;
- áudio atual;
- posição;
- checklists concluídos;
- atrações visitadas.

O backend não deve ser necessário para abrir ou compreender a viagem.

---

# 27. Modelo conceitual de dados

```text
Trip
├── Participants[]
├── Days[]
├── Cities[]
├── Attractions[]
├── Walks[]
├── Stories[]
├── AudioGuides[]
├── Accommodations[]
├── Transports[]
├── Documents[]
├── EmergencyInfo[]
├── UsefulApps[]
├── PlansB[]
├── ClothingRules[]
└── Memories[]
```

---

# 28. Estrutura de assets

```text
trip/
├── trip.json
├── images/
│   ├── cities/
│   ├── attractions/
│   └── accommodations/
├── audio/
│   ├── cities/
│   ├── attractions/
│   └── walks/
├── documents/
│   ├── tickets/
│   ├── hotels/
│   ├── insurance/
│   └── personal/
└── icons/
```

---

# 29. Componentes principais de UI

Criar um design system pequeno e específico.

## Componentes

- DayHeader
- WeatherSummary
- OutfitCard
- TimelineItem
- CriticalItem
- AttractionHero
- CityHero
- TransportCard
- AccommodationCard
- DocumentCard
- AudioPlayer
- GroupAudioStatus
- ParticipantChip
- MapAction
- DeepLinkButton
- EmergencyAction
- PlanBCard
- VoiceRecorder
- StoryNotification
- WalkProgress
- OfflineStatus

---

# 30. Cores semânticas

Além da identidade visual, usar cores semânticas consistentes.

- neutro: informação comum;
- sucesso: confirmado/resolvido;
- atenção: verificar;
- crítico: não pode atrasar;
- passeio: conteúdo de exploração;
- áudio: reprodução/audioguia.

Não depender apenas de cor. Sempre combinar com:

- ícone;
- título;
- texto.

---

# 31. Tipografia

Prioridades:

- leitura ao ar livre;
- boa legibilidade;
- diferenciação clara entre horário, ação e descrição.

Sugestão conceitual:

- fonte expressiva/editorial para grandes títulos de cidade;
- sans-serif altamente legível para interface e operação.

Não usar fonte decorativa em informações críticas.

---

# 32. Movimento e microinterações

Usar animações discretas.

Exemplos:

- progressão da timeline;
- expansão de cards;
- transição para audioguia;
- contador 3–2–1 do áudio sincronizado;
- onda simples durante gravação de voz;
- mudança visual quando participante conecta.

Evitar animações longas.

---

# 33. Tela bloqueada e fones

O áudio deve continuar com tela apagada.

Controles de mídia devem aparecer:

- lock screen;
- notificação Android;
- comandos dos fones quando suportados.

Priorizar:

- play/pause;
- voltar;
- próximo.

---

# 34. Notificações

Categorias diferentes.

## Operacionais

- horário crítico;
- check-in;
- transporte;
- saída.

## Histórias

- ponto interessante próximo.

## Passeio

- início;
- grupo;
- reconexão.

## Diário

- convite para registrar memória.

O usuário deve poder silenciar categorias separadamente.

---

# 35. Estados de conectividade

O usuário nunca deve se perguntar se o app ainda funciona.

Estados possíveis:

### Offline

> Sem internet. Todo o conteúdo da viagem continua disponível.

### Última previsão armazenada

> Clima atualizado há 2h.

### Sincronização indisponível

> Áudio em grupo indisponível. Reprodução local continua normalmente.

---

# 36. Acessibilidade e contexto físico

O design deve considerar:

- uso sob sol forte;
- uso andando;
- uma mão;
- tela pequena;
- fadiga;
- áudio com fones de condução óssea;
- possíveis mãos molhadas;
- necessidade de decisão rápida.

Recomendações:

- alvos de toque grandes;
- contraste alto;
- pouco texto em telas operacionais;
- suporte a tamanho de fonte;
- conteúdo longo separado das ações.

---

# 37. Primeiras telas a desenhar

A primeira rodada de design deve focar em **8 telas**, pois elas definem quase todo o sistema visual.

## Tela 1 — Quem é você?

Define onboarding e personalidade.

## Tela 2 — Hoje

Principal referência visual do produto.

## Tela 3 — Dia completo

Timeline detalhada.

## Tela 4 — Cidade

Define camada editorial.

## Tela 5 — Atração

Define conteúdo + utilidade + áudio.

## Tela 6 — Modo Passeio

Define experiência especial.

## Tela 7 — Passeio em grupo / player

Define sincronização e áudio.

## Tela 8 — Carteira / documento

Define camada operacional.

Depois:

- hospedagem;
- transporte;
- emergência;
- diário por voz;
- clima;
- plano B.

---

# 38. Fluxo prioritário para protótipo

O primeiro protótipo visual deve contar uma pequena história de uso.

```text
Quem é você?
       ↓
Hoje
       ↓
Atração
       ↓
Iniciar Passeio
       ↓
Érika conectada
       ↓
Ouvir juntos
       ↓
História disparada pela localização
       ↓
Fim do passeio
       ↓
🎙 Registrar memória
```

Esse fluxo mostra simultaneamente:

- identidade;
- contexto;
- conteúdo;
- GPS;
- áudio;
- sincronização;
- diário.

---

# 39. Conteúdo de referência para as primeiras telas

Recomenda-se usar exemplos reais da viagem dos Bálcãs, não lorem ipsum.

Boas opções:

## Sarajevo

Excelente para demonstrar:

- cidade;
- história;
- caminhada;
- audioguia;
- histórias pelo caminho.

## Mostar / Stari Most

Excelente para:

- atração;
- narrativa;
- áudio;
- observação espacial.

## Ksamil / Butrinto

Excelente para:

- timeline;
- transporte;
- horário;
- atração;
- clima.

## Žabljak / Bobotov Kuk

Excelente para:

- clima;
- roupa;
- checklist;
- atividade;
- memória por voz.

---

# 40. Critérios de sucesso do design

O design será considerado bem-sucedido se:

1. O usuário entende o que fazer agora em menos de 5 segundos.
2. Informações críticas são visualmente impossíveis de confundir com conteúdo editorial.
3. Abrir Maps, passagem ou voucher exige no máximo 1–2 ações.
4. O usuário consegue iniciar um passeio sem entender conceitos técnicos de sincronização.
5. O áudio em grupo parece uma funcionalidade natural e não um sistema de “salas”.
6. A navegação funciona mesmo sem internet.
7. Cidade e atração parecem um guia de viagem agradável, não um banco de dados.
8. O diário por voz é fácil o suficiente para ser usado cansado no fim do dia.
9. O aplicativo mantém personalidade pessoal e descontraída.
10. O sistema visual é reutilizável para viagens futuras.

---

# 41. Não objetivos da primeira versão

Não priorizar agora:

- edição de itinerário no app;
- CMS;
- login tradicional;
- planejamento colaborativo;
- reservas dentro do app;
- chat;
- social feed;
- publicação pública;
- upload automático de fotos;
- geração de conteúdo dentro do app;
- streaming de áudio;
- comunicação peer-to-peer sem internet;
- navegação turn-by-turn própria.

---

# 42. Próxima etapa de design

A próxima etapa deve ser **exploração visual**, não implementação.

Objetivo:

Criar três direções visuais claramente diferentes para as telas:

1. **Hoje**
2. **Cidade**
3. **Modo Passeio**

Todas devem seguir a mesma arquitetura, mas explorar diferentes interpretações do conceito:

### Direção A — Field Guide

Mais próxima de diário de exploração, mapas, anotações e caderno de campo.

### Direção B — Modern Travel Companion

Mais limpa e digital, com forte fotografia, tipografia moderna e foco em contexto.

### Direção C — Editorial Journey

Mais próxima de revista/álbum de viagem, com fotografia dominante e forte narrativa.

Depois de escolher uma direção, ela deve ser aplicada às oito telas prioritárias antes de iniciar implementação.

---

# 43. Referências existentes

O design deve preservar dois aspectos dos materiais existentes da viagem:

## Itinerário

A forte camada operacional:

- timeline;
- horários;
- status;
- informação crítica;
- clima;
- roupa;
- plano B;
- documentos;
- logística.

## Álbum

A camada:

- pessoal;
- narrativa;
- visual;
- descontraída;
- sensação de jornada.

O aplicativo deve unir essas duas linguagens sem misturá-las de forma confusa.

---

# 44. Resumo da visão

O Travel Companion deve parecer:

> **um guia turístico particular, um caderno de viagem e uma central operacional no mesmo app.**

Durante o deslocamento, ele deve ser rápido e objetivo.

Durante uma atração ou passeio, deve desaparecer no bolso e conversar através dos fones.

Quando houver interesse em aprender mais, deve oferecer uma experiência editorial rica.

Quando algo der errado, deve mostrar imediatamente o que fazer.

E quando o dia acabar, deve permitir registrar a memória simplesmente tocando em:

# 🎙 Gravar
