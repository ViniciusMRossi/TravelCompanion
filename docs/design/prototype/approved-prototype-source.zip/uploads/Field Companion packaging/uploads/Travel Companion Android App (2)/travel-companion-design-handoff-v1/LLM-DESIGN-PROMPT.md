# Prompt principal — Criar o design do Travel Companion

Você é responsável por criar o **design de alta fidelidade completo de um aplicativo Android chamado Travel Companion**, usando exclusivamente como base as decisões e arquivos fornecidos neste pacote.

## Objetivo

Transformar o Design System e a especificação funcional já aprovados em um conjunto consistente de telas Android de alta fidelidade, fluxos e estados suficientes para orientar a implementação do app.

O produto é um **travel companion pessoal, offline-first**.

Ele não é um app genérico de planejamento de viagens.

A experiência deve parecer:

> Um guia turístico particular, um caderno de campo e uma central operacional no mesmo aplicativo.

---

# 1. Regra principal

## NÃO REDESENHE O DESIGN SYSTEM

O arquivo:

`travel-companion-design-system-v0.1.md`

e a referência visual:

`travel-companion-component-gallery-v0.1.html`

estão **aprovados**.

Você deve aplicar essa linguagem.

Não:

- trocar a paleta;
- substituir Fraunces + Roboto sem motivo técnico incontornável;
- mudar a direção Field Companion;
- transformar o app em Material 3 genérico;
- propor três novos estilos;
- recomeçar o processo de branding;
- introduzir glassmorphism;
- criar aparência de agência de turismo;
- criar um dashboard corporativo.

Pode fazer pequenos ajustes de composição necessários para criar as telas, desde que preserve claramente a identidade aprovada.

---

# 2. Plataforma e viewport

Plataforma principal:

**Android phone**

Use como artboard de referência:

**412 × 915 px**

Representando aproximadamente um aparelho Android moderno.

Requisitos:

- respeitar status bar;
- respeitar navigation/gesture area;
- alvos de toque mínimos de 48dp;
- layouts devem continuar plausíveis em telas menores;
- privilegiar uma coluna;
- não criar grids estilo desktop.

---

# 3. Conteúdo

Não use Lorem Ipsum.

Use conteúdo realista da viagem pelos Bálcãs.

Priorize exemplos:

### Sarajevo
Para:
- cidade;
- história;
- Modo Passeio;
- histórias pelo caminho;
- áudio sincronizado.

### Mostar / Stari Most
Para:
- atração;
- história;
- audioguia;
- observações espaciais.

### Ksamil / Butrinto
Para:
- Hoje;
- timeline;
- transportes;
- informação crítica.

### Žabljak / Bobotov Kuk
Para:
- clima;
- roupas;
- atividade;
- diário por voz.

Referências:

https://draerikabatista.com.br/viagem/itinerario.html

https://draerikabatista.com.br/viagem/Album/album.html

Quando algum dado específico não estiver disponível, use conteúdo plausível claramente como mock visual e não invente detalhes operacionais críticos apresentados como fatos.

---

# 4. Primeiro fluxo obrigatório

O primeiro conjunto de telas deve permitir visualizar este fluxo completo:

```text
Quem é você?
       ↓
Hoje
       ↓
Atração
       ↓
Iniciar Passeio
       ↓
Passeio ativo
       ↓
Érika conectada
       ↓
Ouvir juntos
       ↓
História disparada por localização
       ↓
Fim do passeio
       ↓
Gravar memória por voz
```

Esse fluxo é o principal cenário de demonstração do produto.

---

# 5. Telas obrigatórias

Crie todas as telas descritas em:

`SCREEN-DELIVERABLES.md`

A prioridade máxima é:

1. Quem é você?
2. Hoje
3. Dia completo
4. Cidade
5. Atração
6. Modo Passeio — pré-início
7. Modo Passeio — ativo
8. Audioguia compartilhado
9. História pelo caminho
10. Carteira
11. Documento / QR
12. Transporte
13. Hospedagem
14. Diário por voz — idle
15. Diário por voz — gravando
16. Emergência
17. Plano B
18. Mais / utilidades

---

# 6. Estados obrigatórios

Não entregue somente happy path.

Mostre também estados relevantes:

### Sincronização
- Vinícius sincronizado;
- Érika sincronizada;
- participante reconectando;
- participante offline.

### Conectividade
- online;
- offline com conteúdo disponível;
- previsão desatualizada;
- sincronização indisponível.

### Timeline
- passado/concluído;
- atual;
- futuro;
- crítico.

### Reserva
- confirmado;
- verificar;
- comprar;
- crítico.

### Áudio
- parado;
- carregando;
- tocando;
- pausado;
- sincronizando grupo.

### Diário
- vazio;
- gravando;
- pausado;
- salvo.

Consulte:
`INTERACTION-AND-STATE-REQUIREMENTS.md`

---

# 7. Navegação

Bottom navigation fixa:

1. Hoje
2. Viagem
3. Explorar
4. Carteira
5. Mais

Os labels devem permanecer visíveis.

Detalhes usam back navigation apropriada.

O design deve deixar clara a diferença entre:

- navegação global;
- ações contextuais;
- deeplinks para apps externos.

---

# 8. Conteúdo editorial vs operacional

Essa distinção é central.

## Editorial

Pode usar:

- Fraunces;
- fotografia forte;
- espaços maiores;
- histórias;
- detalhes;
- atmosfera de caderno de campo.

## Operacional

Deve usar:

- Roboto;
- horários escaneáveis;
- alta legibilidade;
- ações diretas;
- status claros;
- alertas inequívocos.

Não misture uma informação operacional crítica dentro de um bloco editorial longo.

---

# 9. “Hoje” é a tela mais importante

Ela deve responder quase instantaneamente:

- Onde estamos?
- O que fazemos agora?
- O que vem depois?
- Existe algo que não pode dar errado?
- Como está o clima?
- O que vestir/levar?
- Onde está o ticket/documento relevante?
- Existe Plano B?

O componente `Agora` deve dominar visualmente a tela.

Critical Items devem ser impossíveis de perder.

---

# 10. Modo Passeio

O Modo Passeio deve ser tratado como feature principal, não detalhe.

O usuário estará usando fones de ouvido e frequentemente manterá o celular no bolso.

A tela precisa comunicar:

- passeio;
- progresso;
- história atual;
- próxima história;
- distância aproximada;
- estado de áudio;
- participantes;
- GPS apenas quando relevante;
- controles essenciais.

Evite excesso de elementos.

---

# 11. Áudio em grupo

Os participantes já fazem parte do mesmo grupo da viagem.

Não desenhar:

- sala;
- invite;
- QR para pairing;
- código;
- lobby.

Na primeira instalação o usuário apenas responde:

> Quem é você?

Depois disso, o grupo existe automaticamente.

Terminologia permitida:

- Ouvir juntos
- Sincronizado
- Conectando
- Sincronizando novamente
- Offline

Não expor:

- room;
- stream;
- peer;
- Firebase;
- timestamp;
- latency.

---

# 12. Diário por voz

O diário deve parecer extremamente fácil de usar cansado, no fim do dia.

Não exigir:

- título;
- descrição;
- categoria;
- texto.

Fluxo principal:

```text
Gravar memória
↓
gravação
↓
Concluir
↓
salvo automaticamente com contexto
```

Contexto visual possível:

- participante;
- cidade;
- atração;
- horário.

---

# 13. Carteira

A Carteira é operacional.

Objetivo:

abrir ticket/voucher/documento o mais rápido possível.

QR mode:

- QR grande;
- brilho máximo;
- tela ativa;
- pouca interface;
- informação necessária para identificação.

Evite ornamentação.

---

# 14. Emergência

A tela de emergência pode romper propositalmente a suavidade visual do restante do app.

Precisa privilegiar:

- número;
- serviço;
- botão de ligação;
- seguro;
- hospedagem;
- consulado/representação;
- “mostrar para alguém”.

Nada deve competir com a ação.

---

# 15. Plano B

Plano B não deve parecer emergência.

Use a linguagem visual de warning/gold.

Formato recomendado:

- cenário;
- consequência;
- próximos passos numerados;
- links/ações.

---

# 16. Deeplinks

Não desenhe o Travel Companion tentando substituir ferramentas especializadas.

Ações podem abrir:

- Google Maps;
- Booking;
- Bolt;
- Uber;
- FlixBus;
- companhia aérea;
- site oficial.

Labels devem ser verbos:

- Abrir no Maps
- Ver reserva no Booking
- Chamar Bolt
- Abrir passagem

---

# 17. Entregáveis

Entregue:

## A. Screens

Todas as telas obrigatórias em alta fidelidade.

## B. Screen index

Uma página/quadro com miniaturas e nomes de todas as telas.

## C. Primary flow

Uma visualização conectando as telas do fluxo principal.

## D. Component usage

Uma prancha mostrando os principais componentes aplicados em telas reais.

## E. Interaction annotations

Anotações curtas para comportamentos que não ficam óbvios em imagem:

- scroll;
- sticky/floating;
- transição;
- áudio;
- GPS;
- deeplink;
- offline;
- sincronização.

## F. State variants

Variantes essenciais descritas neste prompt.

---

# 18. Formato de entrega

Se a ferramenta suportar projeto visual editável:

- organize as telas por seção;
- use nomes consistentes;
- crie componentes reutilizáveis;
- use tokens;
- mantenha uma página/seção chamada `00 Foundations`;
- mantenha uma página/seção chamada `01 Components`;
- mantenha uma página/seção chamada `02 Core Screens`;
- mantenha uma página/seção chamada `03 Secondary Screens`;
- mantenha uma página/seção chamada `04 Flows & States`.

Se produzir imagens:

- exportar PNG individual;
- 1x é suficiente para revisão;
- nomear conforme `SCREEN-DELIVERABLES.md`.

Se produzir protótipo HTML:

- manter viewport Android;
- permitir navegar pelo primary flow;
- preservar design tokens fornecidos.

---

# 19. Critério para não avançar silenciosamente

Se houver conflito entre:

- este prompt;
- Design System;
- Design Spec;
- Component Gallery;

prioridade:

1. decisões explícitas deste prompt;
2. Design System aprovado;
3. Component Gallery aprovada;
4. Design Spec.

Não substitua uma decisão aprovada por preferência própria.

---

# 20. Critérios de sucesso

Antes de considerar o design finalizado, verifique:

- A próxima ação de “Hoje” é identificável em menos de 5 segundos?
- O usuário distingue conteúdo editorial de informação operacional?
- Critical Items realmente chamam atenção?
- O Modo Passeio funciona visualmente mesmo se quase não olharmos para a tela?
- O estado do grupo é compreensível sem termos técnicos?
- Abrir tickets/documentos é rápido?
- O diário por voz parece mais fácil do que escrever?
- O offline parece um modo normal e não uma falha?
- O design parece pessoal e de viagem sem virar scrapbook?
- O conjunto parece pertencer ao Design System aprovado?

Use também:

`DESIGN-QA-CHECKLIST.md`

---

# 21. Importante

Não implemente backend.

Não desenhe CMS.

Não crie login.

Não crie social features.

Não crie edição de itinerário.

Não crie chat.

Não crie feed.

Não transforme isso em um app comercial genérico.

Seu objetivo é criar uma **experiência Android pessoal e extremamente conveniente para viver a viagem**, usando o sistema visual já aprovado.
