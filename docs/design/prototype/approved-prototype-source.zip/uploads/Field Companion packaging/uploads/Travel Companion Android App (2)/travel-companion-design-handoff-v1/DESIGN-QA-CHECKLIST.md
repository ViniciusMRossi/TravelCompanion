# Design QA Checklist

Use este checklist antes de entregar.

## Produto

- [ ] Parece um travel companion pessoal, não um planner genérico?
- [ ] A linguagem Field Companion está preservada?
- [ ] Existe equilíbrio entre guia editorial e utilidade operacional?

## Design System

- [ ] Paleta aprovada preservada?
- [ ] Fraunces usada apenas editorialmente?
- [ ] Roboto usada para operação?
- [ ] Grid 4dp respeitado?
- [ ] Gutter de ~20dp?
- [ ] Touch targets >= 48dp?
- [ ] Raios consistentes?
- [ ] Sem excesso de sombras?
- [ ] Sem excesso de cards aninhados?

## Hoje

- [ ] “Agora” domina a hierarquia?
- [ ] Próximo item é fácil de identificar?
- [ ] Critical Item é impossível de ignorar?
- [ ] Clima e roupa são compactos?
- [ ] Documento importante é acessível rapidamente?

## Timeline

- [ ] Horários escaneáveis?
- [ ] Atual, passado e futuro distinguíveis?
- [ ] Critical não depende apenas da cor?
- [ ] Timeline não virou uma pilha de cards?

## Cidade / Atração

- [ ] Fotografia tem presença?
- [ ] Conteúdo editorial respira?
- [ ] Maps/audioguia são fáceis de achar?
- [ ] Informações práticas não estão escondidas em parágrafos?

## Modo Passeio

- [ ] Progresso visível?
- [ ] Próxima instrução clara?
- [ ] Pode funcionar com o celular no bolso?
- [ ] Status do grupo é simples?
- [ ] Sem linguagem técnica de rede/GPS?

## Áudio

- [ ] Player compacto funciona?
- [ ] Player expandido é legível?
- [ ] Participantes sincronizados têm estado claro?
- [ ] Reconnecting/offline não bloqueia o áudio local?

## Carteira

- [ ] Ticket abre em 1–2 ações?
- [ ] QR mode é minimalista?
- [ ] Offline está claro?
- [ ] Documento é priorizado por contexto?

## Diário

- [ ] Gravar exige uma ação?
- [ ] Não há formulário obrigatório?
- [ ] Pausar/concluir/cancelar são difíceis de confundir?
- [ ] Contexto salvo é visível sem exigir edição?

## Emergência

- [ ] Número e ação dominam a tela?
- [ ] Não há decoração desnecessária?
- [ ] Seguro/hospedagem/representação são fáceis de achar?

## Plano B

- [ ] Parece contingência, não pânico?
- [ ] Possui passos concretos?
- [ ] Usa gold/warning adequadamente?

## Offline

- [ ] O app continua parecendo funcional?
- [ ] Não existe banner vermelho global?
- [ ] Weather stale está explicitamente rotulado?
- [ ] Sync failure explica que áudio local continua?

## Acessibilidade

- [ ] Contraste adequado?
- [ ] Não depende apenas de cor?
- [ ] Texto ampliado é plausível?
- [ ] Ícones têm label quando necessário?
- [ ] Elementos críticos têm ícone + texto?

## Conteúdo

- [ ] Sem Lorem Ipsum?
- [ ] Conteúdo baseado na viagem real?
- [ ] Dados inventados não parecem fatos operacionais?
- [ ] Linguagem curta e natural em pt-BR?

## Handoff

- [ ] Todas as 18 telas existem?
- [ ] Screen index existe?
- [ ] Primary flow existe?
- [ ] State boards existem?
- [ ] Interações não óbvias estão anotadas?
- [ ] Nomes de frames/arquivos seguem a convenção?
