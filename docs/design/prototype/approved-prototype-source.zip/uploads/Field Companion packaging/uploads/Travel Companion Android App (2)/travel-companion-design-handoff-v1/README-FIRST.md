# Travel Companion — Design Handoff Package v1

## Leia isto primeiro

Este pacote contém a especificação aprovada para criar o **design visual completo do aplicativo Android Travel Companion**.

O produto é um companion pessoal de viagem, offline-first, que combina:

- itinerário operacional;
- guia de cidades e atrações;
- audioguias;
- passeios guiados por GPS;
- sincronização de áudio entre os participantes;
- carteira de tickets/vouchers/documentos;
- clima e sugestão de roupas;
- emergência e Plano B;
- diário de viagem por gravação de voz.

O design system e a Component Gallery deste pacote **já foram aprovados**.

A tarefa não é propor uma nova identidade visual. A tarefa é **aplicar o sistema aprovado e produzir as telas e fluxos finais do app**.

---

## Ordem de leitura obrigatória

1. `LLM-DESIGN-PROMPT.md`
2. `travel-companion-design-system-v0.1.md`
3. `travel-companion-component-gallery-v0.1.html`
4. `travel-companion-design-spec-v0.1.md`
5. `SCREEN-DELIVERABLES.md`
6. `INTERACTION-AND-STATE-REQUIREMENTS.md`
7. `DESIGN-QA-CHECKLIST.md`
8. `travel-companion-design-tokens-v0.1.json`

---

## Referências existentes da viagem

Use o conteúdo real da viagem como referência sempre que possível:

- Itinerário:
  https://draerikabatista.com.br/viagem/itinerario.html

- Álbum:
  https://draerikabatista.com.br/viagem/Album/album.html

O **itinerário** representa principalmente a camada operacional.

O **álbum** representa principalmente a camada narrativa, visual e pessoal.

O app deve unir as duas.

---

## Decisões já aprovadas

- Plataforma inicial: Android.
- Uso pessoal.
- Usuários/participantes conhecidos previamente.
- Primeira abertura pergunta **“Quem é você?”**.
- Participantes pertencem automaticamente ao grupo da viagem.
- Conteúdo da viagem vem de JSON + assets locais.
- Não existe CMS.
- Não existe login tradicional.
- Conteúdo essencial é offline-first.
- Firebase ou solução equivalente pode sincronizar apenas estado leve.
- Áudios ficam locais em cada aparelho.
- Modo Passeio usa fones e pode operar com a tela apagada.
- Diário/memórias é baseado em **gravação de voz**.
- Design System: **Field Companion**.
- Direção visual não deve ser redefinida.
- Component Gallery v0.1 está aprovada.

---

## Resultado esperado

O resultado deve ser suficientemente completo para:

1. validar visualmente o produto;
2. entender todos os principais fluxos;
3. implementar o app sem precisar reinventar decisões de UI;
4. testar o design com conteúdo real da viagem;
5. futuramente reutilizar o mesmo sistema para outras viagens.

Consulte `LLM-DESIGN-PROMPT.md` para a instrução principal.
