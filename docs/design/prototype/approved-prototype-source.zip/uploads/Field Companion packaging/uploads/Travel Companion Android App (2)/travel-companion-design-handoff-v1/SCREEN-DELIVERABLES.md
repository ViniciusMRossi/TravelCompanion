# Screen Deliverables

## Convenção de export

Use os IDs abaixo como prefixo de arquivo/frame.

Exemplo:

`01-who-are-you.png`

---

# Core screens

## 01 — Who Are You?

**ID:** `01-who-are-you`

Objetivo:
Identificar o participante na primeira abertura.

Conteúdo:
- título da viagem;
- breve mensagem;
- pergunta “Quem é você?”;
- Vinícius;
- Érika;
- imagem/elemento editorial leve.

Não incluir:
- e-mail;
- login;
- senha;
- criar conta.

---

## 02 — Today

**ID:** `02-today`

Objetivo:
Centro operacional da viagem.

Obrigatório:
- data;
- cidade/país;
- dia X de Y;
- clima;
- roupa;
- Agora;
- Próximo;
- timeline;
- Critical Item;
- shortcut para documento contextual;
- shortcut para Plano B;
- gravar memória.

Exemplo:
Ksamil / Butrinto.

---

## 03 — Full Day

**ID:** `03-full-day`

Objetivo:
Mostrar o dia inteiro com mais detalhes.

Obrigatório:
- timeline completa;
- transportes;
- atrações;
- refeições/tempo livre;
- hospedagem;
- critical;
- documentos;
- plano B.

---

## 04 — City

**ID:** `04-city`

Exemplo:
Sarajevo.

Obrigatório:
- hero;
- introdução;
- audioguia da cidade;
- história em capítulos;
- atrações;
- passeios;
- restaurantes;
- pequenas histórias;
- período da estadia.

---

## 05 — Attraction

**ID:** `05-attraction`

Exemplo:
Stari Most ou Butrinto.

Obrigatório:
- fotografia;
- nome/local;
- resumo;
- Maps;
- como chegar;
- audioguia;
- informações práticas;
- história;
- curiosidades;
- “o que observar”;
- Plano B.

---

## 06 — Walk Pre-start

**ID:** `06-walk-prestart`

Exemplo:
Sarajevo Historical Walk.

Obrigatório:
- nome;
- rota;
- distância;
- tempo;
- número de histórias;
- áudio;
- histórias automáticas;
- participantes;
- botão Começar passeio.

---

## 07 — Walk Active

**ID:** `07-walk-active`

Obrigatório:
- progresso;
- história atual;
- próxima instrução;
- próxima história;
- distância;
- áudio;
- participantes;
- pause/end;
- GPS apenas quando necessário.

---

## 08 — Shared Audio Player

**ID:** `08-shared-audio-player`

Obrigatório:
- faixa;
- capítulo;
- progresso;
- play/pause;
- ±15 s;
- participantes;
- sincronização.

Mostrar variante:
- ambos sincronizados;
- Érika reconectando.

---

## 09 — Story Trigger

**ID:** `09-story-trigger`

Objetivo:
História detectada por localização.

Obrigatório:
- título;
- hook;
- distância/contexto;
- Ouvir;
- Ler;
- indicação de “História pelo caminho”.

---

## 10 — Wallet

**ID:** `10-wallet`

Obrigatório:
- viagem;
- dia;
- transporte;
- hospedagem;
- seguro;
- documentos pessoais;
- pesquisa/filtro somente se realmente necessário.

---

## 11 — Document / QR

**ID:** `11-document-qr`

Obrigatório:
- documento/ticket;
- modo visualização;
- QR Mode;
- estado brilho máximo;
- offline.

---

## 12 — Transport

**ID:** `12-transport`

Exemplo:
Ksamil → Budva.

Obrigatório:
- horários;
- origem/destino;
- operador;
- status;
- ticket;
- embarque;
- Maps;
- como chegar;
- criticidade;
- Plano B.

---

## 13 — Accommodation

**ID:** `13-accommodation`

Obrigatório:
- nome;
- endereço;
- check-in;
- check-out;
- reserva;
- voucher;
- Maps;
- contato;
- instruções;
- Critical Item quando aplicável;
- Plano B.

---

## 14 — Voice Memory Idle

**ID:** `14-memory-idle`

Obrigatório:
- botão dominante “Gravar memória”;
- contexto atual opcional;
- últimas memórias curtas.

---

## 15 — Voice Memory Recording

**ID:** `15-memory-recording`

Obrigatório:
- tempo;
- waveform;
- pausar;
- concluir;
- cancelar;
- cidade/atração;
- participante.

---

## 16 — Emergency

**ID:** `16-emergency`

Obrigatório:
- país atual;
- número geral;
- polícia;
- ambulância;
- seguro;
- hospedagem;
- representação brasileira;
- Mostrar para alguém.

---

## 17 — Plan B

**ID:** `17-plan-b`

Obrigatório:
- cenário;
- próximos passos;
- opções alternativas;
- Maps/app/documentos quando aplicável.

Mostrar um exemplo concreto.

---

## 18 — More / Utilities

**ID:** `18-more`

Obrigatório:
- emergência;
- frases úteis;
- apps úteis;
- participantes;
- sync;
- configurações;
- info da viagem.

---

# State boards

Além das telas acima, criar pranchas de variantes para:

## S1 — Connectivity

- online;
- offline;
- weather stale;
- sync unavailable.

## S2 — Participant

- synchronized;
- reconnecting;
- offline.

## S3 — Timeline

- completed;
- active;
- upcoming;
- critical.

## S4 — Audio

- idle;
- playing;
- paused;
- reconnecting.

## S5 — Booking

- confirmed;
- verify;
- buy;
- critical.

---

# Screen index

Criar uma prancha inicial contendo miniaturas das 18 telas, com:

- ID;
- nome;
- seção do app;
- status.

Isso facilitará revisão e implementação.
