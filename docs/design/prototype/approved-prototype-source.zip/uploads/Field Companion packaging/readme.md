# Field Companion — Travel Companion Design System

Design system **Field Companion**, empacotado a partir do handoff
`travel-companion-design-handoff-v1`. O sistema visual estava aprovado: este
pacote **reembala** as decisões existentes, não propõe novas.

Produto: **Travel Companion**, um companheiro pessoal de viagem para **Android**,
offline-first, feito para uma viagem real (Mochilão pelos Bálcãs). Junta duas
camadas que normalmente vivem em apps diferentes:

- **operacional** — horário, transporte, check-in/out, tickets, clima, avisos,
  emergência, Plano B;
- **editorial** — cidades, atrações, histórias, audioguias, passeios guiados por
  GPS, memórias gravadas por voz.

Princípios de produto que os componentes respeitam: Android-first; companheiro
pessoal, não planejador comercial; offline-first; conteúdo vem de JSON + assets
locais; sem login, convite, sala, código de pareamento ou recurso social; áudio
local (o áudio compartilhado sincroniza **estado de reprodução**, não stream);
Walk Mode funciona com o celular no bolso e fones no ouvido; conteúdo
operacional extremamente claro, editorial pode ser expressivo; **timing crítico
nunca fica escondido dentro de conteúdo editorial**.

## Fontes deste pacote

Arquivos recebidos (em `uploads/Travel Companion Android App (2)/travel-companion-design-handoff-v1/`):

| Arquivo | Papel neste pacote |
|---|---|
| `travel-companion-component-gallery-v0.1.html` | **Verdade visual.** Todos os valores numéricos dos componentes (padding, raio, tamanho, line-height) vêm do CSS dela. |
| `travel-companion-design-tokens-v0.1.json` | Origem dos arquivos em `tokens/`, incluindo `color.dark` como escopo de tema. |
| `travel-companion-design-system-v0.1.md` | Regras de uso, taxonomia de status, linguagem, acessibilidade. |
| `travel-companion-design-spec-v0.1.md` | Especificação de produto (precedência mais baixa). |
| `SCREEN-DELIVERABLES.md` | Lista das 18 telas e das pranchas de estado do UI kit. |
| `INTERACTION-AND-STATE-REQUIREMENTS.md` | Estados e comportamentos anotados no kit. |
| `LLM-DESIGN-PROMPT.md`, `README-FIRST.md`, `DESIGN-QA-CHECKLIST.md` | Escopo, prioridades e QA. |

Referências de conteúdo citadas no handoff (não acessadas na montagem deste
pacote): `https://draerikabatista.com.br/viagem/itinerario.html` e
`https://draerikabatista.com.br/viagem/Album/album.html`.

Precedência aplicada: instruções da conversa → design system aprovado → galeria
de componentes → spec de produto.

---

## Marca

**Não há logo no pacote e nenhum foi desenhado.** Onde uma marca apareceria, o
pacote usa o nome em tipografia simples — “Travel Companion” em Fraunces 600 ou
Roboto Bold, e “Field Companion” como nome do sistema visual. A galeria aprovada
usa um quadrado escuro com as letras “TC” como marcador provisório; ele não foi
reproduzido aqui para não virar um logo de fato.

Para reservar o espaço em layout há **placeholders explícitos** (moldura
tracejada, rótulo monoespaçado, nenhum símbolo):
`assets/brand/logo-placeholder.svg` (320×96, horizontal, para app bar e
cabeçalhos) e `assets/brand/logo-placeholder-square.svg` (128×128, para ícone de
app e splash). Substitua os arquivos quando o símbolo real existir; nada mais
precisa mudar.

---

## VISUAL FOUNDATIONS

**Direção:** guia de campo por fora, instrumento de viagem por dentro. Fundo de
papel quente, tipografia slate escura, teal contido, ouro antigo como detalhe
editorial, musgo para confirmação, oxblood para crítico.

**Cor.** Sete cores de marca (ink `#16232E`, paper `#F5F1E8`, surface
`#FFFDF8`, teal `#1F6F78`, gold `#B8863B`, oxblood `#7A2E2E`, moss
`#4C6444`), onze neutros e quatro famílias semânticas (primary, success,
warning, critical), cada uma com par sólido e par “subtle”. Semântica sempre
comunica estado, nunca decoração. Nunca preto puro em texto. Máximo de duas
cores de fundo por tela: paper para a página, surface para superfícies
elevadas — ink e oxblood aparecem como blocos inteiros (Agora, Walk Mode,
Emergência), não como acento.

**Tipografia.** Duas famílias com responsabilidades separadas. **Fraunces**
(SemiBold 600, Google Fonts, eixo opsz 9..144) só em conteúdo editorial: nome de
cidade, título de capítulo, hero de atração, nome de passeio. **Roboto**
(400/500/700) em tudo que é operação: horários, botões, timeline, tickets,
clima, avisos, formulários, metadados. Fraunces é **proibida** em horário,
identificador de transporte, dado de ticket, aviso crítico e botão. Escala:
display 40/44, 32/38, 28/34 · headings 28/34, 24/30, 20/26 · body 18/27, 16/24,
14/20 · labels 16/20, 14/18, 12/16 · time hero 28/30 e time inline 16/20,
tabulares. Eyebrow: 12px Bold, uppercase, tracking .12em, teal.

**Espaçamento e layout.** Grade base 4dp; gutter de tela 20dp (16dp só em
superfície operacional muito densa); coluna única — nada de grid de dashboard em
telefone. Artboard 412×915. Alvo de toque mínimo 48dp; 52dp para ações críticas
(mostrar passagem, abrir Maps, começar passeio, gravar memória, ligar).

**Forma.** Raios 6/10/14/20/28/pill. Botão 14, card operacional 14, documento 10,
hero 20–28, chip pill. Raio grande **não** se aplica a todo container.

**Bordas.** 1dp neutral-200 por padrão; 1dp neutral-300 para divisor forte;
card crítico ganha acento de 5px à esquerda em oxblood — sempre acompanhado de
ícone e texto, nunca cor sozinha.

**Elevação.** Rasa e rara: nível 0 na página, nível 1 (`0 8px 24px rgba(22,35,46,.07)`)
em card padrão, bottom nav e player compacto, nível 2 (`0 14px 42px rgba(22,35,46,.12)`)
em controle flutuante e gravador ativo, nível 3 só em modal, bottom sheet e
overlay de emergência. Cards de superfície usam quase nada: `0 1px 0 rgba(22,35,46,.02)`.

**Fundos e imagem.** Sem gradiente decorativo. O único gradiente do sistema é o
de proteção de texto sobre fotografia (`rgba(22,35,46,.7)` → `rgba(22,35,46,.05)`).
Não há fotografia no pacote: heroes sem `image` renderizam o placeholder da
galeria (gradiente cinza-esverdeado) com uma etiqueta monoespaçada dizendo o que
entra ali. Texto operacional nunca vai sobre foto; nome de cidade pode, com
contraste garantido. Textura só em área editorial, nunca atrás de texto denso,
documento ou emergência.

**Transparência e blur.** Praticamente ausentes. Em superfícies ink, o sistema
usa preenchimentos brancos translúcidos fixos (`.06`, `.07`, `.08`) e borda
`.25`/`.12`, além do halo teal `rgba(31,111,120,.45)` no card Agora. Sem
glassmorphism.

**Movimento.** micro 120ms, standard 200ms, emphasized 300ms. Permitido:
expansão de card, transição do player, marcador atual da timeline, waveform,
reconexão de participante, contagem 3–2–1 do áudio compartilhado. Proibido:
parallax em tarefa operacional, transição decorativa de página, botão que
quica. Respeita redução de movimento.

**Hover / press / disabled.** Android primeiro: interação é toque. Press escurece
levemente o preenchimento (ou usa o estado ripple nativo na implementação);
hover, no protótipo web, usa a mesma variação sutil. Disabled é opacidade 0.42 e
cursor padrão — nunca cinza novo fora da paleta. Foco: contorno visível, ordem
previsível.

**Acessibilidade.** WCAG AA, alvo 48dp, escala de texto suportada, nada
comunicado só por cor, ícone + texto em elemento crítico, transcrição para todo
audioguia.

---

## CONTENT FUNDAMENTALS

Interface em **português do Brasil**. As strings deste pacote são as aprovadas —
“Quem é você?”, “Não pode dar errado”, “Ouvir juntos”, “Sincronizado”,
“Memória salva em Žabljak · 14:51” — e não devem ser reescritas.

- **Voz:** concisa, útil e humana. “Esteja no ponto até 19:00.” em vez de
  “Recomendamos que os usuários se dirijam ao ponto de embarque com antecedência
  adequada.”
- **Crítico é literal.** Prazo, consequência, ação. Nada de eufemismo.
- **Editorial pode narrar.** Frases mais longas, contexto histórico, observação
  concreta (“olhe a junta das pedras no meio do arco”).
- **Erro explica o que continua funcionando:** “Não foi possível sincronizar o
  grupo. Seu audioguia continua funcionando normalmente.” Nunca “Erro de conexão”.
- **Offline não é falha:** “Offline · conteúdo disponível”.
- **Deeplink diz o destino:** “Abrir no Maps”, “Ver reserva no Booking”,
  “Chamar Bolt” — nunca “Abrir”, “Link”, “Ver mais”.
- **Vocabulário de áudio:** Audioguia, Ouvir, Ouvir juntos, Pausar, Continuar,
  Próxima história, Transcrição, Sincronizado. Proibidos na UI: stream, session,
  room, peer, timestamp, latência, Firebase.
- **Vocabulário de GPS:** Histórias pelo caminho, Localização ativa, Procurando
  sua localização, Localização imprecisa. Proibidos: geofence, background
  location, location provider.
- **Casing:** frases em sentence case; só eyebrow/label pequeno em uppercase com
  tracking. Nada de Title Case em botão.
- **Números pt-BR:** `19:30`, `16 de setembro`, `€ 24,07`, `1.000 lek`,
  `2,5 km`, `45 min`. Códigos de operadora mantêm o formato original.
- **Emoji:** usado com parcimônia como apoio — bandeira de país depois do nome
  (“Sarajevo · Bósnia e Herzegovina 🇧🇦”) e ícone de tipo de documento
  (🎫 🏨 🛡️ 🎙️), exatamente como na galeria aprovada. Nunca como decoração.

---

## ICONOGRAPHY

O handoff **não inclui arquivos de ícone**. O pacote traz agora um **set nativo
desenhado para este sistema**, em `assets/icons/`: 35 ícones geométricos na
grade de 24, traço de 2px, pontas e junções arredondadas, `currentColor`,
seguindo o §15 (traço simples, junções arredondadas, uma família só).

```
arrow-left · arrow-right · chevron-right · chevron-down · close · check · plus
minus · play · pause · record · clock · pin · calendar · ticket · qr · warning
offline · sun · mic · headphones · document · map · compass · wallet · person
group · more-horiz · call · alt-route · settings · near-me · notifications · bed · shield
```

Como usar:

```html
<script src="assets/icons/tc-icons.js"></script>   <!-- injeta o sprite -->
<svg width="24" height="24" viewBox="0 0 24 24"><use href="#tc-map"></use></svg>
```

Também há `assets/icons/tc-icons.svg` (sprite standalone) e um arquivo por
ícone (`tc-map.svg`, …) para quem preferir importar individualmente. Tamanhos
do sistema: 18dp metadado, 20dp inline, 24dp ação padrão, 28–32dp ação
proeminente, 40dp emergência/gravador.

**Material Symbols Rounded** continua carregada em `styles.css` (classe
`.tc-icon` + `.tc-icon-18/20/24/28/32/40`) para os pictogramas que o set
nativo não cobre — figura humana e objetos complexos: `directions_walk`,
`restaurant`, `translate`, `apps`, `currency_exchange`,
`account_balance`, `local_hospital`, `present_to_all`. Não misture outras
famílias.

Onde a galeria aprovada usa glifo literal, o pacote mantém o glifo: emoji de
tipo de documento (🎫 🏨 🛡️ 🎙️) nas linhas da Carteira e controles unicode
(▶ ❙❙ →) no player. Os componentes recebem o ícone como `node`, então trocar o
set inteiro não exige mudar componente.

---

## Componentes

Inventário **fechado**: são os nomes definidos em `§50 Component naming` do
design system aprovado (e no array `components` do JSON de tokens). Nada foi
adicionado — sem Toast, Avatar, Tabs, Input.

> Nota: o briefing fala em “26 componentes”; a lista aprovada tem **27** nomes
> (`TcButton` … `TcSectionHeader`). Os 27 estão construídos.

| Grupo | Componentes |
|---|---|
| `components/core/` | TcButton, TcIconButton, TcChip, TcStatusChip, TcCard, TcSectionHeader, TcOfflineStatus |
| `components/today/` | TcNowCard, TcCriticalCard, TcTimeline, TcTimelineItem, TcWeatherSummary, TcOutfitCard |
| `components/editorial/` | TcCityHero, TcAttractionHero, TcStoryCard |
| `components/operational/` | TcTransportCard, TcAccommodationCard, TcPlanBCard, TcEmergencyAction |
| `components/audio/` | TcAudioPlayer, TcGroupAudioStatus, TcParticipantStatus, TcWalkProgress, TcVoiceRecorder |
| `components/wallet/` | TcDocumentRow, TcQrViewer |

Cada componente tem `.jsx` (export nomeado), `.d.ts` (contrato de props e
regras) e `.prompt.md` (quando usar + exemplo). Estilo sempre por custom
properties — sem CSS-in-JS, sem dependências.

### Peças derivadas (declaradas)

A galeria aprovada não traz especimen para tudo. Onde ela é silenciosa, a
geometria foi derivada de outro especimen dela — nunca de default de framework:

- **TcAccommodationCard** — não existe na galeria; reusa a geometria do card de
  transporte (raio 14, padding 18, horários 24px Bold).
- **TcOfflineStatus** — a galeria só mostra o chip neutro “Offline”; o formato
  inline (dot 8px + 13px neutral-600) segue a linguagem do §40.
- **TcIconButton** — a galeria só tem o círculo teal de 46px do player; os
  tamanhos 40/48/56 vêm dos alvos de toque do §19.
- **TcCityHero** — a galeria usa 30px Fraunces no hero de atração; o hero de
  cidade usa Display Large 40/44 conforme o §9.
- **TcSectionHeader** — deriva do cabeçalho de seção da própria galeria
  (eyebrow teal 12px + H2 24px).

### Não incluído (por falta de material)

- Fotografia. Heroes renderizam placeholder rotulado.
- Logo/símbolo de marca (há placeholder, não há marca).
- Arquivos de fonte locais (Fraunces e Roboto vêm do Google Fonts).
- Tela “Mostrar para alguém” e telas de permissão em alta fidelidade: o handoff
  as descreve como anotação, não como uma das 18 telas — ficaram anotadas.

---

## Tokens

`styles.css` (raiz) é o ponto de entrada e contém apenas `@import`:

```
tokens/fonts.css        famílias e pesos (Fraunces, Roboto, mono)
tokens/colors.css       marca, neutros, semântica + aliases (--tc-text-primary…)
tokens/dark.css         tema escuro como escopo [data-theme="dark"] / .tc-theme-dark
tokens/typography.css   escala de tipo, pesos, tracking
tokens/spacing.css      escala 4dp
tokens/shape.css        raios + aliases de papel (botão, card, documento, hero)
tokens/elevation.css    sombras 0–3 e as duas sombras específicas da galeria
tokens/motion.css       120 / 200 / 300ms + easing
tokens/layout.css       412×915, gutter, alvos de toque, status bar, bottom nav
tokens/base.css         reset mínimo, `.tc-root`, `.tc-display`, `.tc-tabular`, `.tc-icon`
```

O tema escuro **não** é um sistema separado nem uma inversão: só os papéis que o
§49 define para a noite são reapontados dentro do escopo.

---

## Índice do pacote

- `readme.md` — este arquivo (contexto, fundamentos visuais, conteúdo, iconografia, índice).
- `SKILL.md` — instruções para uso como skill.
- `styles.css` + `tokens/` — CSS de tokens (claro + escuro).
- `components/<grupo>/` — os 27 componentes + card de galeria por grupo.
- `components/_card-boot.js` — bootstrap dos cards/kit; não é componente.
- `guidelines/*.card.html` — 21 especimens de fundação (cor, tipo, espaço, ícones, marca).
- `assets/icons/` — set nativo de 35 ícones (`tc-icons.js` injeta o sprite; `tc-icons.svg` e arquivos individuais).
- `assets/brand/` — placeholders de logo (horizontal 320×96 e quadrado 128×128). Nenhum símbolo foi desenhado.
- `ui_kits/android-app/` — UI kit: `index.html` (fluxo principal clicável, 18
  telas, pranchas de estado), `screens.jsx`, `README.md`.
